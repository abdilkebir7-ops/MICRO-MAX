import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";
import crypto from "crypto";
import rateLimit from "express-rate-limit";
import PDFDocument from "pdfkit";
import { RouterOS } from "./routeros.js";
import { binancePayConfigured, createBinancePayOrder, queryBinancePayOrder, verifyBinancePayNotification } from "./binancePay.js";

dotenv.config();
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json({ limit: "2mb", verify: (req, _res, buf) => { req.rawBody = Buffer.from(buf); } }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false });
const ENC_KEY = crypto.createHash("sha256").update(process.env.ROUTER_ENCRYPTION_KEY || process.env.JWT_SECRET || "change-me").digest();
const IV_LEN = 12;
function encrypt(text) { const iv=crypto.randomBytes(IV_LEN); const c=crypto.createCipheriv("aes-256-gcm", ENC_KEY, iv); const data=Buffer.concat([c.update(String(text),"utf8"),c.final()]); return `${iv.toString("base64")}.${c.getAuthTag().toString("base64")}.${data.toString("base64")}`; }
function decrypt(value) { const [iv,tag,data]=String(value).split(".").map(x=>Buffer.from(x,"base64")); const d=crypto.createDecipheriv("aes-256-gcm",ENC_KEY,iv); d.setAuthTag(tag); return Buffer.concat([d.update(data),d.final()]).toString("utf8"); }
function sign(user) { return jwt.sign({ sub:user.id,email:user.email,role:user.role }, process.env.JWT_SECRET, { expiresIn:"12h" }); }
function auth(req,res,next){ const h=req.headers.authorization||""; try{ const t=h.startsWith("Bearer ")?h.slice(7):""; req.user=jwt.verify(t,process.env.JWT_SECRET); next(); }catch{res.status(401).json({error:"UNAUTHORIZED"});} }
function role(...roles){ return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:"FORBIDDEN"}); }
async function audit(userId,action,entity,entityId,details={}){ await pool.query("INSERT INTO audit_logs(id,user_id,action,entity,entity_id,details) VALUES(gen_random_uuid(),$1,$2,$3,$4,$5)",[userId,action,entity,entityId,JSON.stringify(details)]); }

async function init(){
 await pool.query(`CREATE EXTENSION IF NOT EXISTS pgcrypto;
 CREATE TABLE IF NOT EXISTS users(id UUID PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'staff',created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS routers(id UUID PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL,host TEXT NOT NULL,port INTEGER NOT NULL DEFAULT 8728,username TEXT NOT NULL,password_enc TEXT NOT NULL,tls BOOLEAN NOT NULL DEFAULT false,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS cards(id UUID PRIMARY KEY,router_id UUID NOT NULL REFERENCES routers(id) ON DELETE CASCADE,username TEXT NOT NULL,password TEXT NOT NULL,profile TEXT NOT NULL DEFAULT 'default',price NUMERIC(14,2) NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'available',sold_at TIMESTAMPTZ,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(router_id,username));
 CREATE TABLE IF NOT EXISTS sales(id UUID PRIMARY KEY,card_id UUID REFERENCES cards(id) ON DELETE SET NULL,seller_id UUID REFERENCES users(id) ON DELETE SET NULL,amount NUMERIC(14,2) NOT NULL,payment_method TEXT NOT NULL,payment_status TEXT NOT NULL DEFAULT 'pending',reference TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS payments(id UUID PRIMARY KEY,sale_id UUID REFERENCES sales(id) ON DELETE CASCADE,provider TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',external_reference TEXT,amount NUMERIC(14,2) NOT NULL,raw JSONB,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS audit_logs(id UUID PRIMARY KEY,user_id UUID REFERENCES users(id) ON DELETE SET NULL,action TEXT NOT NULL,entity TEXT NOT NULL,entity_id TEXT,details JSONB,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS notifications(id UUID PRIMARY KEY,user_id UUID REFERENCES users(id) ON DELETE CASCADE,title TEXT NOT NULL,body TEXT NOT NULL,level TEXT NOT NULL DEFAULT 'info',read_at TIMESTAMPTZ,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS hotspot_themes(id UUID PRIMARY KEY,router_id UUID REFERENCES routers(id) ON DELETE CASCADE UNIQUE,name TEXT NOT NULL,logo_url TEXT,primary_color TEXT NOT NULL,background TEXT NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
 CREATE TABLE IF NOT EXISTS hotspot_profiles(id UUID PRIMARY KEY,router_id UUID NOT NULL REFERENCES routers(id) ON DELETE CASCADE,name TEXT NOT NULL,price NUMERIC(14,2) NOT NULL DEFAULT 0,duration_minutes INTEGER NOT NULL DEFAULT 0,rate_limit TEXT NOT NULL DEFAULT '',session_timeout TEXT NOT NULL DEFAULT '',idle_timeout TEXT NOT NULL DEFAULT '',shared_users INTEGER NOT NULL DEFAULT 1,enabled BOOLEAN NOT NULL DEFAULT true,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(router_id,name));
 CREATE TABLE IF NOT EXISTS hotspot_plans(id UUID PRIMARY KEY,router_id UUID NOT NULL REFERENCES routers(id) ON DELETE CASCADE,profile_name TEXT NOT NULL,name TEXT NOT NULL,price NUMERIC(14,2) NOT NULL DEFAULT 0,currency TEXT NOT NULL DEFAULT 'XOF',active BOOLEAN NOT NULL DEFAULT true,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(router_id,name));
 CREATE TABLE IF NOT EXISTS plan_price_history(id UUID PRIMARY KEY,plan_id UUID NOT NULL REFERENCES hotspot_plans(id) ON DELETE CASCADE,old_price NUMERIC(14,2),new_price NUMERIC(14,2) NOT NULL,changed_by UUID REFERENCES users(id) ON DELETE SET NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 ALTER TABLE cards ADD COLUMN IF NOT EXISTS plan_id UUID REFERENCES hotspot_plans(id) ON DELETE SET NULL;
 ALTER TABLE cards ADD COLUMN IF NOT EXISTS price_currency TEXT NOT NULL DEFAULT 'XOF';
ALTER TABLE cards ADD COLUMN IF NOT EXISTS batch_id UUID;
 ALTER TABLE cards ADD COLUMN IF NOT EXISTS qr_content TEXT;
 CREATE TABLE IF NOT EXISTS app_settings(user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,theme TEXT NOT NULL DEFAULT 'light',currency TEXT NOT NULL DEFAULT 'XOF');
 CREATE TABLE IF NOT EXISTS store_items(id UUID PRIMARY KEY,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT 'template',price NUMERIC(14,2) NOT NULL DEFAULT 0,active BOOLEAN NOT NULL DEFAULT true,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
 INSERT INTO store_items(id,name,description,category,price,active)
 SELECT gen_random_uuid(),'MICRO-MAX Glass','قالب زجاجي مجاني لواجهة HotSpot','template',0,true
 WHERE NOT EXISTS (SELECT 1 FROM store_items WHERE name='MICRO-MAX Glass');
 INSERT INTO store_items(id,name,description,category,price,active)
 SELECT gen_random_uuid(),'VIP HotSpot','قالب VIP مجاني لواجهة HotSpot','template',0,true
 WHERE NOT EXISTS (SELECT 1 FROM store_items WHERE name='VIP HotSpot');
 INSERT INTO store_items(id,name,description,category,price,active)
 SELECT gen_random_uuid(),'QR / Barcode Pack','أدوات إنشاء QR وBarcode للكروت بدون اشتراك','tools',0,true
 WHERE NOT EXISTS (SELECT 1 FROM store_items WHERE name='QR / Barcode Pack');
 CREATE TABLE IF NOT EXISTS store_entitlements(id UUID PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,item_id UUID NOT NULL REFERENCES store_items(id) ON DELETE CASCADE,created_at TIMESTAMPTZ NOT NULL DEFAULT now(),UNIQUE(user_id,item_id));`);
}

app.get("/health",(_,res)=>res.json({ok:true,service:"MICRO-MAX API",version:"2.0.0"}));
app.post("/api/auth/register",async(req,res)=>{const email=String(req.body.email||"").trim().toLowerCase(),password=String(req.body.password||"");if(!email||password.length<8)return res.status(400).json({error:"INVALID_INPUT"});try{const count=await pool.query("SELECT count(*)::int n FROM users");const id=crypto.randomUUID(),hash=await bcrypt.hash(password,12),roleName=count.rows[0].n===0?"admin":"staff";const r=await pool.query("INSERT INTO users(id,email,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,email,role",[id,email,hash,roleName]);await pool.query("INSERT INTO app_settings(user_id) VALUES($1) ON CONFLICT DO NOTHING",[id]);res.status(201).json({token:sign(r.rows[0]),user:r.rows[0]});}catch{res.status(409).json({error:"EMAIL_EXISTS"});}});
app.post("/api/auth/login",loginLimiter,async(req,res)=>{const email=String(req.body.email||"").trim().toLowerCase(),password=String(req.body.password||"");const r=await pool.query("SELECT * FROM users WHERE email=$1",[email]);if(!r.rowCount||!(await bcrypt.compare(password,r.rows[0].password_hash)))return res.status(401).json({error:"INVALID_CREDENTIALS"});await audit(r.rows[0].id,"LOGIN","user",r.rows[0].id);res.json({token:sign(r.rows[0]),user:{id:r.rows[0].id,email:r.rows[0].email,role:r.rows[0].role}});});
app.get("/api/me",auth,async(req,res)=>{const r=await pool.query("SELECT id,email,role,created_at FROM users WHERE id=$1",[req.user.sub]);res.json(r.rows[0]);});
app.get("/api/features",auth,async(req,res)=>{res.json({subscriptionRequired:false,storeOpen:true,paymentsOptional:true,features:{mikrotik:true,routerManagement:true,dashboard:true,hotspotCards:true,qrCode:true,barcode:true,inventory:true,sales:true,reports:true,usersAndRoles:true,auditLog:true,backup:true,hotspotThemes:true,store:true}});});
app.get("/api/store",auth,async(req,res)=>{const r=await pool.query("SELECT id,name,description,category,price,active,created_at FROM store_items WHERE active=true ORDER BY created_at DESC");res.json({open:true,subscriptionRequired:false,items:r.rows});});
app.post("/api/store/:id/activate",auth,async(req,res)=>{const r=await pool.query("SELECT id,name,description,category,price FROM store_items WHERE id=$1 AND active=true",[req.params.id]);if(!r.rowCount)return res.status(404).json({error:"STORE_ITEM_NOT_FOUND"});await pool.query("INSERT INTO store_entitlements(id,user_id,item_id) VALUES($1,$2,$3) ON CONFLICT(user_id,item_id) DO NOTHING",[crypto.randomUUID(),req.user.sub,req.params.id]);await audit(req.user.sub,"ACTIVATE","store_item",req.params.id,{name:r.rows[0].name});res.json({ok:true,subscriptionRequired:false,item:r.rows[0],message:"تم تفعيل العنصر مجاناً داخل حسابك."});});
app.get("/api/store/my",auth,async(req,res)=>{const r=await pool.query("SELECT e.created_at,i.id,i.name,i.description,i.category,i.price FROM store_entitlements e JOIN store_items i ON i.id=e.item_id WHERE e.user_id=$1 ORDER BY e.created_at DESC",[req.user.sub]);res.json({items:r.rows});});
app.get("/api/payment-methods",auth,async(req,res)=>{const online=process.env.ENABLE_ONLINE_PAYMENTS==="true";res.json({methods:[{id:"cash",name:"نقداً / يدوي",available:true},...(online?[{id:"binance_pay",name:"Binance Pay",available:binancePayConfigured()}]:[])]});});

app.get("/api/routers",auth,async(req,res)=>{const r=await pool.query("SELECT id,name,host,port,username,tls,created_at FROM routers WHERE user_id=$1 ORDER BY created_at DESC",[req.user.sub]);res.json({routers:r.rows});});
app.post("/api/routers/test",auth,async(req,res)=>{const {host,port=8728,username,password,tls=false}=req.body;try{const ros=new RouterOS({host,port:Number(port),username,password,tls:!!tls});const resource=await ros.command("/system/resource/print",[]);await ros.close();res.json({ok:true,resource:resource[0]||{}});}catch(e){res.status(400).json({ok:false,error:"ROUTER_CONNECTION_FAILED",detail:e.message});}});
app.post("/api/routers",auth,async(req,res)=>{const {name,host,port=8728,username,password,tls=false}=req.body;if(!name||!host||!username||!password)return res.status(400).json({error:"INVALID_INPUT"});const id=crypto.randomUUID();await pool.query("INSERT INTO routers(id,user_id,name,host,port,username,password_enc,tls) VALUES($1,$2,$3,$4,$5,$6,$7,$8)",[id,req.user.sub,name,host,Number(port),username,encrypt(password),!!tls]);await audit(req.user.sub,"CREATE","router",id,{name,host});res.status(201).json({id,name,host,port:Number(port),username,tls:!!tls});});
app.delete("/api/routers/:id",auth,role("admin"),async(req,res)=>{await pool.query("DELETE FROM routers WHERE id=$1 AND user_id=$2",[req.params.id,req.user.sub]);await audit(req.user.sub,"DELETE","router",req.params.id);res.status(204).end();});
async function getRouter(req,id){const r=await pool.query("SELECT * FROM routers WHERE id=$1 AND user_id=$2",[id,req.user.sub]);if(!r.rowCount)throw Error("ROUTER_NOT_FOUND");return r.rows[0];}
async function withRos(req,id,fn){const router=await getRouter(req,id);const ros=new RouterOS({host:router.host,port:router.port,username:router.username,password:decrypt(router.password_enc),tls:router.tls});try{return await fn(ros,router);}finally{await ros.close().catch(()=>{});}}
app.get("/api/routers/:id/dashboard",auth,async(req,res)=>{try{const data=await withRos(req,req.params.id,async ros=>{const [resource,active,interfaces]=await Promise.all([ros.command("/system/resource/print",[]),ros.command("/ip/hotspot/active/print",[]),ros.command("/interface/print",[])]);return {resource:resource[0]||{},activeUsers:active.length,interfaces};});res.json(data);}catch(e){res.status(502).json({error:"ROUTER_QUERY_FAILED",detail:e.message});}});
function hotspotDuration(minutes){
  const m=Math.max(0,Number(minutes)||0);
  if(!m) return "";
  if(m%1440===0) return `${m/1440}d`;
  if(m%60===0) return `${m/60}h`;
  return `${m}m`;
}
function profilePayload(body){
  const name=String(body.name||"").trim();
  if(!name || name.length>64) throw Error("INVALID_PROFILE_NAME");
  const price=0;
  const durationMinutes=Math.max(0,Math.floor(Number(body.durationMinutes)||0));
  const rateLimit=String(body.rateLimit||"").trim();
  const sessionTimeout=String(body.sessionTimeout||hotspotDuration(durationMinutes)).trim();
  const idleTimeout=String(body.idleTimeout||"").trim();
  const sharedUsers=Math.min(Math.max(Math.floor(Number(body.sharedUsers)||1),1),100);
  return {name,price,durationMinutes,rateLimit,sessionTimeout,idleTimeout,sharedUsers};
}

app.get("/api/routers/:id/hotspot-profiles",auth,async(req,res)=>{
  try{
    const items=await withRos(req,req.params.id,async ros=>{
      const [routerProfiles,local]=await Promise.all([
        ros.command("/ip/hotspot/user/profile/print",[]),
        pool.query("SELECT name,price,duration_minutes,rate_limit,session_timeout,idle_timeout,shared_users,enabled FROM hotspot_profiles WHERE router_id=$1 ORDER BY name",[req.params.id])
      ]);
      const meta=new Map(local.rows.map(x=>[x.name,x]));
      return routerProfiles.map(x=>({name:x.name||"",rateLimit:x["rate-limit"]||"",sessionTimeout:x["session-timeout"]||"",idleTimeout:x["idle-timeout"]||"",sharedUsers:Number(x["shared-users"]||1),price:Number(meta.get(x.name)?.price||0),durationMinutes:Number(meta.get(x.name)?.duration_minutes||0),enabled:meta.get(x.name)?.enabled!==false}));
    });
    res.json({profiles:items});
  }catch(e){res.status(502).json({error:"HOTSPOT_PROFILE_QUERY_FAILED",detail:e.message});}
});
app.post("/api/routers/:id/hotspot-profiles",auth,async(req,res)=>{
  try{
    const p=profilePayload(req.body);
    const result=await withRos(req,req.params.id,async ros=>{
      const existing=await ros.command("/ip/hotspot/user/profile/print",[]);
      const found=existing.find(x=>x.name===p.name);
      const args=[`=name=${p.name}`,`=shared-users=${p.sharedUsers}`];
      if(p.rateLimit) args.push(`=rate-limit=${p.rateLimit}`);
      if(p.sessionTimeout) args.push(`=session-timeout=${p.sessionTimeout}`);
      if(p.idleTimeout) args.push(`=idle-timeout=${p.idleTimeout}`);
      if(found?.[".id"]){
        const setArgs=[`=.id=${found[".id"]}`,...args.slice(1)];
        await ros.command("/ip/hotspot/user/profile/set",setArgs);
      }else{
        await ros.command("/ip/hotspot/user/profile/add",args);
      }
      const q=await pool.query(`INSERT INTO hotspot_profiles(id,router_id,name,price,duration_minutes,rate_limit,session_timeout,idle_timeout,shared_users,enabled)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,true)
        ON CONFLICT(router_id,name) DO UPDATE SET price=0,duration_minutes=EXCLUDED.duration_minutes,rate_limit=EXCLUDED.rate_limit,session_timeout=EXCLUDED.session_timeout,idle_timeout=EXCLUDED.idle_timeout,shared_users=EXCLUDED.shared_users,enabled=true,updated_at=now()
        RETURNING *`,[crypto.randomUUID(),req.params.id,p.name,p.price,p.durationMinutes,p.rateLimit,p.sessionTimeout,p.idleTimeout,p.sharedUsers]);
      return q.rows[0];
    });
    await audit(req.user.sub,"UPSERT","hotspot_profile",req.params.id,{name:p.name,price:p.price,durationMinutes:p.durationMinutes});
    res.status(201).json({profile:result});
  }catch(e){res.status(400).json({error:"HOTSPOT_PROFILE_SAVE_FAILED",detail:e.message});}
});

// Smart selling layer: MICRO-MAX Plan owns price; MikroTik Profile owns network behavior.
app.get("/api/routers/:id/plans",auth,async(req,res)=>{try{const r=await pool.query(`SELECT p.*,hp.duration_minutes,hp.rate_limit,hp.session_timeout,hp.idle_timeout,hp.shared_users FROM hotspot_plans p LEFT JOIN hotspot_profiles hp ON hp.router_id=p.router_id AND hp.name=p.profile_name WHERE p.router_id=$1 ORDER BY p.active DESC,p.name`,[req.params.id]);res.json({plans:r.rows});}catch(e){res.status(500).json({error:"PLANS_QUERY_FAILED",detail:e.message});}});
app.post("/api/routers/:id/plans",auth,async(req,res)=>{try{const profileName=String(req.body.profileName||"").trim(),name=String(req.body.name||profileName).trim(),currency=String(req.body.currency||"XOF").trim().toUpperCase(),price=Math.max(0,Number(req.body.price)||0);if(!profileName||!name||!Number.isFinite(price))return res.status(400).json({error:"INVALID_PLAN"});const check=await pool.query("SELECT 1 FROM hotspot_profiles WHERE router_id=$1 AND name=$2",[req.params.id,profileName]);if(!check.rowCount)return res.status(400).json({error:"HOTSPOT_PROFILE_NOT_FOUND"});const existing=await pool.query("SELECT id,price FROM hotspot_plans WHERE router_id=$1 AND name=$2",[req.params.id,name]);let q;if(existing.rowCount){const old=Number(existing.rows[0].price);q=await pool.query("UPDATE hotspot_plans SET profile_name=$1,price=$2,currency=$3,active=true,updated_at=now() WHERE id=$4 RETURNING *",[profileName,price,currency,existing.rows[0].id]);if(Math.abs(old-price)>0.000001)await pool.query("INSERT INTO plan_price_history(id,plan_id,old_price,new_price,changed_by) VALUES($1,$2,$3,$4,$5)",[crypto.randomUUID(),existing.rows[0].id,old,price,req.user.sub]);}else{q=await pool.query("INSERT INTO hotspot_plans(id,router_id,profile_name,name,price,currency) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",[crypto.randomUUID(),req.params.id,profileName,name,price,currency]);await pool.query("INSERT INTO plan_price_history(id,plan_id,old_price,new_price,changed_by) VALUES($1,$2,$3,$4,$5)",[crypto.randomUUID(),q.rows[0].id,null,price,req.user.sub]);}await audit(req.user.sub,"UPSERT","hotspot_plan",q.rows[0].id,{name,profileName,price,currency});res.status(201).json({plan:q.rows[0]});}catch(e){res.status(400).json({error:"PLAN_SAVE_FAILED",detail:e.message});}});
app.get("/api/plans/:id/price-history",auth,async(req,res)=>{const r=await pool.query("SELECT h.*,u.email changed_by_email FROM plan_price_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.plan_id=$1 ORDER BY h.created_at DESC",[req.params.id]);res.json({history:r.rows});});


function validateLoginHtml(html){
  const src=String(html||"");
  const warnings=[];
  const errors=[];
  const hasForm=/<form\b/i.test(src);
  const hasUser=/(name=["']username["']|id=["']username["'])/i.test(src);
  const hasPass=/(name=["']password["']|id=["']password["'])/i.test(src);
  const hasLoginAction=/(action=["'][^"']*login[^"']*["'])/i.test(src) || /\$\(link-login-only\)/i.test(src);
  const hasLinkLogin= /\$\(link-login-only\)/i.test(src);
  const hasLinkOrig= /\$\(link-orig\)/i.test(src);
  const hasError= /\$\(error\)/i.test(src);
  const hasMd5= /\$\(chap-id\)|\$\(chap-challenge\)/i.test(src);
  const hasAutoSubmit=/\.submit\s*\(|requestSubmit\s*\(/i.test(src);
  if(!hasForm) errors.push("LOGIN_FORM_MISSING");
  if(!hasUser) errors.push("USERNAME_FIELD_MISSING");
  if(!hasPass) errors.push("PASSWORD_FIELD_MISSING");
  if(!hasLoginAction) errors.push("LOGIN_ACTION_MISSING");
  if(!hasLinkLogin) warnings.push("LINK_LOGIN_ONLY_MISSING");
  if(!hasLinkOrig) warnings.push("LINK_ORIG_MISSING");
  if(!hasError) warnings.push("ERROR_VARIABLE_MISSING");
  if(hasMd5 && !/md5\.js|hexMD5|doLogin/i.test(src)) warnings.push("CHAP_VARIABLES_FOUND_BUT_CHAP_HANDLER_NOT_DETECTED");
  return {valid:errors.length===0,errors,warnings,checks:{hasForm,hasUser,hasPass,hasLoginAction,hasLinkLogin,hasLinkOrig,hasError,hasMd5,hasAutoSubmit}};
}

async function getRouterForUser(req,id){
  const q=await pool.query("SELECT * FROM routers WHERE id=$1 AND user_id=$2",[id,req.user.sub]);
  if(!q.rowCount) throw Error("ROUTER_NOT_FOUND");
  return q.rows[0];
}

app.get("/api/routers/:id/hotspot-login",auth,async(req,res)=>{
  let ros;
  try{
    const r=await getRouterForUser(req,req.params.id);
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt(r.password_enc),tls:r.tls});
    await ros.connect();
    const files=await ros.command("/file/print",["?name=hotspot/login.html"]);
    const f=files[0]||{};
    const content=String(f.contents||"");
    const validation=validateLoginHtml(content);
    res.json({routerId:r.id,name:r.name,file:"hotspot/login.html",content,validation,updatedAt:f.creation_time||f["creation-time"]||null});
  }catch(e){res.status(502).json({error:"HOTSPOT_LOGIN_READ_FAILED",detail:e.message});}
  finally{try{await ros?.close();}catch{}}
});

app.post("/api/routers/:id/hotspot-login/validate",auth,async(req,res)=>{
  try{
    await getRouterForUser(req,req.params.id);
    const validation=validateLoginHtml(String(req.body.content||""));
    res.json(validation);
  }catch(e){res.status(400).json({valid:false,error:"HOTSPOT_LOGIN_VALIDATE_FAILED",detail:e.message});}
});

app.post("/api/routers/:id/hotspot-login/publish",auth,role("admin"),async(req,res)=>{
  let ros;
  try{
    const r=await getRouterForUser(req,req.params.id);
    const content=String(req.body.content||"");
    if(content.length<100 || content.length>500000) return res.status(400).json({error:"INVALID_LOGIN_HTML_SIZE"});
    const validation=validateLoginHtml(content);
    if(!validation.valid) return res.status(400).json({error:"LOGIN_HTML_INCOMPATIBLE",validation});
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt(r.password_enc),tls:r.tls});
    await ros.connect();
    const current=await ros.command("/file/print",["?name=hotspot/login.html"]);
    const old=String(current[0]?.contents||"");
    const backupName=`hotspot/login.html.micromax-${new Date().toISOString().replace(/[:.]/g,"-")}.bak`;
    if(old){
      try{ await ros.command("/file/add",[`=name=${backupName}`,`=contents=${old}`]); }catch{}
    }
    const target=current[0]?.[".id"] || current[0]?.id;
    if(target) await ros.command("/file/set",[`=.id=${target}`,`=contents=${content}`]);
    else await ros.command("/file/add",["=name=hotspot/login.html",`=contents=${content}`]);
    await audit(req.user.sub,"PUBLISH","hotspot_login",req.params.id,{backup:backupName,bytes:Buffer.byteLength(content,"utf8"),validation});
    res.json({ok:true,file:"hotspot/login.html",backup:old?backupName:null,validation});
  }catch(e){res.status(502).json({ok:false,error:"HOTSPOT_LOGIN_PUBLISH_FAILED",detail:e.message});}
  finally{try{await ros?.close();}catch{}}
});

app.get("/api/routers/:id/hotspot-login/backups",auth,async(req,res)=>{
  let ros;
  try{
    const r=await getRouterForUser(req,req.params.id);
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt(r.password_enc),tls:r.tls});
    await ros.connect();
    const files=await ros.command("/file/print",[]);
    const backups=files.filter(f=>/^hotspot\/login\.html\.micromax-[A-Za-z0-9_.-]+\.bak$/.test(String(f.name||""))).map(f=>({name:f.name,size:Number(f.size||0),creationTime:f.creation_time||f["creation-time"]||null})).sort((a,b)=>String(b.creationTime).localeCompare(String(a.creationTime)));
    res.json({backups});
  }catch(e){res.status(502).json({error:"HOTSPOT_LOGIN_BACKUPS_FAILED",detail:e.message});}
  finally{try{await ros?.close();}catch{}}
});

app.post("/api/routers/:id/hotspot-login/restore",auth,role("admin"),async(req,res)=>{
  let ros;
  try{
    const r=await getRouterForUser(req,req.params.id);
    const backup=String(req.body.backupName||"").trim();
    if(!/^hotspot\/login\.html\.micromax-[A-Za-z0-9_.-]+\.bak$/.test(backup)) return res.status(400).json({error:"INVALID_BACKUP_NAME"});
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt(r.password_enc),tls:r.tls});
    await ros.connect();
    const b=await ros.command("/file/print",[`?name=${backup}`]);
    const content=String(b[0]?.contents||"");
    const validation=validateLoginHtml(content);
    if(!validation.valid) return res.status(400).json({error:"BACKUP_INCOMPATIBLE",validation});
    const current=await ros.command("/file/print",["?name=hotspot/login.html"]);
    const target=current[0]?.[".id"] || current[0]?.id;
    if(!target) throw Error("LOGIN_HTML_NOT_FOUND");
    await ros.command("/file/set",[`=.id=${target}`,`=contents=${content}`]);
    await audit(req.user.sub,"RESTORE","hotspot_login",req.params.id,{backup});
    res.json({ok:true,restoredFrom:backup,validation});
  }catch(e){res.status(502).json({ok:false,error:"HOTSPOT_LOGIN_RESTORE_FAILED",detail:e.message});}
  finally{try{await ros?.close();}catch{}}
});

const routerCommands={dhcp:"/ip/dhcp-server/lease/print",arp:"/ip/arp/print",dns:"/ip/dns/print",ip:"/ip/address/print",routes:"/ip/route/print",firewall:"/ip/firewall/filter/print",queues:"/queue/simple/print",logs:"/log/print"};
for(const [key,cmd] of Object.entries(routerCommands)) app.get(`/api/routers/:id/${key}`,auth,async(req,res)=>{try{res.json({items:await withRos(req,req.params.id,ros=>ros.command(cmd,[]))});}catch(e){res.status(502).json({error:"ROUTER_QUERY_FAILED",detail:e.message});}});

// Smart preflight: validates a bulk-card request without creating or changing anything.
app.post("/api/routers/:id/cards/preflight",auth,async(req,res)=>{
  let ros=null;
  try{
    const requested=Number(req.body.count);
    const count=Math.min(Math.max(Number.isFinite(requested)?Math.floor(requested):1,1),5000);
    const prefix=String(req.body.prefix||"MM").replace(/[^a-zA-Z0-9]/g,"").slice(0,12)||"MM";
    const usernameDigits=Math.min(Math.max(Number.isFinite(Number(req.body.usernameDigits))?Math.floor(Number(req.body.usernameDigits)):6,0),20);
    const usernameLetters=Math.min(Math.max(Number.isFinite(Number(req.body.usernameLetters))?Math.floor(Number(req.body.usernameLetters)):0,0),12);
    const planId=String(req.body.planId||"").trim();
    if(usernameDigits+usernameLetters===0)throw Error("USERNAME_FORMAT_EMPTY");
    const planQ=await pool.query(`SELECT p.*,hp.duration_minutes,hp.rate_limit,hp.session_timeout,hp.idle_timeout,hp.shared_users FROM hotspot_plans p LEFT JOIN hotspot_profiles hp ON hp.router_id=p.router_id AND hp.name=p.profile_name WHERE p.id=$1 AND p.router_id=$2 AND p.active=true`,[planId,req.params.id]);
    if(!planQ.rowCount)throw Error("PLAN_REQUIRED");
    const plan=planQ.rows[0];
    const routerQ=await pool.query("SELECT id,host,port,username,tls FROM routers WHERE id=$1 AND user_id=$2",[req.params.id,req.user.sub]);
    if(!routerQ.rowCount)throw Error("ROUTER_NOT_FOUND");
    const r=routerQ.rows[0];
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt((await pool.query("SELECT password_enc FROM routers WHERE id=$1",[req.params.id])).rows[0].password_enc),tls:r.tls});
    await ros.connect();
    const profiles=await ros.command("/ip/hotspot/user/profile/print",[]);
    const profileVerified=profiles.some(x=>String(x.name||"")===String(plan.profile_name));
    if(!profileVerified)throw Error("HOTSPOT_PROFILE_NOT_FOUND");
    const existingRos=await ros.command("/ip/hotspot/user/print",[]);
    const dbQ=await pool.query("SELECT username FROM cards WHERE router_id=$1",[req.params.id]);
    const used=new Set(existingRos.map(x=>String(x.name||"")));
    dbQ.rows.forEach(x=>used.add(String(x.username||"")));
    const space=Math.pow(26,usernameLetters)*Math.pow(10,usernameDigits);
    const available=Math.max(0,space-usedPrefixCount(used,prefix,usernameLetters,usernameDigits));
    const enough=available>=count;
    res.json({
      ready:enough,
      request:{count,prefix,letters:usernameLetters,digits:usernameDigits,totalLength:prefix.length+usernameLetters+usernameDigits,planId,planName:plan.name,price:Number(plan.price),currency:plan.currency},
      validation:{routerVerified:true,profileVerified,duplicateCheck:true,usernameCollisionCheck:true},
      usernamePool:{theoretical:space,usedMatchingPrefix:space-available,available,required:count},
      warnings:enough?[]:["USERNAME_POOL_TOO_SMALL"],
      note:"Preflight does not create, delete, modify, or sell any card."
    });
  }catch(e){res.status(400).json({ready:false,error:"CARD_PREFLIGHT_FAILED",detail:e.message});}
  finally{try{await ros?.close();}catch{}}
});


// QR HotSpot compatibility check: validates the real portal URL and RouterOS login method
// before a QR is treated as a connection QR. It never changes MikroTik configuration.
app.post("/api/routers/:id/qr-preflight",auth,async(req,res)=>{
  let ros=null;
  try{
    const portalUrl=String(req.body.portalUrl||"").trim();
    const planId=String(req.body.planId||"").trim();
    if(!portalUrl) return res.status(400).json({ready:false,error:"HOTSPOT_URL_REQUIRED"});
    let url;
    try{ url=new URL(portalUrl); }catch{ return res.status(400).json({ready:false,error:"INVALID_HOTSPOT_URL"}); }
    if(!["http:","https:"].includes(url.protocol)) return res.status(400).json({ready:false,error:"HOTSPOT_URL_MUST_BE_HTTP_OR_HTTPS"});
    const routerQ=await pool.query("SELECT * FROM routers WHERE id=$1 AND user_id=$2",[req.params.id,req.user.sub]);
    if(!routerQ.rowCount)throw Error("ROUTER_NOT_FOUND");
    const r=routerQ.rows[0];
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt(r.password_enc),tls:r.tls});
    await ros.connect();
    const hotspotProfiles=await ros.command("/ip/hotspot/profile/print",[]);
    const hotspotServers=await ros.command("/ip/hotspot/print",[]);
    const loginBy=[...new Set(hotspotProfiles.flatMap(x=>String(x["login-by"]||x.login_by||"").split(",").map(v=>v.trim()).filter(Boolean)))];
    const serverAddress=hotspotProfiles.find(x=>x["hotspot-address"]||x["dns-name"]||x["dns-name"])||{};
    const controllerHost=String(url.host);
    let portalStatus=null,portalReachable=false,html="",fetchError=null;
    try{
      const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),5000);
      const response=await fetch(url,{redirect:"follow",signal:controller.signal,headers:{"User-Agent":"MICRO-MAX-HotSpot-QR-Check/1.0"}});
      clearTimeout(timer); portalStatus=response.status; html=(await response.text()).slice(0,500000); portalReachable=response.ok;
    }catch(e){fetchError=e.message||"PORTAL_UNREACHABLE";}
    const hasLoginForm=/<form[^>]+action=["'][^"']*\/login/i.test(html)||/<form[^>]*>/i.test(html)&&/name=["']username["']/i.test(html)&&/name=["']password["']/i.test(html);
    const hasAutoSubmit=/\.submit\s*\(|requestSubmit\s*\(/i.test(html);
    const papAllowed=loginBy.some(v=>v.toLowerCase().includes("http-pap"));
    const httpsAllowed=loginBy.some(v=>v.toLowerCase().includes("https"));
    const chapOnly=loginBy.length>0 && loginBy.every(v=>v.toLowerCase().includes("http-chap")||v.toLowerCase().includes("cookie"));
    let mode="portal-prefill";
    let ready=portalReachable && hasLoginForm && (papAllowed || httpsAllowed || !chapOnly);
    if(ready && hasAutoSubmit && (papAllowed||httpsAllowed)) mode="auto-submit";
    const warnings=[];
    if(!portalReachable)warnings.push("HOTSPOT_PORTAL_NOT_REACHABLE_FROM_API");
    if(portalReachable&&!hasLoginForm)warnings.push("LOGIN_FORM_NOT_DETECTED");
    if(chapOnly)warnings.push("CHAP_REQUIRES_LOGIN_PAGE_CHALLENGE_HANDLING");
    if(mode==="portal-prefill")warnings.push("QR_OPENS_REAL_HOTSPOT_LOGIN_PAGE;_AUTO_LOGIN_REQUIRES_COMPATIBLE_LOGIN_HTML");
    res.json({
      ready,mode,portal:{url:portalUrl,host:controllerHost,status:portalStatus,reachable:portalReachable,loginFormDetected:hasLoginForm,autoSubmitDetected:hasAutoSubmit,fetchError},
      router:{verified:true,hotspotServers:hotspotServers.length,loginBy,papAllowed,httpsAllowed,chapOnly},
      recommendedQr:`${portalUrl.replace(/\/$/,"")}?username={USERNAME}&password={PASSWORD}&dst=${encodeURIComponent(url.origin+"/")}`,
      planId:planId||null,
      note:"MICRO-MAX never changes MikroTik login settings during QR preflight. Auto-submit is only marked ready when the real login page already contains compatible form handling."
    });
  }catch(e){res.status(400).json({ready:false,error:"QR_PREFLIGHT_FAILED",detail:e.message});}
  finally{try{await ros?.close();}catch{}}
});

function usedPrefixCount(used,prefix,letters,digits){
  let n=0; const re=new RegExp(`^${prefix}[A-HJ-NP-Z]{${letters}}[0-9]{${digits}}$`);
  for(const u of used)if(re.test(u))n++;
  return n;
}

app.post("/api/routers/:id/cards/generate",auth,async(req,res)=>{
  const requested=Number(req.body.count);
  const count=Math.min(Math.max(Number.isFinite(requested)?Math.floor(requested):1,1),5000);
  const prefix=String(req.body.prefix||"MM").replace(/[^a-zA-Z0-9]/g,"").slice(0,12)||"MM";
  const usernameDigits=Math.min(Math.max(Number.isFinite(Number(req.body.usernameDigits))?Math.floor(Number(req.body.usernameDigits)):6,0),20);
  const usernameLetters=Math.min(Math.max(Number.isFinite(Number(req.body.usernameLetters))?Math.floor(Number(req.body.usernameLetters)):0,0),12);
  const planId=String(req.body.planId||"").trim();
  const portalUrl=String(req.body.portalUrl||"").trim();
  const batchId=crypto.randomUUID();
  const created=[];
  let ros=null;
  try{
    const planQ=await pool.query(`SELECT p.*,hp.duration_minutes,hp.rate_limit,hp.session_timeout,hp.idle_timeout,hp.shared_users
      FROM hotspot_plans p LEFT JOIN hotspot_profiles hp ON hp.router_id=p.router_id AND hp.name=p.profile_name
      WHERE p.id=$1 AND p.router_id=$2 AND p.active=true`,[planId,req.params.id]);
    if(!planQ.rowCount)throw Error("PLAN_REQUIRED");
    const plan=planQ.rows[0];
    if(Number(plan.price)<0)throw Error("INVALID_PLAN_PRICE");
    let portal; try{ portal=new URL(portalUrl); }catch{ throw Error("INVALID_HOTSPOT_URL"); }
    if(!["http:","https:"].includes(portal.protocol))throw Error("HOTSPOT_URL_MUST_BE_HTTP_OR_HTTPS");
    const qrBase=portalUrl.replace(/\/$/,"");
    // Smart preflight: validate the real MikroTik profile before generating anything.
    const routerQ=await pool.query("SELECT * FROM routers WHERE id=$1 AND user_id=$2",[req.params.id,req.user.sub]);
    if(!routerQ.rowCount)throw Error("ROUTER_NOT_FOUND");
    const r=routerQ.rows[0];
    ros=new RouterOS({host:r.host,port:r.port,username:r.username,password:decrypt(r.password_enc),tls:r.tls});
    await ros.connect();
    const profiles=await ros.command("/ip/hotspot/user/profile/print",[]);
    if(!profiles.some(x=>x.name===plan.profile_name))throw Error("HOTSPOT_PROFILE_NOT_FOUND");

    // Smart collision check: reserve usernames locally and compare against existing MikroTik users.
    const existingRos=await ros.command("/ip/hotspot/user/print",[]);
    const used=new Set(existingRos.map(x=>String(x.name||"")));
    const dbExisting=await pool.query("SELECT username FROM cards WHERE router_id=$1",[req.params.id]);
    for(const row of dbExisting.rows)used.add(String(row.username));
    const candidates=[];
    let attempts=0;
    const digitsPool="0123456789", lettersPool="ABCDEFGHJKLMNPQRSTUVWXYZ";
    const pick=(pool,n)=>{let out="";while(out.length<n){const b=crypto.randomBytes(n);for(const x of b){out+=pool[x%pool.length];if(out.length===n)break;}}return out;};
    if(usernameDigits+usernameLetters===0)throw Error("USERNAME_FORMAT_EMPTY");
    while(candidates.length<count && attempts<count*30){
      attempts++;
      const username=`${prefix}${pick(lettersPool,usernameLetters)}${pick(digitsPool,usernameDigits)}`;
      if(used.has(username))continue;
      used.add(username);
      const password=crypto.randomBytes(8).toString("base64url").replace(/[^A-Za-z0-9]/g,"").slice(0,10);
      candidates.push({username,password});
    }
    if(candidates.length!==count)throw Error("USERNAME_POOL_EXHAUSTED");

    // Create on MikroTik with a batch marker. If anything fails, remove only this batch.
    for(const c of candidates){
      await ros.command("/ip/hotspot/user/add",[
        `=name=${c.username}`,`=password=${c.password}`,`=profile=${plan.profile_name}`,`=comment=MICRO-MAX:${batchId}`
      ]);
      created.push(c);
    }

    // Persist in DB in chunks so large batches do not create one giant SQL statement.
    const client=await pool.connect();
    try{
      await client.query("BEGIN");
      for(let i=0;i<created.length;i+=250){
        const chunk=created.slice(i,i+250);
        const values=[]; const params=[];
        chunk.forEach((c,j)=>{
          const o=j*10; const id=crypto.randomUUID();
          values.push(`($${o+1},$${o+2},$${o+3},$${o+4},$${o+5},$${o+6},$${o+7},$${o+8},$${o+9},$${o+10})`);
          const qrContent=`${qrBase}?username=${encodeURIComponent(c.username)}&password=${encodeURIComponent(c.password)}&dst=${encodeURIComponent(portal.origin+"/")}`;
          params.push(id,req.params.id,c.username,c.password,plan.profile_name,plan.price,plan.id,plan.currency,batchId,qrContent);
        });
        await client.query(`INSERT INTO cards(id,router_id,username,password,profile,price,plan_id,price_currency,batch_id,qr_content) VALUES ${values.join(",")}`,params);
      }
      await client.query("COMMIT");
    }catch(e){
      await client.query("ROLLBACK");
      // Best-effort cleanup on MikroTik using the unique batch marker.
      try{
        const batchUsers=await ros.command("/ip/hotspot/user/print",[`?comment=MICRO-MAX:${batchId}`]);
        for(const u of batchUsers){ if(u[".id"]) await ros.command("/ip/hotspot/user/remove",[`=.id=${u[".id"]}`]); }
      }catch{}
      throw e;
    }finally{client.release();}

    await audit(req.user.sub,"CREATE","cards",req.params.id,{count,planId,price:Number(plan.price),currency:plan.currency,batchId,smartValidation:true,usernameDigits,usernameLetters});
    res.status(201).json({
      success:true,count,batchId,pricingSource:"micromax_plan",planId,planName:plan.name,price:Number(plan.price),currency:plan.currency,
      usernameFormat:{prefix,letters:usernameLetters,digits:usernameDigits,totalLength:prefix.length+usernameLetters+usernameDigits},
      validation:{profileVerified:true,duplicateCheck:true,usernameCollisionCheck:true,routerVerified:true},
      cards:created.map(c=>({username:c.username,password:c.password,profile:plan.profile_name,planId:plan.id,planName:plan.name,price:Number(plan.price),currency:plan.currency,durationMinutes:Number(plan.duration_minutes||0),rateLimit:plan.rate_limit||"",sessionTimeout:plan.session_timeout||"",idleTimeout:plan.idle_timeout||"",sharedUsers:Number(plan.shared_users||1),qrContent:`${qrBase}?username=${encodeURIComponent(c.username)}&password=${encodeURIComponent(c.password)}&dst=${encodeURIComponent(portal.origin+"/")}`}))
    });
  }catch(e){
    // If RouterOS creation failed before DB commit, clean up this batch marker.
    if(ros && created.length){try{const batchUsers=await ros.command("/ip/hotspot/user/print",[`?comment=MICRO-MAX:${batchId}`]);for(const u of batchUsers){if(u[".id"])await ros.command("/ip/hotspot/user/remove",[`=.id=${u[".id"]}`]);}}catch{}}
    res.status(400).json({error:"CARD_GENERATION_FAILED",detail:e.message,batchId,generatedBeforeFailure:created.length});
  }finally{try{await ros?.close();}catch{}}
});

app.get("/api/cards",auth,async(req,res)=>{const r=await pool.query("SELECT c.*,r.name router_name,p.name plan_name,p.currency plan_currency,hp.duration_minutes profile_duration_minutes,hp.rate_limit profile_rate_limit,hp.session_timeout profile_session_timeout,hp.idle_timeout profile_idle_timeout,hp.shared_users profile_shared_users FROM cards c JOIN routers r ON r.id=c.router_id LEFT JOIN hotspot_profiles hp ON hp.router_id=c.router_id AND hp.name=c.profile LEFT JOIN hotspot_plans p ON p.id=c.plan_id WHERE r.user_id=$1 ORDER BY c.created_at DESC LIMIT 1000",[req.user.sub]);res.json({cards:r.rows});});

// Smart Batch Center: reporting and safe lifecycle operations. Does not change card pricing/profile/username.
app.get("/api/card-batches",auth,async(req,res)=>{try{const r=await pool.query(`SELECT c.batch_id,MIN(c.created_at) created_at,COUNT(*)::int total,COUNT(*) FILTER(WHERE c.status='available')::int available,COUNT(*) FILTER(WHERE c.status='sold')::int sold,COUNT(*) FILTER(WHERE c.status='used')::int used,COUNT(*) FILTER(WHERE c.status='expired')::int expired,COUNT(*) FILTER(WHERE c.status='disabled')::int disabled,MIN(c.plan_id) plan_id,MIN(p.name) plan_name,MIN(r.name) router_name,MIN(c.price_currency) currency,MIN(c.price) price FROM cards c JOIN routers r ON r.id=c.router_id LEFT JOIN hotspot_plans p ON p.id=c.plan_id WHERE r.user_id=$1 AND c.batch_id IS NOT NULL GROUP BY c.batch_id ORDER BY MIN(c.created_at) DESC LIMIT 500`,[req.user.sub]);res.json({batches:r.rows});}catch(e){res.status(500).json({error:"BATCH_QUERY_FAILED",detail:e.message});}});
app.get("/api/card-batches/:id",auth,async(req,res)=>{try{const r=await pool.query(`SELECT c.*,r.name router_name,p.name plan_name,p.currency plan_currency FROM cards c JOIN routers r ON r.id=c.router_id LEFT JOIN hotspot_plans p ON p.id=c.plan_id WHERE c.batch_id=$1 AND r.user_id=$2 ORDER BY c.created_at DESC`,[req.params.id,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:"BATCH_NOT_FOUND"});res.json({batchId:req.params.id,cards:r.rows});}catch(e){res.status(500).json({error:"BATCH_DETAIL_FAILED",detail:e.message});}});
app.post("/api/card-batches/:id/disable",auth,async(req,res)=>{const client=await pool.connect();let routerId=null;try{await client.query("BEGIN");const q=await client.query(`SELECT c.id,c.router_id,c.username,c.status FROM cards c JOIN routers r ON r.id=c.router_id WHERE c.batch_id=$1 AND r.user_id=$2 FOR UPDATE`,[req.params.id,req.user.sub]);if(!q.rowCount)throw Error("BATCH_NOT_FOUND");routerId=q.rows[0].router_id;const candidates=q.rows.filter(x=>["available","expired"].includes(x.status));for(const c of candidates)await client.query("UPDATE cards SET status='disabled' WHERE id=$1",[c.id]);await client.query("COMMIT");await audit(req.user.sub,"DISABLE","card_batch",req.params.id,{changed:candidates.length,protected:q.rows.length-candidates.length});res.json({success:true,batchId:req.params.id,disabled:candidates.length,protected:q.rows.length-candidates.length});}catch(e){await client.query("ROLLBACK");res.status(400).json({error:e.message});}finally{client.release();}});
app.delete("/api/card-batches/:id",auth,async(req,res)=>{const client=await pool.connect();let ros=null;try{await client.query("BEGIN");const q=await client.query(`SELECT c.*,r.host,r.port,r.username router_username,r.password_enc,r.tls FROM cards c JOIN routers r ON r.id=c.router_id WHERE c.batch_id=$1 AND r.user_id=$2 FOR UPDATE`,[req.params.id,req.user.sub]);if(!q.rowCount)throw Error("BATCH_NOT_FOUND");const protectedCards=q.rows.filter(x=>!["available","expired","disabled"].includes(x.status));if(protectedCards.length)throw Error("BATCH_CONTAINS_SOLD_OR_USED_CARDS");const deletable=q.rows.filter(x=>["available","expired","disabled"].includes(x.status));for(const c of deletable)await client.query("DELETE FROM cards WHERE id=$1",[c.id]);await client.query("COMMIT");try{const r=q.rows[0];ros=new RouterOS({host:r.host,port:r.port,username:r.router_username,password:decrypt(r.password_enc),tls:r.tls});await ros.connect();const users=await ros.command("/ip/hotspot/user/print",[`?comment=MICRO-MAX:${req.params.id}`]);for(const u of users){if(u[".id"])await ros.command("/ip/hotspot/user/remove",[`=.id=${u[".id"]}`]);}}catch{}await audit(req.user.sub,"DELETE","card_batch",req.params.id,{deleted:deletable.length});res.json({success:true,batchId:req.params.id,deleted:deletable.length});}catch(e){await client.query("ROLLBACK");res.status(400).json({error:e.message});}finally{client.release();try{await ros?.close();}catch{}}});
app.get("/api/card-batches/:id/csv",auth,async(req,res)=>{try{const r=await pool.query(`SELECT c.username,c.password,c.profile,c.status,c.price,c.price_currency,c.plan_id,c.batch_id,c.created_at,c.sold_at,r.name router_name,p.name plan_name FROM cards c JOIN routers r ON r.id=c.router_id LEFT JOIN hotspot_plans p ON p.id=c.plan_id WHERE c.batch_id=$1 AND r.user_id=$2 ORDER BY c.created_at`,[req.params.id,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:"BATCH_NOT_FOUND"});const esc=v=>`"${String(v??"").replaceAll('"','""')}"`;const lines=["username,password,profile,status,price,currency,plan_id,batch_id,created_at,sold_at,router,plan"];for(const x of r.rows)lines.push([x.username,x.password,x.profile,x.status,x.price,x.price_currency,x.plan_id,x.batch_id,x.created_at?.toISOString?.()||x.created_at,x.sold_at?.toISOString?.()||x.sold_at,x.router_name,x.plan_name].map(esc).join(","));res.setHeader("Content-Type","text/csv; charset=utf-8");res.setHeader("Content-Disposition",`attachment; filename="micromax-batch-${req.params.id}.csv"`);res.send("\uFEFF"+lines.join("\n"));}catch(e){res.status(500).json({error:"BATCH_CSV_FAILED",detail:e.message});}});

app.post("/api/sales",auth,async(req,res)=>{const {cardId,paymentMethod="cash",reference=null}=req.body;const requestedAmount=req.body.amount; if(!cardId)return res.status(400).json({error:"CARD_REQUIRED"});if(paymentMethod!=="cash" && process.env.ENABLE_ONLINE_PAYMENTS!=="true")return res.status(403).json({error:"ONLINE_PAYMENTS_DISABLED"});const client=await pool.connect();try{await client.query("BEGIN");const c=await client.query("SELECT c.*,hp.duration_minutes profile_duration_minutes FROM cards c JOIN routers r ON r.id=c.router_id LEFT JOIN hotspot_profiles hp ON hp.router_id=c.router_id AND hp.name=c.profile WHERE c.id=$1 AND r.user_id=$2 FOR UPDATE",[cardId,req.user.sub]);if(!c.rowCount||c.rows[0].status!=="available")throw Error("CARD_NOT_AVAILABLE");const card=c.rows[0];const planPrice=Number(card.price||0);const numericAmount=planPrice;if(!Number.isFinite(numericAmount)||numericAmount<=0)return res.status(400).json({error:"PLAN_PRICE_NOT_SET",plan:card.plan_name||card.profile});const saleId=crypto.randomUUID();const finalCash=paymentMethod==="cash";await client.query("UPDATE cards SET status='sold',sold_at=now() WHERE id=$1",[cardId]);await client.query("INSERT INTO sales(id,card_id,seller_id,amount,payment_method,payment_status,reference) VALUES($1,$2,$3,$4,$5,$6,$7)",[saleId,cardId,req.user.sub,numericAmount,paymentMethod,finalCash?"success":"pending",reference]);await client.query("COMMIT");await audit(req.user.sub,"CREATE","sale",saleId,{cardId,amount:numericAmount,paymentMethod,paymentStatus:finalCash?"success":"pending",profile:card.profile,plan:card.plan_name||null,profileDurationMinutes:Number(card.profile_duration_minutes||0)});res.status(201).json({saleId,status:finalCash?"success":"pending",amount:numericAmount,profile:card.profile,durationMinutes:Number(card.profile_duration_minutes||0),card:finalCash?{username:card.username,password:card.password,profile:card.profile,price:numericAmount}:undefined});}catch(e){await client.query("ROLLBACK");res.status(400).json({error:e.message});}finally{client.release();}});
app.get("/api/sales",auth,async(req,res)=>{const r=await pool.query("SELECT s.*,c.username card_username FROM sales s LEFT JOIN cards c ON c.id=s.card_id WHERE s.seller_id=$1 ORDER BY s.created_at DESC LIMIT 1000",[req.user.sub]);res.json({sales:r.rows});});
app.post("/api/payments/intents",auth,async(req,res)=>{
  const { saleId, provider="cash" } = req.body;
  if(!saleId||!provider)return res.status(400).json({error:"INVALID_INPUT"});
  const sale=await pool.query("SELECT s.*,c.username card_username FROM sales s LEFT JOIN cards c ON c.id=s.card_id WHERE s.id=$1 AND s.seller_id=$2",[saleId,req.user.sub]);
  if(!sale.rowCount)return res.status(404).json({error:"SALE_NOT_FOUND"});
  const s=sale.rows[0];
  if(s.payment_status!=="pending")return res.status(409).json({error:"SALE_ALREADY_FINALIZED",status:s.payment_status});
  const id=crypto.randomUUID();

  if(provider === "cash"){
    await pool.query("INSERT INTO payments(id,sale_id,provider,status,amount) VALUES($1,$2,$3,'success',$4)",[id,saleId,provider,s.amount]);
    await pool.query("UPDATE sales SET payment_status='success' WHERE id=$1",[saleId]);
    await audit(req.user.sub,"UPDATE","payment",id,{status:"success",provider});
    return res.status(201).json({paymentId:id,status:"success",provider,card:{username:s.card_username,password:(await pool.query("SELECT password FROM cards WHERE id=$1",[s.card_id])).rows[0]?.password||null}});
  }

  if(provider !== "binance_pay"){
    await pool.query("INSERT INTO payments(id,sale_id,provider,status,amount) VALUES($1,$2,$3,'pending',$4)",[id,saleId,provider,s.amount]);
    return res.status(201).json({paymentId:id,status:"pending",provider,notice:"هذا المزود ما زال يحتاج تكامل API وWebhook رسمي."});
  }

  if(!binancePayConfigured()){await pool.query("UPDATE cards SET status='available',sold_at=NULL WHERE id=(SELECT card_id FROM sales WHERE id=$1) AND status='sold'",[saleId]);return res.status(503).json({error:"BINANCE_PAY_NOT_CONFIGURED",message:"أضف Binance Pay Certificate SN + Secret Key في بيئة السيرفر، وليس داخل Android."});}
  const merchantTradeNo=`MM${Date.now()}${crypto.randomBytes(4).toString("hex").toUpperCase()}`.slice(0,32);
  try{
    const created=await createBinancePayOrder({merchantTradeNo,amount:s.amount,currency:process.env.BINANCE_PAY_CURRENCY||"USDT",referenceGoodsId:s.card_id||saleId,goodsName:`MICRO-MAX Card ${s.card_username||""}`.trim(),goodsDetail:"Hotspot access card"});
    const d=created.data||{};
    await pool.query("INSERT INTO payments(id,sale_id,provider,status,external_reference,amount,raw) VALUES($1,$2,'binance_pay','pending',$3,$4,$5)",[id,saleId,merchantTradeNo,s.amount,JSON.stringify(created)]);
    await audit(req.user.sub,"CREATE","payment",id,{provider:"binance_pay",merchantTradeNo});
    return res.status(201).json({paymentId:id,status:"pending",provider:"binance_pay",merchantTradeNo,prepayId:d.prepayId||null,checkoutUrl:d.checkoutUrl||null,qrContent:d.qrContent||null,qrcodeLink:d.qrcodeLink||null,deeplink:d.deeplink||null,universalUrl:d.universalUrl||null});
  }catch(e){
    await pool.query("INSERT INTO payments(id,sale_id,provider,status,external_reference,amount,raw) VALUES($1,$2,'binance_pay','failed',$3,$4,$5)",[id,saleId,merchantTradeNo,s.amount,JSON.stringify(e.providerResponse||{error:e.message})]);
    await pool.query("UPDATE cards SET status='available',sold_at=NULL WHERE id=(SELECT card_id FROM sales WHERE id=$1) AND status='sold'",[saleId]);
    await pool.query("UPDATE sales SET payment_status='failed' WHERE id=$1",[saleId]);
    return res.status(502).json({error:"BINANCE_PAY_CREATE_FAILED",detail:e.message});
  }
});

app.post("/api/payments/:id/sync",auth,async(req,res)=>{
  const p=await pool.query("SELECT p.*,s.seller_id,s.amount sale_amount FROM payments p JOIN sales s ON s.id=p.sale_id WHERE p.id=$1 AND s.seller_id=$2",[req.params.id,req.user.sub]);
  if(!p.rowCount)return res.status(404).json({error:"PAYMENT_NOT_FOUND"});
  const payment=p.rows[0];
  if(payment.provider!=="binance_pay")return res.status(400).json({error:"SYNC_NOT_SUPPORTED_FOR_PROVIDER"});
  try{
    const q=await queryBinancePayOrder({merchantTradeNo:payment.external_reference});
    const d=q.data||{};
    const paid=d.status==="PAID" && Number(d.totalFee)===Number(payment.sale_amount) && String(d.currency||"").toUpperCase()===(process.env.BINANCE_PAY_CURRENCY||"USDT").toUpperCase();
    let status=paid?"success":(["CANCELED","ERROR","EXPIRED","REFUNDED"].includes(d.status)?"failed":"pending");
    await pool.query("UPDATE payments SET status=$1,raw=$2,updated_at=now() WHERE id=$3",[status,JSON.stringify(q),payment.id]);
    await pool.query("UPDATE sales SET payment_status=$1 WHERE id=$2",[status,payment.sale_id]);
    if(status==="failed")await pool.query("UPDATE cards SET status='available',sold_at=NULL WHERE id=(SELECT card_id FROM sales WHERE id=$1) AND status='sold'",[payment.sale_id]);
    let card=null;
    if(status==="success"){
      const cr=await pool.query("SELECT c.username,password,profile FROM cards c JOIN sales s ON s.card_id=c.id WHERE s.id=$1",[payment.sale_id]);
      card=cr.rows[0]||null;
      await audit(req.user.sub,"UPDATE","payment",payment.id,{status,binanceStatus:d.status,transactionId:d.transactionId||null});
    }
    return res.json({paymentId:payment.id,status,binanceStatus:d.status,transactionId:d.transactionId||null,totalFee:d.totalFee||null,currency:d.currency||null,card});
  }catch(e){return res.status(502).json({error:"BINANCE_PAY_QUERY_FAILED",detail:e.message});}
});

app.post("/api/webhooks/binance-pay",async(req,res)=>{
  try{
    const raw=Buffer.isBuffer(req.rawBody)?req.rawBody.toString("utf8"):JSON.stringify(req.body||{});
    const headerSignature=req.headers["binancepay-signature"] || req.headers["binance-pay-signature"];
    const headerTimestamp=req.headers["binancepay-timestamp"] || req.headers["binance-pay-timestamp"];
    const headerNonce=req.headers["binancepay-nonce"] || req.headers["binance-pay-nonce"];
    if(!verifyBinancePayNotification({body:raw,timestamp:headerTimestamp,nonce:headerNonce,signature:headerSignature})){
      return res.status(401).json({returnCode:"FAIL",returnMessage:"INVALID_SIGNATURE"});
    }
    const payload=req.body||{};
    if(payload.bizType!=="PAY")return res.status(200).json({returnCode:"SUCCESS",returnMessage:null});
    const data=typeof payload.data==="string"?JSON.parse(payload.data):payload.data||{};
    const merchantTradeNo=data.merchantTradeNo;
    if(!merchantTradeNo)return res.status(200).json({returnCode:"SUCCESS",returnMessage:null});
    const p=await pool.query("SELECT p.*,s.amount sale_amount,s.card_id FROM payments p JOIN sales s ON s.id=p.sale_id WHERE p.provider='binance_pay' AND p.external_reference=$1",[merchantTradeNo]);
    if(!p.rowCount)return res.status(200).json({returnCode:"SUCCESS",returnMessage:null});
    // Never trust the notification itself for fulfillment. Re-query Binance and verify amount/currency.
    const q=await queryBinancePayOrder({merchantTradeNo});
    const d=q.data||{};
    const row=p.rows[0];
    const paid=d.status==="PAID" && Number(d.totalFee)===Number(row.sale_amount) && String(d.currency||"").toUpperCase()===(process.env.BINANCE_PAY_CURRENCY||"USDT").toUpperCase();
    const status=paid?"success":(["CANCELED","ERROR","EXPIRED","REFUNDED"].includes(d.status)?"failed":"pending");
    await pool.query("UPDATE payments SET status=$1,raw=$2,updated_at=now() WHERE id=$3",[status,JSON.stringify(q),row.id]);
    await pool.query("UPDATE sales SET payment_status=$1 WHERE id=$2",[status,row.sale_id]);
    if(status==="failed")await pool.query("UPDATE cards SET status='available',sold_at=NULL WHERE id=$1 AND status='sold'",[row.card_id]);
    return res.status(200).json({returnCode:"SUCCESS",returnMessage:null});
  }catch(e){
    console.error("Binance Pay webhook error",e);
    return res.status(200).json({returnCode:"FAIL",returnMessage:"Temporary processing error"});
  }
});

app.get("/api/binance-pay/status",auth,role("admin"),(req,res)=>res.json({configured:binancePayConfigured(),currency:process.env.BINANCE_PAY_CURRENCY||"USDT",terminalType:process.env.BINANCE_PAY_TERMINAL_TYPE||"APP"}));
app.post("/api/payments/:id/status",auth,role("admin"),async(req,res)=>{const status=String(req.body.status||"pending");if(!["pending","success","failed","refunded"].includes(status))return res.status(400).json({error:"INVALID_STATUS"});const p=await pool.query("UPDATE payments SET status=$1,updated_at=now() WHERE id=$2 RETURNING *",[status,req.params.id]);if(!p.rowCount)return res.status(404).json({error:"PAYMENT_NOT_FOUND"});await pool.query("UPDATE sales SET payment_status=$1 WHERE id=$2",[status,p.rows[0].sale_id]);await audit(req.user.sub,"UPDATE","payment",req.params.id,{status});res.json(p.rows[0]);});

app.get("/api/reports/sales",auth,async(req,res)=>{const r=await pool.query("SELECT date_trunc('day',created_at) day,count(*) sales,sum(amount) revenue,count(*) FILTER(WHERE payment_status='success') paid,count(*) FILTER(WHERE payment_status='failed') failed FROM sales WHERE seller_id=$1 GROUP BY 1 ORDER BY 1 DESC LIMIT 90",[req.user.sub]);res.json({rows:r.rows});});
app.get("/api/reports/sales.csv",auth,async(req,res)=>{const r=await pool.query("SELECT created_at,amount,payment_method,payment_status,reference FROM sales WHERE seller_id=$1 ORDER BY created_at DESC",[req.user.sub]);const lines=["created_at,amount,payment_method,payment_status,reference",...r.rows.map(x=>[x.created_at.toISOString(),x.amount,x.payment_method,x.payment_status,x.reference||""].map(v=>`"${String(v).replaceAll('"','""')}"`).join(","))];res.type("text/csv").send(lines.join("\n"));});
app.get("/api/reports/sales.pdf",auth,async(req,res)=>{const r=await pool.query("SELECT created_at,amount,payment_method,payment_status FROM sales WHERE seller_id=$1 ORDER BY created_at DESC LIMIT 200",[req.user.sub]);res.type("application/pdf");const doc=new PDFDocument({margin:40});doc.pipe(res);doc.fontSize(20).text("MICRO-MAX - Sales Report");doc.moveDown();for(const x of r.rows)doc.fontSize(10).text(`${x.created_at.toISOString()} | ${x.amount} | ${x.payment_method} | ${x.payment_status}`);doc.end();});

app.get("/api/audit",auth,role("admin"),async(req,res)=>{const r=await pool.query("SELECT a.*,u.email FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 500");res.json({logs:r.rows});});
app.get("/api/users",auth,role("admin"),async(req,res)=>{const r=await pool.query("SELECT id,email,role,created_at FROM users ORDER BY created_at DESC");res.json({users:r.rows});});
app.post("/api/users",auth,role("admin"),async(req,res)=>{const email=String(req.body.email||"").trim().toLowerCase(),password=String(req.body.password||""),roleName=req.body.role==="admin"?"admin":"staff";if(!email||password.length<8)return res.status(400).json({error:"INVALID_INPUT"});const id=crypto.randomUUID();const hash=await bcrypt.hash(password,12);await pool.query("INSERT INTO users(id,email,password_hash,role) VALUES($1,$2,$3,$4)",[id,email,hash,roleName]);await audit(req.user.sub,"CREATE","user",id,{email,role:roleName});res.status(201).json({id,email,role:roleName});});

app.get("/api/notifications",auth,async(req,res)=>{const r=await pool.query("SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100",[req.user.sub]);res.json({notifications:r.rows});});
app.get("/api/themes/:routerId",auth,async(req,res)=>{const r=await pool.query("SELECT * FROM hotspot_themes t JOIN routers r ON r.id=t.router_id WHERE t.router_id=$1 AND r.user_id=$2",[req.params.routerId,req.user.sub]);res.json(r.rows[0]||null);});
app.post("/api/themes/:routerId",auth,async(req,res)=>{const {name="Hotspot",logoUrl=null,primaryColor="#0B5FA5",background="#F4F7FB"}=req.body;const id=crypto.randomUUID();const r=await pool.query("INSERT INTO hotspot_themes(id,router_id,name,logo_url,primary_color,background) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(router_id) DO UPDATE SET name=EXCLUDED.name,logo_url=EXCLUDED.logo_url,primary_color=EXCLUDED.primary_color,background=EXCLUDED.background,updated_at=now() RETURNING *",[id,req.params.routerId,name,logoUrl,primaryColor,background]);res.json(r.rows[0]);});

app.get("/api/backup/export",auth,role("admin"),async(req,res)=>{const tables=["users","routers","cards","sales","payments","audit_logs","notifications","hotspot_themes","app_settings","store_items","store_entitlements"];const data={version:2,createdAt:new Date().toISOString(),tables:{}};for(const t of tables){const r=await pool.query(`SELECT * FROM ${t}`);data.tables[t]=r.rows;}res.json(data);});
app.post("/api/backup/restore",auth,role("admin"),async(req,res)=>{const data=req.body?.tables;if(!data)return res.status(400).json({error:"INVALID_BACKUP"});res.status(501).json({error:"RESTORE_REQUIRES_MAINTENANCE_MODE",message:"تم تجهيز نقطة الاستعادة، ويجب تنفيذها في وضع صيانة لمنع الكتابة المتزامنة."});});

const port=Number(process.env.PORT||8080);init().then(()=>app.listen(port,()=>console.log(`MICRO-MAX API on :${port}`))).catch(e=>{console.error(e);process.exit(1)});
