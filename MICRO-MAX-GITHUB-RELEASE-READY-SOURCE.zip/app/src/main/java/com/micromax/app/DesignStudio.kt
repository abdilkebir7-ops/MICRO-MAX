package com.micromax.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject

private val StudioOrange = Color(0xFFFF9B5A)
private val StudioAccent = Color(0xFF22D3EE)
private val StudioMuted = Color(0xFF94A3B8)
private val StudioRed = Color(0xFFF43F5E)
private val StudioMint = Color(0xFF82E3BF)

@Composable
fun DesignStudioPage(api: Api, router: JSONObject?, activity: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MICRO-MAX Studio", fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("المتجر • تصاميم الكروت • الطباعة • صفحات HotSpot", color = StudioMuted, fontSize = 13.sp)
            }
            Icon(Icons.Default.AutoAwesome, null, tint = StudioAccent, modifier = Modifier.size(30.dp))
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("تصميم الكرت", "صفحات HotSpot", "الطباعة").forEachIndexed { i, label ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) }, leadingIcon = {
                    Icon(if (i == 0) Icons.Default.CreditCard else if (i == 1) Icons.Default.Web else Icons.Default.Print, null)
                })
            }
        }
        when (tab) {
            0 -> CardDesignStudio(api, router)
            1 -> HotspotPageStudio(api, router)
            else -> PrinterStudio(activity)
        }
    }
}

@Composable
private fun CardDesignStudio(api: Api, router: JSONObject?) {
    var template by remember { mutableStateOf("Midnight Glass") }
    var title by remember { mutableStateOf("WiFi Access") }
    var subtitle by remember { mutableStateOf("اتصال سريع وآمن") }
    var support by remember { mutableStateOf("support@micromax.app") }
    var primary by remember { mutableStateOf("#22D3EE") }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val routerId = router?.optString("id")
    val templates = listOf("Midnight Glass", "Orange Market", "Clean White", "VIP Neon")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard {
            Text("مكتبة التصاميم", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("اختر هوية جاهزة ثم عدّل النص واللون. التصميم يحفظ كهوية HotSpot للراوتر.", color = StudioMuted, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                templates.forEach { FilterChip(selected = template == it, onClick = { template = it }, label = { Text(it) }) }
            }
            AppField(title, { title = it }, "عنوان الكرت", Icons.Default.Title)
            AppField(subtitle, { subtitle = it }, "الوصف العربي", Icons.Default.Translate)
            AppField(support, { support = it }, "معلومات الدعم", Icons.Default.SupportAgent)
            AppField(primary, { primary = it }, "اللون الرئيسي HEX", Icons.Default.Palette)
            message?.let { Text(it, color = if (it.startsWith("تم")) StudioMint else StudioRed, fontSize = 12.sp) }
            Button(onClick = {
                if (routerId == null) { message = "اختر راوتر أولاً لحفظ هوية HotSpot"; return@Button }
                scope.launch {
                    saving = true
                    try {
                        api.post("/api/themes/$routerId", JSONObject().put("name", template).put("primaryColor", primary).put("background", "#08111F").put("logoUrl", "MICRO-MAX").toString())
                        message = "تم حفظ تصميم $template للراوتر"
                    } catch (e: Exception) { message = e.message }
                    finally { saving = false }
                }
            }, enabled = !saving, modifier = Modifier.fillMaxWidth()) { Text(if (saving) "جاري الحفظ…" else "حفظ التصميم") }
        }
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("معاينة مباشرة", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Text(template, color = StudioAccent, fontSize = 11.sp)
            }
            DesignedCardPreview(title, subtitle, support, primary)
            Text("المعاينة نفسها تستخدم في ورقة الطباعة وتبقى بيانات الدخول فوق QR وBarcode.", color = StudioMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun DesignedCardPreview(title: String, subtitle: String, support: String, primary: String) {
    val color = parseStudioColor(primary, StudioAccent)
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1624)), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(235.dp).background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF122A3B), Color(0xFF08111D))), RoundedCornerShape(22.dp)).padding(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(26.dp).background(color, RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(9.dp)); Text("MICRO-MAX", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp)); Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text(subtitle, color = color, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Row(verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) { Text("USERNAME", color = StudioMuted, fontSize = 8.sp); Text("KMX-482091", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("PASSWORD  ••••••", color = StudioMuted, fontSize = 9.sp) }
                    val qr = remember { generateCode("https://wifi.micromax.app/login?u=KMX-482091", com.google.zxing.BarcodeFormat.QR_CODE, 130, 130) }
                    qr?.let { Image(it.asImageBitmap(), "QR", Modifier.size(72.dp)) }
                }
                Text(support, color = StudioMuted, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun HotspotPageStudio(api: Api, router: JSONObject?) {
    var page by remember { mutableStateOf("login") }
    var content by remember { mutableStateOf(defaultHotspotHtml("login")) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val id = router?.optString("id")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (router == null) EmptyCard("اختر راوتر أولاً لتصميم صفحات HotSpot") else {
            GlassCard {
                Text("واجهة الزائر", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("صمم login.html و status.html مع معاينة قبل النشر. النشر يحتاج دور Admin ويُنشئ نسخة احتياطية.", color = StudioMuted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = page == "login", onClick = { page = "login"; content = defaultHotspotHtml("login"); status = null }, label = { Text("login.html") }, leadingIcon = { Icon(Icons.Default.Login, null) })
                    FilterChip(selected = page == "status", onClick = { page = "status"; content = defaultHotspotHtml("status"); status = null }, label = { Text("status.html") }, leadingIcon = { Icon(Icons.Default.Dashboard, null) })
                }
                AppField(content, { content = it }, "HTML المصدر", Icons.Default.Code)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            busy = true
                            try { val raw = api.post("/api/routers/$id/hotspot-pages/validate", JSONObject().put("page", page).put("content", content).toString()); status = if (JSONObject(raw).optBoolean("valid")) "تم التحقق: الصفحة متوافقة" else "تحقق غير مكتمل: $raw" }
                            catch (e: Exception) { status = e.message } finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("تحقق") }
                    Button(onClick = {
                        scope.launch {
                            busy = true
                            try { api.post("/api/routers/$id/hotspot-pages/publish", JSONObject().put("page", page).put("content", content).toString()); status = "تم نشر $page.html مع Backup تلقائي" }
                            catch (e: Exception) { status = e.message } finally { busy = false }
                        }
                    }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("نشر آمن") }
                }
                status?.let { Text(it, color = if (it.startsWith("تم")) StudioMint else StudioRed, fontSize = 12.sp) }
            }
            GlassCard {
                Text("المعاينة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                HotspotPreview(page, content)
            }
        }
    }
}

@Composable
private fun HotspotPreview(page: String, content: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("MICRO-MAX", color = Color(0xFF0B5FA5), fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text(if (page == "login") "اتصل بالإنترنت" else "حالة الاتصال", color = Color(0xFF1F2937), fontWeight = FontWeight.Bold)
            if (page == "login") { Text("أدخل بيانات الكرت", color = Color.Gray, fontSize = 12.sp); OutlinedButton(onClick = {}) { Text("تسجيل الدخول") } }
            else { Text("KMX-482091 • متصل", color = Color(0xFF14804A)); Text("الوقت المتبقي: 58 دقيقة", color = Color.Gray, fontSize = 12.sp) }
            Text("مصدر ${content.length} حرف • ${if (page == "login") "MikroTik login.html" else "MikroTik status.html"}", color = Color.Gray, fontSize = 9.sp)
        }
    }
}

@Composable
private fun PrinterStudio(activity: MainActivity) {
    val prefs = remember { activity.getSharedPreferences("micromax_printer", android.content.Context.MODE_PRIVATE) }
    var paper by remember { mutableStateOf(prefs.getString("paper", "A4") ?: "A4") }
    var columns by remember { mutableStateOf(prefs.getInt("columns", 2).toString()) }
    var rows by remember { mutableStateOf(prefs.getInt("rows", 4).toString()) }
    var copies by remember { mutableStateOf(prefs.getInt("copies", 1).toString()) }
    var saved by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard {
            Text("مركز الطباعة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("تحكم في مقاس الورق وعدد الكروت في الورقة، ثم افتح طباعة Android لطابعتك الحرارية أو A4.", color = StudioMuted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("A4", "80mm Thermal", "Custom").forEach { FilterChip(selected = paper == it, onClick = { paper = it }, label = { Text(it) }) } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { AppField(columns, { columns = it.filter(Char::isDigit) }, "أعمدة", Icons.Default.ViewColumn); AppField(rows, { rows = it.filter(Char::isDigit) }, "صفوف", Icons.Default.GridView) }
            AppField(copies, { copies = it.filter(Char::isDigit) }, "عدد النسخ", Icons.Default.ContentCopy)
            Button(onClick = { prefs.edit().putString("paper", paper).putInt("columns", columns.toIntOrNull() ?: 2).putInt("rows", rows.toIntOrNull() ?: 4).putInt("copies", copies.toIntOrNull() ?: 1).apply(); saved = true }, modifier = Modifier.fillMaxWidth()) { Text(if (saved) "تم حفظ إعدادات الطابعة" else "حفظ إعدادات الطباعة") }
        }
        GlassCard {
            Text("معاينة ورقة الطباعة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            PrintSheetPreview(columns.toIntOrNull() ?: 2, rows.toIntOrNull() ?: 4)
            Button(onClick = { activity.printBitmap(composePrintSheet(columns.toIntOrNull() ?: 2, rows.toIntOrNull() ?: 4)) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Print, null); Spacer(Modifier.width(8.dp)); Text("فتح نافذة الطباعة") }
        }
    }
}

@Composable
private fun PrintSheetPreview(columns: Int, rows: Int) {
    Column(Modifier.fillMaxWidth().background(Color(0xFFEFF3F5), RoundedCornerShape(12.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(rows.coerceIn(1, 6)) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) { repeat(columns.coerceIn(1, 4)) { PrintCell(Modifier.weight(1f)) } } }
    }
}

@Composable
private fun PrintCell(modifier: Modifier) {
    Card(modifier.height(74.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1624)), shape = RoundedCornerShape(7.dp)) {
        Column(Modifier.padding(7.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("MICRO-MAX", color = StudioAccent, fontSize = 7.sp, fontWeight = FontWeight.Black)
            Text("WiFi Access", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text("KMX-482091", color = Color.White, fontSize = 7.sp)
            Text("QR + Barcode", color = StudioMuted, fontSize = 6.sp)
        }
    }
}

private fun composePrintSheet(columns: Int, rows: Int): Bitmap {
    val w = 1200
    val h = 1700
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    canvas.drawColor(android.graphics.Color.WHITE)
    val cols = columns.coerceIn(1, 4); val rws = rows.coerceIn(1, 6)
    val gap = 22; val cardW = (w - gap * (cols + 1)) / cols; val cardH = (h - gap * (rws + 1)) / rws
    repeat(rws) { r -> repeat(cols) { c -> drawStudioCard(canvas, gap + c * (cardW + gap), gap + r * (cardH + gap), cardW, cardH) } }
    return out
}

private fun drawStudioCard(canvas: Canvas, x: Int, y: Int, w: Int, h: Int) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG); p.color = android.graphics.Color.rgb(8, 17, 31); canvas.drawRoundRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), 22f, 22f, p)
    p.color = android.graphics.Color.rgb(34, 211, 238); canvas.drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + 12).toFloat(), p)
    p.color = android.graphics.Color.WHITE; p.textSize = 28f; p.typeface = Typeface.DEFAULT_BOLD; canvas.drawText("MICRO-MAX", (x + 24).toFloat(), (y + 54).toFloat(), p)
    p.textSize = 22f; canvas.drawText("KMX-482091", (x + 24).toFloat(), (y + h - 44).toFloat(), p)
    generateCode("https://wifi.micromax.app/login?u=KMX-482091", com.google.zxing.BarcodeFormat.QR_CODE, 260, 260)?.let { canvas.drawBitmap(it, null, android.graphics.Rect(x + w - 150, y + h - 170, x + w - 30, y + h - 50), p) }
}

private fun parseStudioColor(value: String, fallback: Color): Color = try { Color(android.graphics.Color.parseColor(value)) } catch (_: Exception) { fallback }

private fun defaultHotspotHtml(page: String): String = if (page == "login") """<!doctype html><html><head><meta charset="utf-8"><title>MICRO-MAX Login</title></head><body><form name="login" action="$(link-login-only)" method="post"><input name="username" placeholder="Username"><input name="password" type="password" placeholder="Password"><input type="hidden" name="dst" value="$(link-orig)"><button type="submit">تسجيل الدخول</button></form><p>MICRO-MAX HotSpot</p></body></html>""" else """<!doctype html><html><head><meta charset="utf-8"><title>MICRO-MAX Status</title></head><body><h1>MICRO-MAX</h1><p>مرحباً $(username)</p><p>الوقت المتبقي: $(session-time-left)</p><a href="$(link-logout)">تسجيل الخروج</a></body></html>"""
