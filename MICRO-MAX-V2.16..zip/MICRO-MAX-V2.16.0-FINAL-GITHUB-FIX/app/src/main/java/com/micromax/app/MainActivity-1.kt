/*
 * KARIM MAX Hotspot Manager
 * Clean experimental build of MainActivity.
 *
 * Important:
 * - UI functions are explicitly marked @Composable.
 * - No Gradle/SDK logic belongs in this file.
 */

package com.karimmax.hotspot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF050A14)
private val Card = Color(0xDD111C2D)
private val Card2 = Color(0xFF0D1726)
private val Accent = Color(0xFF22D3EE)
private val Blue = Color(0xFF3B82F6)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFF43F5E)
private val Amber = Color(0xFFF59E0B)
private val TextMain = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KarimApp() }
    }
}

class Api(private val base: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .writeTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .connectionPool(okhttp3.ConnectionPool(4, 5, java.util.concurrent.TimeUnit.MINUTES))
        .build()
    var token: String? = null
    private fun builder(path: String) = Request.Builder().url(base.trim().trimEnd('/') + path).apply { token?.let { addHeader("Authorization", "Bearer $it") } }
    suspend fun get(path: String) = call(builder(path).get().build())
    suspend fun post(path: String, json: String) = call(builder(path).post(json.toRequestBody("application/json".toMediaType())).build())
    suspend fun delete(path: String) = call(builder(path).delete().build())
    private suspend fun call(req: Request): String = withContext(Dispatchers.IO) {
        http.newCall(req).execute().use { r -> val body = r.body?.string().orEmpty(); if (!r.isSuccessful) throw Exception(parseError(body, r.code)); body }
    }
    private fun parseError(body: String, code: Int) = try { JSONObject(body).optString("error").ifBlank { "HTTP $code" } } catch (_: Exception) { "HTTP $code" }
}

data class NavItem(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun KarimApp() {
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, secondary = Blue, background = Bg, surface = Card2, onSurface = TextMain)) {
        var api by remember { mutableStateOf<Api?>(null) }
        var logged by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        if (!logged) {
            LoginScreen { url, username, password, result ->
                scope.launch {
                    val a = Api(url)
                    try {
                        val raw = a.post("/api/login", JSONObject().put("username", username).put("password", password).toString())
                        a.token = JSONObject(raw).getString("token")
                        api = a; logged = true; result(null)
                    } catch (e: Exception) { result(e.message ?: "تعذر الاتصال بالخادم") }
                }
            }
        } else {
            MainShell(api!!, onLogout = { logged = false; api = null })
        }
    }
}

@Composable
fun LoginScreen(onLogin: suspend (String, String, String, (String?) -> Unit) -> Unit) {
    val scope = rememberCoroutineScope(); var url by remember { mutableStateOf("https://karim-max-hotspot-manager.onrender.com") }; var user by remember { mutableStateOf("admin") }; var pass by remember { mutableStateOf("") }; var show by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }; var loading by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07111F), Bg, Color(0xFF02050B)))).systemBarsPadding().imePadding()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(24.dp)); Logo(); Spacer(Modifier.height(14.dp)); Text("KARIM MAX", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("HOTSPOT MANAGER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Accent); Text("إدارة MikroTik باحتراف", fontSize = 13.sp, color = TextMuted); Spacer(Modifier.height(22.dp))
            GlassCard { Text("تسجيل الدخول", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("ادخل بيانات حساب مدير التطبيق", fontSize = 13.sp, color = TextMuted); Spacer(Modifier.height(10.dp))
                AppField(url, { url = it }, "رابط الخادم", Icons.Default.Cloud); AppField(user, { user = it }, "اسم المستخدم", Icons.Default.Security); OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("كلمة المرور") }, leadingIcon = { Icon(Icons.Default.Security, null) }, trailingIcon = { IconButton({ show = !show }) { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } }, singleLine = true, visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp))
                error?.let { Text("⚠ $it", color = Color(0xFFFCA5A5), fontSize = 13.sp) }; Spacer(Modifier.height(4.dp)); Button({ if (url.isBlank() || user.isBlank() || pass.isBlank()) { error = "أكمل جميع البيانات"; return@Button }; loading = true; scope.launch { onLogin(url.trim(), user.trim(), pass, { error = it; loading = false }) } }, enabled = !loading, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text(if (loading) "جاري التحقق…" else "دخول آمن", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(20.dp)); Text("KARIM MAX • MikroTik Hotspot Manager", fontSize = 11.sp, color = TextMuted)
        }
    }
}

@Composable fun Logo() { Box(Modifier.size(78.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Accent, Blue))), Alignment.Center) { Text("K", fontSize = 38.sp, fontWeight = FontWeight.Black, color = Color.White) } }
@Composable fun AppField(value: String, onValue: (String) -> Unit, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) { OutlinedTextField(value, onValue, label = { Text(label) }, leadingIcon = { Icon(icon, null) }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) }
@Composable fun GlassCard(content: @Composable ColumnScope.() -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(10.dp)) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content) } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainShell(api: Api, onLogout: () -> Unit) {
    val nav = listOf(NavItem("الرئيسية", Icons.Default.Dashboard), NavItem("الراوترات", Icons.Default.Router), NavItem("المستخدمون", Icons.Default.Devices), NavItem("الكروت", Icons.Default.Inventory2), NavItem("الإعدادات", Icons.Default.Settings))
    var page by remember { mutableIntStateOf(0) }
    var routers by remember { mutableStateOf(JSONArray()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var dash by remember { mutableStateOf<JSONObject?>(null) }
    var users by remember { mutableStateOf(JSONArray()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun refresh() { scope.launch { loading = true; error = null; try { routers = JSONArray(api.get("/api/routers")); if (routers.length() > 0) { val old = selected?.optInt("id", -1) ?: -1; selected = (0 until routers.length()).map { routers.getJSONObject(it) }.firstOrNull { it.optInt("id") == old } ?: routers.getJSONObject(0); loadRouter(api, selected!!, { dash = it }, { users = it }) } else { selected = null; dash = null; users = JSONArray() } } catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" } finally { loading = false } } }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(containerColor = Bg, topBar = { TopAppBar(title = { Row(verticalAlignment = Alignment.CenterVertically) { Text("KARIM MAX", fontWeight = FontWeight.Black); Spacer(Modifier.width(8.dp)); Surface(shape = RoundedCornerShape(50), color = Color(0x2222D3EE)) { Text("VIP", modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent) } } }, actions = { IconButton({ refresh() }) { Icon(Icons.Default.Refresh, "تحديث") }; IconButton(onLogout) { Icon(Icons.Default.Logout, "خروج") } }) }, bottomBar = { NavigationBar(containerColor = Color(0xFF08111F)) { nav.forEachIndexed { i, n -> NavigationBarItem(selected = page == i, onClick = { page = i }, icon = { Icon(n.icon, null) }, label = { Text(n.label, fontSize = 10.sp) }) } } }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (page) {
                0 -> DashboardPage(routers, selected, dash, users, error, loading, { showAdd = true }, { selected = it; scope.launch { try { loadRouter(api, it, { dash = it }, { users = it }) } catch (e: Exception) { error = e.message } } })
                1 -> RoutersPage(routers, selected, { showAdd = true }, { r -> selected = r; page = 0; scope.launch { try { loadRouter(api, r, { dash = it }, { users = it }) } catch (e: Exception) { error = e.message } } }, { id -> scope.launch { try { api.delete("/api/routers/$id"); refresh() } catch (e: Exception) { error = e.message } } })
                2 -> UsersPage(users, selected, error)
                3 -> CardsPage(selected, api, error)
                else -> SettingsPage(onLogout)
            }
        }
    }
    if (showAdd) AddRouterDialog(api, { showAdd = false; refresh() }, { showAdd = false })
}

@Composable
fun DashboardPage(routers: JSONArray, selected: JSONObject?, dash: JSONObject?, users: JSONArray, error: String?, loading: Boolean, add: () -> Unit, select: (JSONObject) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp)) {
        item { Text("لوحة التحكم", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("مراقبة وإدارة شبكة MikroTik من مكان واحد", fontSize = 13.sp, color = TextMuted) }
        error?.let { item { ErrorCard(it) } }
        item { RouterSelector(routers, selected, add, select) }
        if (selected != null && dash != null) {
            val res = dash.optJSONObject("resource"); item { StatsGrid(res, dash) }; item { ResourceCard(res, selected) }
        } else if (routers.length() == 0) { item { EmptyRouterCard(add) } }
        item { Text("المستخدمون الحقيقيون", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("حسابات Hotspot الموجودة على الراوتر المحدد", fontSize = 12.sp, color = TextMuted) }
        if (users.length() == 0 && selected != null) item { EmptyCard("لا توجد حسابات Hotspot حالياً") }
        items((0 until users.length()).take(8)) { UserRow(users.getJSONObject(it)) }
        if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
    }
}

@Composable fun RouterSelector(routers: JSONArray, selected: JSONObject?, add: () -> Unit, select: (JSONObject) -> Unit) { GlassCard { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Router, null, tint = Accent); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("الراوتر الحالي", fontSize = 12.sp, color = TextMuted); Text(selected?.optString("name", "اختر راوتر") ?: "لا يوجد راوتر", fontWeight = FontWeight.Bold) }; Button(add) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة") } }; if (routers.length() > 0) Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { for (i in 0 until routers.length()) { val r = routers.getJSONObject(i); FilterChip(selected = selected?.optInt("id") == r.optInt("id"), onClick = { select(r) }, label = { Text(r.optString("name", "Router"), maxLines = 1) }) } } } }

@Composable fun StatsGrid(res: JSONObject?, dash: JSONObject) { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Row(horizontalArrangement = Arrangement.spacedBy(10.dp), Modifier.fillMaxWidth()) { Stat("CPU", (res?.optString("cpu-load", "0") ?: "0") + "%", Icons.Default.Speed, Modifier.weight(1f)); Stat("المستخدمون", dash.optInt("users").toString(), Icons.Default.Devices, Modifier.weight(1f)) }; Row(horizontalArrangement = Arrangement.spacedBy(10.dp), Modifier.fillMaxWidth()) { Stat("متصل الآن", dash.optInt("active").toString(), Icons.Default.Cloud, Modifier.weight(1f)); Stat("RAM", memoryText(res), Icons.Default.Dns, Modifier.weight(1f)) } } }
@Composable fun Stat(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(16.dp)) { Icon(icon, null, tint = Accent); Spacer(Modifier.height(8.dp)); Text(title, fontSize = 12.sp, color = TextMuted); Text(value, fontSize = 22.sp, fontWeight = FontWeight.Black) } } }
@Composable fun ResourceCard(res: JSONObject?, router: JSONObject) { GlassCard { Row(verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(46.dp), RoundedCornerShape(14.dp), Color(0x2222D3EE)) { Box(Alignment.Center) { Icon(Icons.Default.Router, null, tint = Accent) } }; Spacer(Modifier.width(12.dp)); Column { Text(router.optString("name", "Router"), fontWeight = FontWeight.Bold); Text(router.optString("host", "-"), fontSize = 12.sp, color = TextMuted) } }; HorizontalDivider(); Text("RouterOS ${res?.optString("version", "-")}", fontWeight = FontWeight.Bold); Text("${res?.optString("board-name", "-")} • ${res?.optString("architecture-name", "-")}", 12.sp, color = TextMuted); Text("Uptime: ${res?.optString("uptime", "-")}", 12.sp, color = TextMuted) } }
fun memoryText(res: JSONObject?): String { val total = res?.optString("total-memory")?.toLongOrNull(); val free = res?.optString("free-memory")?.toLongOrNull(); return if (total != null && free != null && total > 0) "${((total-free)*100/total)}%" else "-" }

@Composable fun EmptyRouterCard(add: () -> Unit) { GlassCard { Icon(Icons.Default.Router, null, tint = Accent, modifier = Modifier.size(42.dp)); Text("لا يوجد راوتر مرتبط", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("أضف MikroTik الآن ثم اختبر الاتصال، وستظهر الإحصائيات هنا مباشرة.", fontSize = 13.sp, color = TextMuted); Button(add, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة راوتر MikroTik") } } }
@Composable fun EmptyCard(text: String) { Card(colors = CardDefaults.cardColors(containerColor = Card2), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Text(text, Modifier.padding(18.dp), color = TextMuted) } }
@Composable fun ErrorCard(text: String) { Card(colors = CardDefaults.cardColors(containerColor = Color(0x22F43F5E)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ErrorOutline, null, tint = Red); Spacer(Modifier.width(8.dp)); Text(text, color = Color(0xFFFDA4AF), fontSize = 13.sp) } } }

@Composable
fun RoutersPage(routers: JSONArray, selected: JSONObject?, add: () -> Unit, choose: (JSONObject) -> Unit, remove: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("إدارة الراوترات", fontSize = 28.sp, fontWeight = FontWeight.Black); Text("إضافة واختبار وحذف أجهزة MikroTik", fontSize = 13.sp, color = TextMuted) }; Button(add) { Icon(Icons.Default.Add, null); Text("إضافة") } } }
        if (routers.length() == 0) item { EmptyRouterCard(add) }
        items((0 until routers.length()).map { routers.getJSONObject(it) }) { r -> RouterRow(r, selected?.optInt("id") == r.optInt("id"), { choose(r) }, { remove(r.optInt("id")) }) }
    }
}
@Composable fun RouterRow(r: JSONObject, selected: Boolean, choose: () -> Unit, remove: () -> Unit) { Card(Modifier.fillMaxWidth().clickable { choose() }, colors = CardDefaults.cardColors(containerColor = if (selected) Color(0x3322D3EE) else Card), shape = RoundedCornerShape(20.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(48.dp), RoundedCornerShape(14.dp), Color(0x223B82F6)) { Box(Alignment.Center) { Icon(Icons.Default.Router, null, tint = Blue) } }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(r.optString("name", "Router"), fontWeight = FontWeight.Bold); Text("${r.optString("host", "-")}:${r.optInt("port", 8729)}", 12.sp, color = TextMuted) }; IconButton(remove) { Icon(Icons.Default.Delete, null, tint = Red) } } } }

@Composable fun UsersPage(users: JSONArray, selected: JSONObject?, error: String?) { LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) { item { Text("مستخدمو Hotspot", fontSize = 28.sp, fontWeight = FontWeight.Black); Text(selected?.optString("name", "اختر راوتر") ?: "لا يوجد راوتر محدد", 13.sp, color = TextMuted) }; error?.let { item { ErrorCard(it) } }; items((0 until users.length()).map { users.getJSONObject(it) }) { UserRow(it) }; if (users.length() == 0) item { EmptyCard("لا توجد بيانات مستخدمين") } } }
@Composable fun UserRow(user: JSONObject) { val disabled = user.optString("disabled") == "true"; Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Surface(Modifier.size(42.dp), CircleShape, if (disabled) Color(0x22F43F5E) else Color(0x2222C55E)) { Box(Alignment.Center) { Icon(Icons.Default.Devices, null, tint = if (disabled) Red else Green) } }; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(user.optString("name", "-"), fontWeight = FontWeight.Bold); Text(user.optString("profile", "default"), fontSize = 12.sp, color = TextMuted) }; Text(if (disabled) "معطل" else "فعال", fontSize = 12.sp, color = if (disabled) Red else Green, fontWeight = FontWeight.Bold) } } }

@Composable
fun CardsPage(selected: JSONObject?, api: Api, error: String?) { var count by remember { mutableStateOf("10") }; var profile by remember { mutableStateOf("default") }; var result by remember { mutableStateOf<JSONArray?>(null) }; var msg by remember { mutableStateOf<String?>(error) }; val scope = rememberCoroutineScope(); Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("توليد كروت الدخول", fontSize = 28.sp, fontWeight = FontWeight.Black); Text(selected?.optString("name", "اختر راوتر") ?: "أضف راوتر أولاً", 13.sp, color = TextMuted); GlassCard { AppField(count, { count = it }, "عدد الكروت", Icons.Default.Inventory2); AppField(profile, { profile = it }, "Profile", Icons.Default.Security); Button({ val id = selected?.optInt("id") ?: return@Button; scope.launch { try { val raw = api.post("/api/routers/$id/cards/generate", JSONObject().put("count", count.toIntOrNull() ?: 1).put("profile", profile).put("prefix", "KMX").toString()); result = JSONObject(raw).optJSONArray("cards") } catch (e: Exception) { msg = e.message } } }, enabled = selected != null, Modifier.fillMaxWidth()) { Text("توليد الكروت") } }; msg?.let { ErrorCard(it) }; result?.let { arr -> Text("تم إنشاء ${arr.length()} كرت", fontSize = 18.sp, fontWeight = FontWeight.Bold); for (i in 0 until minOf(arr.length(), 50)) { val c = arr.getJSONObject(i); Card(colors = CardDefaults.cardColors(containerColor = Card), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(c.optString("username")); Text(c.optString("password"), color = Accent) } } } } } }

@Composable fun SettingsPage(logout: () -> Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("الإعدادات", fontSize = 28.sp, fontWeight = FontWeight.Black); GlassCard { Text("KARIM MAX Hotspot Manager", fontWeight = FontWeight.Bold); Text("واجهة إدارة MikroTik عبر RouterOS API / API-SSL", fontSize = 13.sp, color = TextMuted); Text("الاتصال من التطبيق إلى الخادم يتم عبر HTTPS.", fontSize = 13.sp, color = TextMuted) }; OutlinedButton(logout, Modifier.fillMaxWidth()) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(6.dp)); Text("تسجيل الخروج") } } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddRouterDialog(api: Api, onSaved: () -> Unit, onCancel: () -> Unit) {
    val scope = rememberCoroutineScope(); var name by remember { mutableStateOf("") }; var host by remember { mutableStateOf("") }; var port by remember { mutableStateOf("8729") }; var username by remember { mutableStateOf("admin") }; var password by remember { mutableStateOf("") }; var tls by remember { mutableStateOf(true) }; var test by remember { mutableStateOf(false) }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onCancel, title = { Text("إضافة MikroTik", fontWeight = FontWeight.Bold) }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) { AppField(name, { name = it }, "اسم الراوتر", Icons.Default.Router); AppField(host, { host = it }, "IP / Host", Icons.Default.Cloud); AppField(port, { port = it }, "Port", Icons.Default.Dns); AppField(username, { username = it }, "اسم مستخدم MikroTik", Icons.Default.Security); OutlinedTextField(password, { password = it }, label = { Text("كلمة مرور MikroTik") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(14.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(tls, { tls = it }); Text("API-SSL (8729)") }; error?.let { Text(it, color = Color(0xFFFDA4AF), fontSize = 12.sp) } } }, confirmButton = { Button({ scope.launch { test = true; error = null; try { val body = JSONObject().put("name", name.trim()).put("host", host.trim()).put("port", port.toIntOrNull() ?: 8729).put("username", username.trim()).put("password", password).put("verifyTls", false); val created = JSONObject(api.post("/api/routers", body.toString())); val id = created.getLong("id"); api.post("/api/routers/$id/test", "{}"); onSaved() } catch (e: Exception) { error = e.message ?: "فشل الاتصال" } finally { test = false } } }, enabled = !test && name.isNotBlank() && host.isNotBlank() && username.isNotBlank() && password.isNotBlank()) { Text(if (test) "جاري الاختبار…" else "حفظ واختبار") } }, dismissButton = { TextButton(onCancel) { Text("إلغاء") } })
}

private suspend fun loadRouter(api: Api, router: JSONObject, setDash: (JSONObject) -> Unit, setUsers: (JSONArray) -> Unit) = withContext(Dispatchers.IO) {
    val id = router.getInt("id")
    val results = listOf(
        async { JSONObject(api.get("/api/routers/$id/dashboard")) },
        async { JSONArray(api.get("/api/routers/$id/hotspot/users")) }
    ).awaitAll()
    withContext(Dispatchers.Main) {
        setDash(results[0] as JSONObject)
        setUsers(results[1] as JSONArray)
    }
}
