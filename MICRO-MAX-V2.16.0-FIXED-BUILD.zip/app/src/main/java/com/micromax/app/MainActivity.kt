package com.micromax.app

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.print.PrintAttributes
import android.print.PrintManager
import android.print.PrintDocumentAdapter
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter

private object ThemeState {
    val dark = mutableStateOf(false)
    private const val PREFS = "micromax_prefs"
    private const val KEY_DARK = "dark_mode"
    /** Call once on cold start, before setContent{}. */
    fun load(context: Context) {
        dark.value = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_DARK, false)
    }
    /** Call from the Settings toggle — updates the in-memory state AND persists it. */
    fun set(context: Context, value: Boolean) {
        dark.value = value
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_DARK, value).apply()
    }
}
private val Bg: Color get() = if (ThemeState.dark.value) Color(0xFF07111F) else Color(0xFFF3F6FA)
private val Glass: Color get() = if (ThemeState.dark.value) Color(0xCC0C1928) else Color(0xEEFFFFFF)
private val GlassSoft: Color get() = if (ThemeState.dark.value) Color(0xB8172A40) else Color(0xBFFFFFFF)
private val Ink: Color get() = if (ThemeState.dark.value) Color(0xFFF5F8FC) else Color(0xFF14283B)
private val Muted: Color get() = if (ThemeState.dark.value) Color(0xFF9CB0C3) else Color(0xFF718096)
private val Blue: Color get() = if (ThemeState.dark.value) Color(0xFF42AFFF) else Color(0xFF075E9E)
private val Orange: Color get() = if (ThemeState.dark.value) Color(0xFFFF9858) else Color(0xFFEF641F)
private val Green: Color get() = if (ThemeState.dark.value) Color(0xFF35D58A) else Color(0xFF159B67)
private val Red: Color get() = if (ThemeState.dark.value) Color(0xFFFF7080) else Color(0xFFD33F55)
private val Border: Color get() = if (ThemeState.dark.value) Color(0xFF25445E) else Color(0xFFD9E3EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        installSplashScreen() // must run before super.onCreate() per core-splashscreen API
        super.onCreate(b)
        ThemeState.load(this)
        setContent { MicroMaxApp() }
    }
}

class Api(private val base: String) {
    private val client = OkHttpClient.Builder().retryOnConnectionFailure(true).build()
    var token: String? = null
    fun call(path: String, method: String = "GET", json: String? = null): String {
        val b = Request.Builder().url(base.trimEnd('/') + path)
        token?.let { b.header("Authorization", "Bearer $it") }
        when(method) { "POST" -> b.post((json ?: "{}").toRequestBody("application/json".toMediaType())); "DELETE" -> b.delete() }
        client.newCall(b.build()).execute().use { r -> val body=r.body?.string().orEmpty(); if(!r.isSuccessful) throw Exception(JSONObject(body).optString("error", "HTTP_${r.code}")); return body }
    }
}

@Composable fun MicroMaxApp() {
    val api = remember { Api(BuildConfig.MICROMAX_API_BASE_URL) }
    var logged by remember { mutableStateOf(false) }
    val scheme = if (ThemeState.dark.value) darkColorScheme(primary=Blue,secondary=Orange,background=Bg,surface=Glass,onSurface=Ink) else lightColorScheme(primary=Blue,secondary=Orange,background=Bg,surface=Color.White,onSurface=Ink)
    MaterialTheme(colorScheme=scheme) { if(logged) AppShell(api){ api.token=null; logged=false } else Login(api){ logged=true } }
}

@Composable fun AppBackground(content: @Composable BoxScope.() -> Unit) { Box(Modifier.fillMaxSize().background(Brush.verticalGradient(if(ThemeState.dark.value) listOf(Color(0xFF07111F),Bg,Color(0xFF02070D)) else listOf(Color(0xFFF9FBFD),Bg,Color.White))),content=content) }
@Composable fun BrandMark(){ Box(Modifier.size(72.dp).shadow(14.dp,CircleShape).background(Brush.linearGradient(listOf(Blue,Orange)),CircleShape),Alignment.Center){ Text("M",fontSize=34.sp,fontWeight=FontWeight.Black,color=Color.White) } }
@Composable fun GlassCard(content:@Composable ColumnScope.()->Unit){ Card(colors=CardDefaults.cardColors(containerColor=Glass),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth().border(1.dp,Border,RoundedCornerShape(24.dp)),elevation=CardDefaults.cardElevation(if(ThemeState.dark.value) 8.dp else 3.dp)){Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(11.dp),content=content)} }
@Composable fun Field(v:String,on:(String)->Unit,label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,secret:Boolean=false){OutlinedTextField(v,on,label={Text(label)},leadingIcon={Icon(icon,null)},singleLine=true,visualTransformation=if(secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))}
@Composable fun Hero(title:String,sub:String,icon:androidx.compose.ui.graphics.vector.ImageVector){GlassCard{Row(verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(54.dp),RoundedCornerShape(17.dp),if(ThemeState.dark.value) Color(0x223FAAFF) else Color(0xFFE9F3FA)){Box(Alignment.Center){Icon(icon,null,tint=Blue)}};Spacer(Modifier.width(12.dp));Column{Text(title,fontSize=25.sp,fontWeight=FontWeight.Black);Text(sub,fontSize=12.sp,color=Muted)}}}}
@Composable fun Stat(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier){GlassCard{Row(modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Blue);Spacer(Modifier.width(8.dp));Column{Text(title,fontSize=11.sp,color=Muted);Text(value,fontSize=21.sp,fontWeight=FontWeight.Black)}}}}

@Composable fun Login(api:Api,onDone:()->Unit){
    var email by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var register by remember{mutableStateOf(false)};var err by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
    val connectionFailed=stringResource(R.string.connection_failed)
    AppBackground{Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){BrandMark();Spacer(Modifier.height(12.dp));Text(stringResource(R.string.app_name),fontSize=31.sp,fontWeight=FontWeight.Black,color=Blue);Text(stringResource(R.string.tagline),fontSize=11.sp,fontWeight=FontWeight.Bold,color=Orange);Spacer(Modifier.height(20.dp));GlassCard{Text(if(register)stringResource(R.string.register_title) else stringResource(R.string.login_title),fontSize=23.sp,fontWeight=FontWeight.Bold);Field(email,{email=it},stringResource(R.string.email_label),Icons.Default.Email);Field(pass,{pass=it},stringResource(R.string.password_label),Icons.Default.Lock,true);if(err.isNotBlank())Text(err,color=Red,fontSize=12.sp);Button(onClick={busy=true;scope.launch(Dispatchers.IO){try{val p=if(register)"/api/auth/register" else "/api/auth/login";val raw=api.call(p,"POST",JSONObject().put("email",email).put("password",pass).toString());api.token=JSONObject(raw).getString("token");busy=false;onDone()}catch(e:Exception){busy=false;err=e.message?:connectionFailed}}},enabled=!busy,modifier=Modifier.fillMaxWidth().height(53.dp),shape=RoundedCornerShape(16.dp)){Text(if(busy)stringResource(R.string.checking_action) else if(register)stringResource(R.string.register_action) else stringResource(R.string.login_action),fontWeight=FontWeight.Bold)};TextButton({register=!register;err=""}){Text(if(register)stringResource(R.string.switch_to_login) else stringResource(R.string.switch_to_register))};Text(stringResource(R.string.login_security_note),fontSize=10.sp,color=Muted)}}}
}

@Composable fun AppShell(api:Api,logout:()->Unit){
    var page by remember{mutableIntStateOf(0)};var routers by remember{mutableStateOf(listOf<JSONObject>())};var cards by remember{mutableStateOf(listOf<JSONObject>())};var showAdd by remember{mutableStateOf(false)};var refreshKey by remember{mutableIntStateOf(0)};val scope=rememberCoroutineScope()
    fun refresh(){scope.launch(Dispatchers.IO){try{val r=JSONObject(api.call("/api/routers")).getJSONArray("routers");routers=List(r.length()){r.getJSONObject(it)};val c=JSONObject(api.call("/api/cards")).getJSONArray("cards");cards=List(c.length()){c.getJSONObject(it)}}catch(_:Exception){}}}
    LaunchedEffect(refreshKey){refresh()}
    val navLabels=stringArrayResource(R.array.nav_labels)
    val navIcons=listOf(Icons.Default.Dashboard,Icons.Default.Router,Icons.Default.Inventory2,Icons.Default.Store,Icons.Default.ShoppingCart,Icons.Default.BarChart,Icons.Default.Security,Icons.Default.Settings)
    Scaffold(containerColor=Bg,topBar={TopAppBar(title={Column{Text(stringResource(R.string.app_name),fontWeight=FontWeight.Black);Text(navLabels[page],fontSize=10.sp,color=Muted)}},actions={IconButton({refreshKey++}){Icon(Icons.Default.Refresh,null,tint=Blue)};IconButton(logout){Icon(Icons.Default.Logout,null,tint=Orange)}})},bottomBar={NavigationBar(containerColor=Glass){navIcons.forEachIndexed{i,icon->NavigationBarItem(selected=page==i,onClick={page=i},icon={Icon(icon,null)},label={Text(navLabels[i],fontSize=9.sp)})}}}){pad->Box(Modifier.fillMaxSize().padding(pad)){when(page){0->Dashboard(routers,cards,{showAdd=true});1->Routers(routers,api,{showAdd=true},refreshKey,{refreshKey++});2->Cards(cards,routers,api,{refreshKey++});3->Store(api);4->Sales(cards,api);5->Reports(api);6->Security(api);7->Settings(logout)}}};if(showAdd){AddRouterDialog(api,{showAdd=false;refreshKey++},{showAdd=false})}
}

@Composable fun Dashboard(routers:List<JSONObject>,cards:List<JSONObject>,add:()->Unit){LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(13.dp),contentPadding=PaddingValues(top=8.dp,bottom=25.dp)){item{Hero("لوحة التحكم","إدارة الراوترات والكروت والمبيعات في مكان واحد",Icons.Default.Dashboard)};item{Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){Stat("الراوترات",routers.size.toString(),Icons.Default.Router,Modifier.weight(1f));Stat("الكروت",cards.size.toString(),Icons.Default.Inventory2,Modifier.weight(1f))}};item{GlassCard{Text("حالة النظام",fontSize=19.sp,fontWeight=FontWeight.Bold);Text("الاتصال بالـBackend يتم عبر HTTPS، وبيانات الراوترات لا تُخزن داخل التطبيق.",fontSize=12.sp,color=Muted);Button(add,Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("إضافة MikroTik")}}};item{Text("المزايا",fontSize=20.sp,fontWeight=FontWeight.Bold)};item{Feature("إدارة متعددة للراوترات","API / API-SSL + مراقبة الموارد والمستخدمين",Icons.Default.Router)};item{Feature("الكروت والمبيعات","توليد كروت، بيع، مخزون، حالات الدفع",Icons.Default.CreditCard)};item{Feature("الأمان والتقارير","صلاحيات، Audit Log، Backup وتقارير CSV/PDF",Icons.Default.Security)}}}
@Composable fun Feature(t:String,s:String,icon:androidx.compose.ui.graphics.vector.ImageVector){GlassCard{Row(verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Orange);Spacer(Modifier.width(12.dp));Column{Text(t,fontWeight=FontWeight.Bold);Text(s,fontSize=12.sp,color=Muted)}}}}

@Composable fun Routers(rs:List<JSONObject>,api:Api,add:()->Unit,refreshKey:Int,onRefresh:()->Unit){
    var editorRouter by remember{mutableStateOf<JSONObject?>(null)}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("الراوترات",fontSize=27.sp,fontWeight=FontWeight.Black);Text("إضافة • اختبار • إدارة • HotSpot",fontSize=12.sp,color=Muted)};IconButton(add){Icon(Icons.Default.AddCircle,null,tint=Orange)}}}
        if(rs.isEmpty()) item{GlassCard{Text("لا توجد راوترات",fontWeight=FontWeight.Bold);Button(add,Modifier.fillMaxWidth()){Text("إضافة أول راوتر")}}}
        else items(rs){r->GlassCard{Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Router,null,tint=Blue);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(r.optString("name"),fontWeight=FontWeight.Bold);Text("${r.optString("host")} : ${r.optInt("port")}",fontSize=11.sp,color=Muted);Text(if(r.optBoolean("tls"))"API-SSL" else "API",fontSize=10.sp,color=Green)};OutlinedButton(onClick={editorRouter=r}){Icon(Icons.Default.Code,null);Spacer(Modifier.width(4.dp));Text("login.html")}}}}
        item{OutlinedButton(onRefresh,Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(5.dp));Text(stringResource(R.string.action_refresh))}}
    }
    editorRouter?.let{HotspotLoginEditor(api,it){editorRouter=null}}
}


@Composable fun HotspotLoginEditor(api:Api,router:JSONObject,close:()->Unit){
    var content by remember{mutableStateOf("")}
    var validation by remember{mutableStateOf(JSONObject())}
    var message by remember{mutableStateOf("")}
    var backups by remember{mutableStateOf(listOf<JSONObject>())}
    var busy by remember{mutableStateOf(false)}
    var preview by remember{mutableStateOf(false)}
    val scope=rememberCoroutineScope()
    LaunchedEffect(router.optString("id")){
        scope.launch(Dispatchers.IO){try{
            val id=router.optString("id")
            val raw=JSONObject(api.call("/api/routers/$id/hotspot-login"))
            content=raw.optString("content")
            validation=raw.optJSONObject("validation")?:JSONObject()
            val b=JSONObject(api.call("/api/routers/$id/hotspot-login/backups")).optJSONArray("backups")
            backups=if(b!=null) List(b.length()){b.getJSONObject(it)} else emptyList()
        }catch(e:Exception){message=e.message?:"فشل قراءة login.html"}}}
    }
    AlertDialog(onDismissRequest=close,title={Text("محرر MikroTik login.html",fontWeight=FontWeight.Black)},text={
        Column(verticalArrangement=Arrangement.spacedBy(9.dp),modifier=Modifier.fillMaxWidth().heightIn(max=620.dp)){
            Text("${router.optString("name")} • hotspot/login.html",fontSize=11.sp,color=Muted)
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedButton(onClick={preview=true}){Icon(Icons.Default.Visibility,null);Spacer(Modifier.width(4.dp));Text("معاينة")}
                OutlinedButton(enabled=!busy,onClick={
                    busy=true;scope.launch(Dispatchers.IO){try{val id=router.optString("id");val v=JSONObject(api.call("/api/routers/$id/hotspot-login/validate","POST",JSONObject().put("content",content).toString()));validation=v;message=if(v.optBoolean("valid"))"✅ الصفحة متوافقة مبدئيًا مع MikroTik" else "⚠️ توجد عناصر ناقصة: ${v.optJSONArray("errors")}"}catch(e:Exception){message=e.message?:"فشل الفحص"}finally{busy=false}}
                }){Icon(Icons.Default.Verified,null);Spacer(Modifier.width(4.dp));Text("فحص") }
            }
            OutlinedTextField(value=content,onValueChange={content=it},label={Text("كود login.html")},modifier=Modifier.fillMaxWidth().height(360.dp),textStyle=LocalTextStyle.current.copy(fontFamily=FontFamily.Monospace,fontSize=10.sp),maxLines=999)
            val valid=validation.optBoolean("valid",false)
            Text(if(valid)"✅ صالح للنشر" else "⚠️ لم يتم اعتماد الصفحة بعد",color=if(valid)Green else Orange,fontWeight=FontWeight.Bold,fontSize=11.sp)
            if(message.isNotBlank())Text(message,fontSize=11.sp,color=Muted)
            if(backups.isNotEmpty()){
                Text("نسخ احتياطية تلقائية",fontWeight=FontWeight.Bold,fontSize=13.sp)
                backups.take(5).forEach{b->Row(verticalAlignment=Alignment.CenterVertically){Text(b.optString("name"),fontSize=9.sp,modifier=Modifier.weight(1f));TextButton(enabled=!busy,onClick={
                    busy=true;scope.launch(Dispatchers.IO){try{val id=router.optString("id");api.call("/api/routers/$id/hotspot-login/restore","POST",JSONObject().put("backupName",b.optString("name")).toString());val raw=JSONObject(api.call("/api/routers/$id/hotspot-login"));content=raw.optString("content");validation=raw.optJSONObject("validation")?:JSONObject();message="تم الاسترجاع بأمان"}catch(e:Exception){message=e.message?:"فشل الاسترجاع"}finally{busy=false}}}){Text("استرجاع",fontSize=10.sp)}}}
            }
        }
    },confirmButton={Button(enabled=!busy&&validation.optBoolean("valid",false),onClick={busy=true;scope.launch(Dispatchers.IO){try{val id=router.optString("id");val raw=JSONObject(api.call("/api/routers/$id/hotspot-login/publish","POST",JSONObject().put("content",content).toString()));message="تم نشر login.html مع نسخة احتياطية: ${raw.optString("backup","لا توجد")}";val b=JSONObject(api.call("/api/routers/$id/hotspot-login/backups")).optJSONArray("backups");backups=if(b!=null) List(b.length()){b.getJSONObject(it)} else emptyList()}catch(e:Exception){message=e.message?:"فشل النشر"}finally{busy=false}}}){Text(if(busy)"جاري الحفظ…" else "فحص ثم نشر على MikroTik")}},dismissButton={TextButton(close){Text(stringResource(R.string.action_close))}})
    if(preview)AlertDialog(onDismissRequest={preview=false},title={Text("معاينة login.html")},text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState())){Text(content,fontFamily=FontFamily.Monospace,fontSize=9.sp)}},confirmButton={Button({preview=false}){Text(stringResource(R.string.action_close))}})
}

@Composable fun AddRouterDialog(api:Api,done:()->Unit,cancel:()->Unit){var name by remember{mutableStateOf("")};var host by remember{mutableStateOf("")};var port by remember{mutableStateOf("8728")};var user by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var tls by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();AlertDialog(onDismissRequest=cancel,title={Text("إضافة MikroTik")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Field(name,{name=it},"الاسم",Icons.Default.Label);Field(host,{host=it},"IP / Host",Icons.Default.Dns);Field(port,{port=it},"Port",Icons.Default.Settings);Field(user,{user=it},"Username",Icons.Default.Person);Field(pass,{pass=it},"Password",Icons.Default.Lock,true);Row(verticalAlignment=Alignment.CenterVertically){Switch(tls,{tls=it});Text("API-SSL")};if(msg.isNotBlank())Text(msg,color=Red,fontSize=11.sp)}},confirmButton={Button(enabled=!busy,onClick={busy=true;scope.launch(Dispatchers.IO){try{api.call("/api/routers/test","POST",JSONObject().put("host",host).put("port",port.toIntOrNull()?:8728).put("username",user).put("password",pass).put("tls",tls).toString());api.call("/api/routers","POST",JSONObject().put("name",name).put("host",host).put("port",port.toIntOrNull()?:8728).put("username",user).put("password",pass).put("tls",tls).toString());busy=false;done()}catch(e:Exception){busy=false;msg=e.message?:"فشل الاتصال"}}}){Text(if(busy)"جاري الاختبار…" else "اختبار وحفظ")}},dismissButton={TextButton(cancel){Text(stringResource(R.string.action_cancel))}})}

@Composable fun Cards(cards:List<JSONObject>,routers:List<JSONObject>,api:Api,refresh:()->Unit){
    var count by remember{mutableStateOf("10")}
    var profile by remember{mutableStateOf("default")}
    var routerId by remember(routers){mutableStateOf(routers.firstOrNull()?.optString("id"))}
    var prefix by remember{mutableStateOf("MM")}
    var usernameLetters by remember{mutableStateOf("0")}
    var usernameDigits by remember{mutableStateOf("6")}
    var price by remember{mutableStateOf("0")}
    var portalUrl by remember{mutableStateOf("http://mikrotik/login")}
    var qrCheck by remember{mutableStateOf("")}
    var msg by remember{mutableStateOf("")}
    var busy by remember{mutableStateOf(false)}
    var selected by remember{mutableStateOf<JSONObject?>(null)}
    var profiles by remember{mutableStateOf(listOf<JSONObject>())}
    var plans by remember{mutableStateOf(listOf<JSONObject>())}
    var planId by remember{mutableStateOf("")}
    var showPlanEditor by remember{mutableStateOf(false)}
    var showProfileEditor by remember{mutableStateOf(false)}
    var cardSearch by remember{mutableStateOf("")}
    var statusFilter by remember{mutableStateOf("all")}
    var batches by remember{mutableStateOf(listOf<JSONObject>())}
    var showBatchCenter by remember{mutableStateOf(false)}
    var batchMsg by remember{mutableStateOf("")}
    val context=LocalContext.current
    val scope=rememberCoroutineScope()

    fun loadProfiles(id:String?){
        if(id.isNullOrBlank()) return
        scope.launch(Dispatchers.IO){try{
            val a=JSONObject(api.call("/api/routers/$id/hotspot-profiles")).getJSONArray("profiles")
            val list=List(a.length()){a.getJSONObject(it)}
            profiles=list
            if(list.none{it.optString("name")==profile}) profile=list.firstOrNull()?.optString("name") ?: "default"
            list.firstOrNull{it.optString("name")==profile}?.let{price=it.optDouble("price",0.0).toString().removeSuffix(".0")}
        }catch(_:Exception){profiles=emptyList()}}
    }
    fun loadPlans(id:String?){if(id.isNullOrBlank()) return;scope.launch(Dispatchers.IO){runCatching{val a=JSONObject(api.call("/api/routers/$id/plans")).getJSONArray("plans");val list=List(a.length()){a.getJSONObject(it)};plans=list;if(list.none{it.optString("id")==planId})planId=list.firstOrNull()?.optString("id").orEmpty()}}}
    fun loadBatches(){scope.launch(Dispatchers.IO){runCatching{val a=JSONObject(api.call("/api/card-batches")).getJSONArray("batches");batches=List(a.length()){a.getJSONObject(it)}}}}
    LaunchedEffect(routerId){loadProfiles(routerId);loadPlans(routerId)}
    LaunchedEffect(Unit){loadBatches()}
    val filteredCards = cards.filter { c ->
        val q=cardSearch.trim().lowercase()
        val matchesQuery=q.isBlank() || c.optString("username").lowercase().contains(q) || c.optString("batch_id").lowercase().contains(q) || c.optString("plan_name").lowercase().contains(q)
        val matchesStatus=statusFilter=="all" || c.optString("status").equals(statusFilter,true)
        matchesQuery && matchesStatus
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=25.dp)){
        item{Hero("الكروت","توليد • Profiles • QR • Barcode • طباعة • مخزون MikroTik",Icons.Default.Inventory2)}
        item{GlassCard{
            Text("Profiles + إنشاء الكروت",fontSize=20.sp,fontWeight=FontWeight.Black)
            Text("Profile يحدد سلوك الإنترنت على MikroTik، ومنتج MICRO-MAX يحدد السعر والعرض. لا يتم تغيير سعر MikroTik تلقائيًا.",fontSize=11.sp,color=Muted)
            if(routers.isNotEmpty()){
                Text("اختر الراوتر",fontSize=12.sp,color=Muted,fontWeight=FontWeight.Bold)
                routers.forEach{r->
                    val rid=r.optString("id")
                    OutlinedButton(onClick={routerId=rid},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){
                        Icon(if(routerId==rid) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,null,tint=if(routerId==rid) Green else Muted)
                        Spacer(Modifier.width(7.dp)); Text(r.optString("name")); Spacer(Modifier.weight(1f)); Text(if(r.optBoolean("tls"))"API-SSL" else "API",fontSize=10.sp,color=Muted)
                    }
                }
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                Button(enabled=routerId!=null,onClick={showProfileEditor=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("Profile جديد")}
                OutlinedButton(enabled=routerId!=null,onClick={loadProfiles(routerId)},modifier=Modifier.weight(1f)){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("تحديث Profiles")}
            }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                Button(enabled=routerId!=null,onClick={showPlanEditor=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("منتج بيع جديد")}
                OutlinedButton(enabled=routerId!=null,onClick={loadPlans(routerId)},modifier=Modifier.weight(1f)){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("تحديث المنتجات")}
            }
            if(plans.isNotEmpty()){
                Text("اختر منتج البيع",fontSize=12.sp,color=Muted,fontWeight=FontWeight.Bold)
                plans.filter{it.optBoolean("active",true)}.take(20).forEach{pl->
                    val pid=pl.optString("id")
                    OutlinedButton(onClick={planId=pid;profile=pl.optString("profile_name")},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){
                        Icon(if(planId==pid) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,null,tint=if(planId==pid) Green else Muted)
                        Spacer(Modifier.width(7.dp));Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(pl.optString("name"),fontWeight=FontWeight.Bold);Text("Profile: ${pl.optString("profile_name")} • ${pl.optInt("duration_minutes",0)} دقيقة",fontSize=10.sp,color=Muted)};Text("${pl.optDouble("price",0.0)} ${pl.optString("currency","XOF")}",fontSize=11.sp,color=Orange)
                    }
                }
            } else { Text("أنشئ منتج بيع أولًا واربطه بـ Profile. السعر ملك لـ MICRO-MAX وليس MikroTik.",fontSize=10.sp,color=Orange) }
            Field(prefix,{prefix=it.filter{ch->ch.isLetterOrDigit()}.take(12)},"بادئة اسم المستخدم",Icons.Default.Label)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                Field(usernameLetters,{usernameLetters=it.filter(Char::isDigit).take(2)},"عدد الحروف",Icons.Default.TextFields)
                Field(usernameDigits,{usernameDigits=it.filter(Char::isDigit).take(2)},"عدد الأرقام",Icons.Default.Numbers)
            }
            Text("مثال: MM + ${usernameLetters.ifBlank{"0"}} حروف + ${usernameDigits.ifBlank{"6"}} أرقام. تستطيع تغييرها حسب نظامك.",fontSize=10.sp,color=Muted)
            Field(count,{count=it.filter(Char::isDigit)},"عدد الكروت",Icons.Default.Numbers)
            Field(portalUrl,{portalUrl=it.trim()},"رابط صفحة الدخول (HotSpot)",Icons.Default.Link)
            Text("QR الحقيقي يفتح صفحة HotSpot الفعلية بهذا الرابط. لن نعتبره تسجيل دخول تلقائيًا إلا إذا كانت login.html متوافقة مع الإرسال التلقائي.",fontSize=10.sp,color=Muted)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                OutlinedButton(enabled=routerId!=null&&!busy,onClick={
                    busy=true; qrCheck="جاري فحص HotSpot وlogin.html…"
                    scope.launch(Dispatchers.IO){runCatching{
                        val body=JSONObject().put("portalUrl",portalUrl).put("planId",planId).toString()
                        val r=JSONObject(api.call("/api/routers/$routerId/qr-preflight","POST",body))
                        val ready=r.optBoolean("ready"); val mode=r.optString("mode")
                        qrCheck=if(ready && mode=="auto-submit") "✅ QR متوافق مع HotSpot وlogin.html يدعم الإرسال التلقائي" else if(ready) "✅ QR حقيقي متوافق؛ يفتح صفحة HotSpot مع بيانات الكرت" else "⚠️ ${r.optString("error",r.optString("warnings","فشل الفحص"))}"
                    }.onFailure{qrCheck="⚠️ ${it.message?:"فشل فحص QR"}"};busy=false}
                },modifier=Modifier.weight(1f)){Icon(Icons.Default.QrCode,null);Spacer(Modifier.width(5.dp));Text("فحص QR الحقيقي")}
            }
            if(qrCheck.isNotBlank())Text(qrCheck,fontSize=10.sp,color=if(qrCheck.startsWith("✅"))Green else Orange)
            Text("فحص ذكي: التحقق من الراوتر وProfile وتعارض أسماء المستخدمين قبل إنشاء الكروت.",fontSize=11.sp,color=Muted)
            Button(enabled=routerId!=null&&!busy&&profile.isNotBlank(),onClick={
                busy=true
                scope.launch(Dispatchers.IO){try{
                    api.call("/api/routers/$routerId/cards/generate","POST",JSONObject().put("count",count.toIntOrNull()?.coerceIn(1,5000)?:1).put("planId",planId).put("prefix",prefix.ifBlank{"MM"}).put("usernameLetters",usernameLetters.toIntOrNull()?.coerceIn(0,12)?:0).put("usernameDigits",usernameDigits.toIntOrNull()?.coerceIn(0,20)?:6).put("portalUrl",portalUrl.trim()).toString())
                    msg="تم إنشاء الكروت على MikroTik وتحديث المخزون";busy=false;refresh();loadProfiles(routerId)
                }catch(e:Exception){msg=e.message ?: "فشل التوليد";busy=false}}
            },Modifier.fillMaxWidth().height(52.dp)){Text(if(busy)"جاري الفحص والتوليد…" else "فحص ذكي + توليد الكروت",fontWeight=FontWeight.Bold)}
            if(routerId==null)Text("أضف MikroTik أولاً.",fontSize=12.sp,color=Red)
            if(msg.isNotBlank())Text(msg,fontSize=12.sp,color=if(msg.startsWith("تم"))Green else Red)
        }}
        item{
            GlassCard{
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("مركز الدفعات الذكي",fontSize=20.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
                    Text("${batches.size} دفعة",fontSize=11.sp,color=Muted)
                }
                Text("إحصائيات الدفعات، الطباعة والإدارة الآمنة. الكروت المباعة أو المستخدمة محمية من الحذف.",fontSize=11.sp,color=Muted)
                Button(onClick={loadBatches();showBatchCenter=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Inventory2,null);Spacer(Modifier.width(6.dp));Text("فتح مركز الدفعات")}
                if(batchMsg.isNotBlank())Text(batchMsg,fontSize=11.sp,color=if(batchMsg.startsWith("تم"))Green else Orange)
            }
        }
        item{
            GlassCard{
                Row(verticalAlignment=Alignment.CenterVertically){
                    Text("إدارة الكروت",fontSize=20.sp,fontWeight=FontWeight.Black,modifier=Modifier.weight(1f))
                    Text("${filteredCards.size} / ${cards.size}",fontSize=11.sp,color=Muted)
                }
                OutlinedTextField(cardSearch,{cardSearch=it},label={Text("بحث: Username / Batch ID / المنتج")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()){
                    listOf("all" to "الكل","available" to "متاح","sold" to "مباع","used" to "مستخدم","expired" to "منتهي").forEach{(v,label)->
                        FilterChip(selected=statusFilter==v,onClick={statusFilter=v},label={Text(label,fontSize=10.sp)},modifier=Modifier.weight(1f))
                    }
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    OutlinedButton(enabled=filteredCards.isNotEmpty(),onClick={ printCardsSheet(context, filteredCards.take(24), portalUrl) },modifier=Modifier.weight(1f)){Icon(Icons.Default.Print,null);Spacer(Modifier.width(5.dp));Text("طباعة") }
                    OutlinedButton(onClick={cardSearch="";statusFilter="all"},modifier=Modifier.weight(1f)){Icon(Icons.Default.Clear,null);Spacer(Modifier.width(5.dp));Text("مسح الفلتر") }
                }
                Text("الفحص والإدارة لا يغيران السعر أو Profile أو بيانات Username.",fontSize=10.sp,color=Muted)
            }
        }
        items(filteredCards.take(100)){c->
            GlassCard{
                Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(c.optString("username"),fontWeight=FontWeight.Black,fontSize=18.sp);Text("${c.optString("profile")} • ${c.optString("status")} • ${c.optString("router_name")}",fontSize=11.sp,color=Muted); if(c.optString("batch_id").isNotBlank()) Text("Batch: ${c.optString("batch_id").take(8)}…",fontSize=9.sp,color=Muted)};Text(c.optString("password"),color=Blue,fontWeight=FontWeight.Bold)}
                CardBarcode(c.optString("username"))
                Button(onClick={selected=c},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.QrCode,null);Spacer(Modifier.width(6.dp));Text("عرض QR وبيانات الكرت")}
            }
        }
    }
    if(showBatchCenter){
        AlertDialog(onDismissRequest={showBatchCenter=false},title={Text("مركز الدفعات الذكي",fontWeight=FontWeight.Black)},text={
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.heightIn(max=430.dp)){
                if(batches.isEmpty())item{Text("لا توجد دفعات بعد.",fontSize=12.sp,color=Muted)}
                items(batches){b->
                    val bid=b.optString("batch_id")
                    GlassCard{
                        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(bid.take(8)+"…",fontWeight=FontWeight.Black);Text("${b.optString("plan_name")} • ${b.optString("router_name")}",fontSize=10.sp,color=Muted);Text("الإجمالي ${b.optInt("total")} • متاح ${b.optInt("available")} • مباع ${b.optInt("sold")} • مستخدم ${b.optInt("used")}",fontSize=10.sp,color=Muted)};Text("${b.optDouble("price",0.0)} ${b.optString("currency","XOF")}",fontSize=11.sp,color=Orange)}
                        Row(horizontalArrangement=Arrangement.spacedBy(5.dp),modifier=Modifier.fillMaxWidth()){
                            OutlinedButton(onClick={scope.launch(Dispatchers.IO){runCatching{val r=api.call("/api/card-batches/$bid/disable","POST","{}");batchMsg="تم تعطيل ${JSONObject(r).optInt("disabled")} كرت";refresh();loadBatches()}.onFailure{batchMsg=it.message?:"تعذر التعطيل"}}},modifier=Modifier.weight(1f)){Text("تعطيل المتاح",fontSize=9.sp)}
                            OutlinedButton(onClick={scope.launch(Dispatchers.IO){runCatching{val r=api.call("/api/card-batches/$bid","DELETE");batchMsg="تم حذف ${JSONObject(r).optInt("deleted")} كرت";refresh();loadBatches()}.onFailure{batchMsg=it.message?:"الحذف محمي"}}},modifier=Modifier.weight(1f)){Text("تنظيف آمن",fontSize=9.sp)}
                        }
                    }
                }
            }
        },confirmButton={Button(onClick={showBatchCenter=false}){Text(stringResource(R.string.action_close))}})
    }

    selected?.let{c->
        val loginUrl=c.optString("qr_content").ifBlank{"${portalUrl.trimEnd('/')}?username=${Uri.encode(c.optString("username"))}&password=${Uri.encode(c.optString("password"))}&dst=${Uri.encode(Uri.parse(portalUrl).buildUpon().clearQuery().build().toString())}"}
        AlertDialog(onDismissRequest={selected=null},title={Text("معاينة بطاقة MICRO-MAX",fontWeight=FontWeight.Black)},text={CardPreview(username=c.optString("username"),password=c.optString("password"),profile=c.optString("profile"),router=c.optString("router_name"),qrContent=loginUrl)},confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={printCard(context,c.optString("username"),c.optString("password"),c.optString("profile"),portalUrl)}){Icon(Icons.Default.Print,null);Spacer(Modifier.width(4.dp));Text("طباعة PDF")};Button(onClick={selected=null}){Text(stringResource(R.string.action_close))}}})
    }
    if(showProfileEditor && routerId!=null) ProfileEditorDialog(api,routerId!!,{showProfileEditor=false;loadProfiles(routerId)},{showProfileEditor=false})
    if(showPlanEditor && routerId!=null) PlanEditorDialog(api,routerId!!,profiles,{showPlanEditor=false;loadPlans(routerId)},{showPlanEditor=false})
}

@Composable fun ProfileEditorDialog(api:Api,routerId:String,done:()->Unit,cancel:()->Unit){
    var name by remember{mutableStateOf("")};var duration by remember{mutableStateOf("60")};var rate by remember{mutableStateOf("")};var session by remember{mutableStateOf("")};var idle by remember{mutableStateOf("")};var shared by remember{mutableStateOf("1")};var msg by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
    AlertDialog(onDismissRequest=cancel,title={Text("إنشاء / تحديث Profile",fontWeight=FontWeight.Black)},text={LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.heightIn(max=520.dp)){item{Text("Profile يحدد إعدادات الشبكة فقط. سعر البيع يتم إنشاؤه كمنتج MICRO-MAX مستقل.",fontSize=11.sp,color=Muted)};item{Field(name,{name=it},"اسم Profile",Icons.Default.Label)};item{Field(duration,{duration=it.filter(Char::isDigit)},"المدة بالدقائق",Icons.Default.Schedule)};item{Field(rate,{rate=it},"Rate Limit مثال 2M/5M",Icons.Default.Speed)};item{Field(session,{session=it},"Session Timeout اختياري",Icons.Default.Timer)};item{Field(idle,{idle=it},"Idle Timeout اختياري",Icons.Default.HourglassBottom)};item{Field(shared,{shared=it.filter(Char::isDigit)},"عدد الأجهزة المشتركة",Icons.Default.People)};if(msg.isNotBlank())item{Text(msg,color=Red,fontSize=11.sp)}}},confirmButton={Button(enabled=!busy&&name.isNotBlank(),onClick={busy=true;scope.launch(Dispatchers.IO){try{api.call("/api/routers/$routerId/hotspot-profiles","POST",JSONObject().put("name",name).put("price",0).put("durationMinutes",duration.toIntOrNull()?:0).put("rateLimit",rate).put("sessionTimeout",session).put("idleTimeout",idle).put("sharedUsers",shared.toIntOrNull()?:1).toString());busy=false;done()}catch(e:Exception){busy=false;msg=e.message?:"فشل حفظ Profile"}}}){Text(if(busy)"جاري الحفظ…" else "حفظ Profile")}},dismissButton={TextButton(cancel){Text(stringResource(R.string.action_cancel))}})
}

@Composable fun PlanEditorDialog(api:Api,routerId:String,profiles:List<JSONObject>,done:()->Unit,cancel:()->Unit){var name by remember{mutableStateOf("")};var selectedProfile by remember{mutableStateOf(profiles.firstOrNull()?.optString("name").orEmpty())};var price by remember{mutableStateOf("")};var currency by remember{mutableStateOf("XOF")};var msg by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();AlertDialog(onDismissRequest=cancel,title={Text("منتج بيع MICRO-MAX",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("السعر هنا ملك لـ MICRO-MAX. لن يتم تعديل سعر MikroTik.",fontSize=11.sp,color=Muted);Field(name,{name=it},"اسم المنتج",Icons.Default.Label);Text("Profile الشبكة",fontSize=11.sp,color=Muted);profiles.forEach{p0->val pn=p0.optString("name");OutlinedButton(onClick={selectedProfile=pn},modifier=Modifier.fillMaxWidth()){Icon(if(selectedProfile==pn)Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,null);Spacer(Modifier.width(5.dp));Text(pn)}};Field(price,{price=it.filter{ch->ch.isDigit()||ch=='.'}},"سعر البيع",Icons.Default.Payments);Field(currency,{currency=it.filter(Char::isLetter).uppercase().take(6)},"العملة",Icons.Default.AttachMoney);if(msg.isNotBlank())Text(msg,color=Red,fontSize=11.sp)}},confirmButton={Button(enabled=!busy&&name.isNotBlank()&&selectedProfile.isNotBlank()&&price.toDoubleOrNull()!=null,onClick={busy=true;scope.launch(Dispatchers.IO){runCatching{api.call("/api/routers/$routerId/plans","POST",JSONObject().put("name",name).put("profileName",selectedProfile).put("price",price.toDoubleOrNull()?:0.0).put("currency",currency.ifBlank{"XOF"}).toString());busy=false;done()}.onFailure{busy=false;msg=it.message?:"فشل حفظ المنتج"}}}){Text(if(busy)"جاري الحفظ…" else "حفظ المنتج")}},dismissButton={TextButton(cancel){Text(stringResource(R.string.action_cancel))}})}

@Composable
fun CardPreview(username:String,password:String,profile:String,router:String,qrContent:String){
    Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=if(ThemeState.dark.value) Color(0xFF0B1726) else Color.White),modifier=Modifier.fillMaxWidth().border(1.dp,Border,RoundedCornerShape(24.dp)),elevation=CardDefaults.cardElevation(6.dp)){
        Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Blue,Orange))),contentAlignment=Alignment.Center){Text("M",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Black)}
                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("MICRO-MAX",fontSize=19.sp,fontWeight=FontWeight.Black,color=Blue);Text("HOTSPOT ACCESS CARD",fontSize=9.sp,fontWeight=FontWeight.Bold,color=Muted)}
                Surface(shape=RoundedCornerShape(50),color=if(ThemeState.dark.value) Color(0x2235D58A) else Color(0xFFE8F8F1)){Text("VIP",modifier=Modifier.padding(horizontal=10.dp,vertical=5.dp),fontSize=10.sp,fontWeight=FontWeight.Black,color=Green)}
            }
            HorizontalDivider(color=Border)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)){
                    Text("USERNAME",fontSize=9.sp,color=Muted,fontWeight=FontWeight.Bold);Text(username,fontSize=21.sp,fontWeight=FontWeight.Black,color=Ink)
                    Text("PASSWORD",fontSize=9.sp,color=Muted,fontWeight=FontWeight.Bold);Text(password,fontSize=20.sp,fontWeight=FontWeight.Black,color=Orange)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Surface(shape=RoundedCornerShape(8.dp),color=if(ThemeState.dark.value) Color(0x223FAAFF) else Color(0xFFEAF4FB)){Text(profile,modifier=Modifier.padding(horizontal=8.dp,vertical=4.dp),fontSize=10.sp,color=Blue,fontWeight=FontWeight.Bold)};if(router.isNotBlank())Text(router,fontSize=10.sp,color=Muted,modifier=Modifier.padding(top=4.dp))}
                }
                CardQrImage(qrContent,120)
            }
            CardBarcode(username)
            Text("اتصل بالشبكة • امسح QR أو استخدم بيانات الدخول",fontSize=9.sp,color=Muted,modifier=Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
fun CardQrImage(content:String,size:Int){
    val bitmap=remember(content){runCatching{val m=QRCodeWriter().encode(content,BarcodeFormat.QR_CODE,420,420);Bitmap.createBitmap(m.width,m.height,Bitmap.Config.RGB_565).also{b->for(x in 0 until m.width)for(y in 0 until m.height)b.setPixel(x,y,if(m.get(x,y))android.graphics.Color.BLACK else android.graphics.Color.WHITE)}}.getOrNull()}
    if(bitmap!=null)Surface(shape=RoundedCornerShape(12.dp),color=Color.White){Image(bitmap.asImageBitmap(),contentDescription="QR Code",modifier=Modifier.size(size.dp).padding(5.dp))}
}

@Composable
fun CardBarcode(content:String){
    val bitmap=remember(content){runCatching{
        val matrix=MultiFormatWriter().encode(content,BarcodeFormat.CODE_128,900,220)
        Bitmap.createBitmap(matrix.width,matrix.height,Bitmap.Config.RGB_565).also{bmp->
            for(x in 0 until matrix.width) for(y in 0 until matrix.height)
                bmp.setPixel(x,y,if(matrix.get(x,y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }.getOrNull()}
    if(bitmap!=null){
        Surface(shape=RoundedCornerShape(14.dp),color=Color.White,modifier=Modifier.fillMaxWidth()){
            Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(10.dp)){
                androidx.compose.foundation.Image(bitmap.asImageBitmap(),contentDescription="Barcode",modifier=Modifier.fillMaxWidth().height(76.dp))
                Text(content,fontSize=11.sp,fontWeight=FontWeight.Bold,color=Color.Black)
            }
        }
    }
}


/** Prints up to 24 cards as a clean 2-column × 3-row A4 sheet per page. */
fun printCardsSheet(context: android.content.Context, cards: List<JSONObject>, portalUrl: String = "http://mikrotik/login") {
    if (cards.isEmpty()) return
    val printManager = context.getSystemService(PrintManager::class.java)
    val jobName = "MICRO-MAX • ${cards.size} HotSpot Cards"
    val adapter = object : PrintDocumentAdapter() {
        override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes?, cancellationSignal: CancellationSignal?, callback: LayoutResultCallback?, extras: Bundle?) {
            if (cancellationSignal?.isCanceled == true) { callback?.onLayoutCancelled(); return }
            val pages = ((cards.size + 5) / 6).coerceAtLeast(1)
            callback?.onLayoutFinished(
                android.print.PrintDocumentInfo.Builder(jobName)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(pages).build(), true)
        }
        override fun onWrite(pages: Array<out PageRange>?, destination: ParcelFileDescriptor?, cancellationSignal: CancellationSignal?, callback: WriteResultCallback?) {
            try {
                val f = java.io.File(context.cacheDir, "micromax-cards-${System.currentTimeMillis()}.pdf")
                val document = android.graphics.pdf.PdfDocument()
                val pageW = 595; val pageH = 842
                val margin = 24f; val gap = 12f
                val cardW = (pageW - margin * 2 - gap) / 2f
                val cardH = (pageH - margin * 2 - gap * 2) / 3f
                val totalPages = (cards.size + 5) / 6
                for (pageIndex in 0 until totalPages) {
                    if (cancellationSignal?.isCanceled == true) { document.close(); callback?.onWriteCancelled(); return }
                    val page = document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageW, pageH, pageIndex + 1).create())
                    val canvas = page.canvas
                    for (slot in 0 until 6) {
                        val idx = pageIndex * 6 + slot
                        if (idx >= cards.size) break
                        val col = slot % 2; val row = slot / 2
                        val left = margin + col * (cardW + gap)
                        val top = margin + row * (cardH + gap)
                        drawPrintableCard(canvas, cards[idx], left, top, cardW, cardH, portalUrl)
                    }
                    document.finishPage(page)
                }
                FileOutputStream(f).use { document.writeTo(it) }
                document.close()
                ParcelFileDescriptor.AutoCloseInputStream(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)).use { src ->
                    FileOutputStream(destination!!.fileDescriptor).use { out -> src.copyTo(out) }
                }
                callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) { callback?.onWriteFailed(e.message) }
        }
    }
    printManager.print(jobName, adapter, PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
}

private fun drawPrintableCard(canvas: Canvas, c: JSONObject, left: Float, top: Float, w: Float, h: Float, portalUrl: String = "http://mikrotik/login") {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.style = Paint.Style.FILL
    p.color = android.graphics.Color.WHITE
    canvas.drawRoundRect(left, top, left + w, top + h, 16f, 16f, p)
    p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = android.graphics.Color.rgb(215, 225, 235)
    canvas.drawRoundRect(left, top, left + w, top + h, 16f, 16f, p)
    p.style = Paint.Style.FILL; p.color = android.graphics.Color.rgb(7, 94, 158)
    canvas.drawRoundRect(left, top, left + w, top + 42f, 16f, 16f, p)
    canvas.drawRect(left, top + 22f, left + w, top + 42f, p)
    p.color = android.graphics.Color.WHITE; p.typeface = android.graphics.Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.LEFT; p.textSize = 15f
    canvas.drawText("MICRO-MAX", left + 14f, top + 27f, p)
    p.textSize = 8f; p.color = android.graphics.Color.rgb(225, 240, 250); p.textAlign = Paint.Align.RIGHT
    canvas.drawText("HOTSPOT ACCESS", left + w - 14f, top + 26f, p)

    val username = c.optString("username"); val password = c.optString("password"); val profile = c.optString("profile")
    p.textAlign = Paint.Align.LEFT; p.color = android.graphics.Color.rgb(20, 40, 59); p.textSize = 7.5f
    canvas.drawText("USERNAME", left + 14f, top + 62f, p); p.textSize = 15f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
    canvas.drawText(username, left + 14f, top + 80f, p)
    p.typeface = android.graphics.Typeface.DEFAULT; p.textSize = 7.5f; canvas.drawText("PASSWORD", left + 14f, top + 98f, p)
    p.textSize = 14f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD; p.color = android.graphics.Color.rgb(239, 100, 31)
    canvas.drawText(password, left + 14f, top + 115f, p)
    p.typeface = android.graphics.Typeface.DEFAULT; p.textSize = 7.5f; p.color = android.graphics.Color.DKGRAY
    canvas.drawText("PROFILE: $profile", left + 14f, top + 132f, p)

    runCatching {
        val qr = QRCodeWriter().encode("${portalUrl.trimEnd('/')}?username=${Uri.encode(username)}&password=${Uri.encode(password)}", BarcodeFormat.QR_CODE, 150, 150)
        val qSize = 82f; val qLeft = left + w - qSize - 14f; val qTop = top + 53f; val sx = qSize / qr.width; val sy = qSize / qr.height
        p.color = android.graphics.Color.BLACK
        for (x in 0 until qr.width) for (y in 0 until qr.height) if (qr.get(x, y)) canvas.drawRect(qLeft + x * sx, qTop + y * sy, qLeft + (x + 1) * sx, qTop + (y + 1) * sy, p)
    }
    runCatching {
        val bc = MultiFormatWriter().encode(username, BarcodeFormat.CODE_128, 360, 70)
        val bw = w - 28f; val bh = 42f; val bx = left + 14f; val by = top + h - 65f; val sx = bw / bc.width; val sy = bh / bc.height
        p.color = android.graphics.Color.BLACK
        for (x in 0 until bc.width) for (y in 0 until bc.height) if (bc.get(x, y)) canvas.drawRect(bx + x * sx, by + y * sy, bx + (x + 1) * sx, by + (y + 1) * sy, p)
        p.textAlign = Paint.Align.CENTER; p.textSize = 7.5f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        canvas.drawText(username, left + w / 2f, top + h - 15f, p)
    }
}

fun printCard(context: android.content.Context, username:String, password:String, profile:String, portalUrl:String = "http://mikrotik/login"){
    val printManager=context.getSystemService(PrintManager::class.java)
    val jobName="MICRO-MAX • $username"
    val adapter=object: PrintDocumentAdapter(){
        override fun onLayout(oldAttributes:PrintAttributes?,newAttributes:PrintAttributes?,cancellationSignal:CancellationSignal?,callback:LayoutResultCallback?,extras:android.os.Bundle?){
            if(cancellationSignal?.isCanceled==true){callback?.onLayoutCancelled();return}
            callback?.onLayoutFinished(android.print.PrintDocumentInfo.Builder(jobName).setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),true)
        }
        override fun onWrite(pages:Array<out PageRange>?,destination:ParcelFileDescriptor?,cancellationSignal:CancellationSignal?,callback:WriteResultCallback?){
            try{
                val f=java.io.File(context.cacheDir,"micromax-$username.pdf")
                val document=android.graphics.pdf.PdfDocument(); val page=document.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(420,595,1).create()); val canvas=page.canvas; val p=Paint(Paint.ANTI_ALIAS_FLAG)
                p.color=android.graphics.Color.rgb(20,40,59);p.textAlign=Paint.Align.CENTER;p.typeface=android.graphics.Typeface.DEFAULT_BOLD;p.textSize=28f;canvas.drawText("MICRO-MAX",210f,52f,p);p.textSize=12f;canvas.drawText("HOTSPOT ACCESS CARD",210f,72f,p)
                p.textAlign=Paint.Align.LEFT;p.textSize=10f;p.typeface=android.graphics.Typeface.DEFAULT_BOLD;canvas.drawText("USERNAME",28f,115f,p);p.textSize=22f;canvas.drawText(username,28f,140f,p);p.textSize=10f;canvas.drawText("PASSWORD",28f,165f,p);p.textSize=20f;p.color=android.graphics.Color.rgb(239,100,31);canvas.drawText(password,28f,190f,p);p.color=android.graphics.Color.rgb(20,40,59);p.textSize=11f;canvas.drawText("PROFILE: $profile",28f,216f,p)
                val qr=QRCodeWriter().encode("${portalUrl.trimEnd('/')}?username=${Uri.encode(username)}&password=${Uri.encode(password)}",BarcodeFormat.QR_CODE,150,150);for(x in 0 until qr.width)for(y in 0 until qr.height)if(qr.get(x,y)){p.color=android.graphics.Color.BLACK;canvas.drawRect(235f+x*0.9f,95f+y*0.9f,235f+(x+1)*0.9f,95f+(y+1)*0.9f,p)}
                val bc=MultiFormatWriter().encode(username,BarcodeFormat.CODE_128,300,70);for(x in 0 until bc.width)for(y in 0 until bc.height)if(bc.get(x,y)){p.color=android.graphics.Color.BLACK;canvas.drawRect(50f+x*1.05f,285f+y*0.7f,50f+(x+1)*1.05f,285f+(y+1)*0.7f,p)}
                p.textAlign=Paint.Align.CENTER;p.textSize=11f;canvas.drawText(username,210f,365f,p);p.textSize=9f;p.color=android.graphics.Color.DKGRAY;canvas.drawText("Scan QR or use the credentials to connect",210f,540f,p);document.finishPage(page);FileOutputStream(f).use{document.writeTo(it)};document.close()
                ParcelFileDescriptor.AutoCloseInputStream(ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY)).use{src->FileOutputStream(destination!!.fileDescriptor).use{out->src.copyTo(out)}};callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            }catch(e:Exception){callback?.onWriteFailed(e.message)}
        }
    }
    printManager.print(jobName,adapter,PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
}

@Composable
fun BinanceQr(content:String){
    val bitmap=remember(content){runCatching{
        val matrix=QRCodeWriter().encode(content,BarcodeFormat.QR_CODE,560,560)
        Bitmap.createBitmap(matrix.width,matrix.height,Bitmap.Config.RGB_565).also{bmp->
            for(x in 0 until matrix.width) for(y in 0 until matrix.height)
                bmp.setPixel(x,y,if(matrix.get(x,y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }.getOrNull()}
    if(bitmap!=null){
        Surface(shape=RoundedCornerShape(22.dp),color=Color.White,modifier=Modifier.fillMaxWidth()){
            Box(Modifier.fillMaxWidth().padding(18.dp),contentAlignment=Alignment.Center){
                androidx.compose.foundation.Image(bitmap.asImageBitmap(),contentDescription="Binance Pay QR",modifier=Modifier.size(250.dp))
            }
        }
    }
}

@Composable fun Sales(cards:List<JSONObject>,api:Api){
    var card by remember{mutableStateOf("")}; var msg by remember{mutableStateOf("")}; var user by remember{mutableStateOf("")}; var pass by remember{mutableStateOf("")}; var soldProfile by remember{mutableStateOf("")}; var soldDuration by remember{mutableStateOf(0)}; var busy by remember{mutableStateOf(false)}; val scope=rememberCoroutineScope()
    val selectedCard=cards.firstOrNull{it.optString("id")==card}
    val selectedPrice=selectedCard?.optDouble("price",0.0) ?: 0.0
    val selectedDuration=selectedCard?.optInt("profile_duration_minutes",0) ?: 0
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=25.dp)){
        item{Hero("المبيعات","بيع الكروت نقدًا / يدويًا • الدفع الإلكتروني مؤجل ويمكن إضافته لاحقًا",Icons.Default.ShoppingCart)}
        item{GlassCard{
            Text("بيع كرت",fontSize=20.sp,fontWeight=FontWeight.Black)
            Text("اختر كرتًا متاحًا ثم سجّل عملية البيع. لا تحتاج إلى Binance أو أي بوابة دفع لتشغيل النظام.",fontSize=12.sp,color=Muted)
            cards.filter{it.optString("status")=="available"}.take(12).forEach{c->
                val id=c.optString("id"); OutlinedButton(onClick={card=id},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){
                    Icon(if(card==id) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,null,tint=if(card==id) Blue else Muted); Spacer(Modifier.width(7.dp)); Column(Modifier.weight(1f)){Text("${c.optString("username")} • ${c.optString("profile")}",fontWeight=FontWeight.Bold);Text("السعر: ${c.optDouble("price",0.0)} • ${c.optInt("profile_duration_minutes",0)} دقيقة",fontSize=10.sp,color=Muted)}
                }
            }
            if(selectedCard!=null){
                GlassCard{Text("سعر الباقة",fontSize=12.sp,color=Muted);Text("${selectedPrice}",fontSize=28.sp,fontWeight=FontWeight.Black,color=Green);Text("Profile: ${selectedCard.optString("profile")} • المدة: ${selectedDuration} دقيقة",fontSize=11.sp,color=Muted);Text("السعر مأخوذ تلقائيًا من Profile ولا يحتاج إدخالًا يدويًا.",fontSize=10.sp,color=Muted)}
            }
            Button(enabled=card.isNotBlank()&&!busy&&selectedPrice>0,onClick={
                busy=true;msg="";user="";pass=""
                scope.launch(Dispatchers.IO){try{
                    val r=JSONObject(api.call("/api/sales","POST",JSONObject().put("cardId",card).put("paymentMethod","cash").toString()))
                    val c=r.optJSONObject("card"); user=c?.optString("username").orEmpty(); pass=c?.optString("password").orEmpty(); soldProfile=r.optString("profile",c?.optString("profile").orEmpty()); soldDuration=r.optInt("durationMinutes",selectedDuration); msg="تم تسجيل البيع بنجاح • ${r.optDouble("amount",selectedPrice)}"; busy=false
                }catch(e:Exception){msg=e.message?:"فشل تسجيل البيع";busy=false}}
            },Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp)){Text(if(busy)"جاري التسجيل…" else "تسجيل البيع بالسعر المحدد",fontWeight=FontWeight.Bold)}
            if(msg.isNotBlank())Text(msg,fontSize=12.sp,color=if(msg.startsWith("تم")) Green else Red)
        }}
        if(user.isNotBlank())item{GlassCard{Text("بيانات الكرت",fontSize=21.sp,fontWeight=FontWeight.Black,color=Green);Text("Username",fontSize=11.sp,color=Muted);Text(user,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Blue);Text("Password",fontSize=11.sp,color=Muted);Text(pass,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Orange);Text("Profile: $soldProfile • المدة: $soldDuration دقيقة",fontSize=11.sp,color=Muted)}}
        item{GlassCard{Text("الدفع الإلكتروني",fontWeight=FontWeight.Bold);Text("غير مطلوب حاليًا. تم ترك البنية البرمجية جاهزة لإضافة Binance Pay أو أي مزود آخر لاحقًا دون تغيير نظام MikroTik والكروت والمتجر.",fontSize=11.sp,color=Muted)}}
    }
}
@Composable fun Store(api:Api){
    var items by remember{mutableStateOf(listOf<JSONObject>())}; var msg by remember{mutableStateOf("")}; val scope=rememberCoroutineScope()
    LaunchedEffect(Unit){scope.launch(Dispatchers.IO){runCatching{val a=JSONObject(api.call("/api/store")).getJSONArray("items");items=List(a.length()){a.getJSONObject(it)}}}}
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=25.dp)){
        item{Hero("متجر MICRO-MAX","مفتوح داخل المشروع • لا اشتراك مطلوب",Icons.Default.Store)}
        item{GlassCard{Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.LockOpen,null,tint=Green);Spacer(Modifier.width(8.dp));Column{Text("المتجر مفتوح",fontWeight=FontWeight.Black);Text("الوصول إلى العناصر لا يتطلب اشتراكًا مدفوعًا.",fontSize=11.sp,color=Muted)}}}}
        if(msg.isNotBlank())item{Text(msg,fontSize=12.sp,color=Green)}
        items(items){item->GlassCard{Text(item.optString("name"),fontSize=19.sp,fontWeight=FontWeight.Black);Text(item.optString("description"),fontSize=12.sp,color=Muted);Spacer(Modifier.height(4.dp));Row(verticalAlignment=Alignment.CenterVertically){Text(if(item.optDouble("price",0.0)==0.0)"مجاني" else item.optString("price"),fontWeight=FontWeight.Bold,color=Green);Spacer(Modifier.weight(1f));Button(onClick={scope.launch(Dispatchers.IO){runCatching{val r=JSONObject(api.call("/api/store/${item.optString("id")}/activate","POST","{}"));msg=r.optString("message","تم التفعيل")}.onFailure{msg=it.message?:"تعذر التفعيل"}}}){Text("تفعيل")}}}}
        item{GlassCard{Text("الدفع الإلكتروني",fontWeight=FontWeight.Bold);Text("غير مطلوب لتشغيل المتجر أو تفعيل العناصر. يمكن إضافة Binance Pay أو مزود آخر لاحقًا.",fontSize=11.sp,color=Muted)}}
    }
}

@Composable fun Reports(api:Api){var data by remember{mutableStateOf("")};val scope=rememberCoroutineScope();LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Hero("التقارير المالية","يومي • شهري • CSV • PDF",Icons.Default.BarChart)};item{GlassCard{Button(onClick={scope.launch(Dispatchers.IO){try{data=api.call("/api/reports/sales")}catch(e:Exception){data=e.message?:"خطأ"}}},Modifier.fillMaxWidth()){Text("تحميل التقرير")};if(data.isNotBlank())Text(data,fontSize=11.sp,color=Muted)}};item{GlassCard{Text("التصدير",fontWeight=FontWeight.Bold);Text("CSV: /api/reports/sales.csv",fontSize=12.sp);Text("PDF: /api/reports/sales.pdf",fontSize=12.sp);Text("يمكن ربطهما بأزرار مشاركة/طباعة في الخطوة التالية.",fontSize=11.sp,color=Muted)}}}}

@Composable fun Security(api:Api){var logs by remember{mutableStateOf("")};var users by remember{mutableStateOf("")};val scope=rememberCoroutineScope();LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Hero("الأمان والصلاحيات","Admin • Staff • Audit Log • Rate Limiting",Icons.Default.Security)};item{GlassCard{Button(onClick={scope.launch(Dispatchers.IO){try{logs=api.call("/api/audit")}catch(e:Exception){logs=e.message?:"خطأ"}}},Modifier.fillMaxWidth()){Text("عرض سجل النشاط")};if(logs.isNotBlank())Text(logs,fontSize=10.sp,color=Muted)}};item{GlassCard{Button(onClick={scope.launch(Dispatchers.IO){try{users=api.call("/api/users")}catch(e:Exception){users=e.message?:"خطأ"}}},Modifier.fillMaxWidth()){Text("إدارة المستخدمين")};if(users.isNotBlank())Text(users,fontSize=10.sp,color=Muted)}};item{Text("تسجيل الدخول محمي بمحدّد محاولات، وصلاحيات Staff لا تصل إلى وظائف Admin.",fontSize=12.sp,color=Muted)}}}

@Composable fun Settings(logout:()->Unit){val context=LocalContext.current;Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Hero(stringResource(R.string.settings_title),stringResource(R.string.settings_subtitle),Icons.Default.Settings);GlassCard{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(stringResource(R.string.appearance_label),fontWeight=FontWeight.Bold);Text(if(ThemeState.dark.value)stringResource(R.string.appearance_dark) else stringResource(R.string.appearance_light),fontSize=12.sp,color=Muted)};Switch(ThemeState.dark.value,{ThemeState.set(context,it)})}};GlassCard{Text(stringResource(R.string.version_label),fontWeight=FontWeight.Bold);Text("${BuildConfig.VERSION_NAME} • Production architecture",fontSize=12.sp,color=Muted);Text("دعم MikroTik API/API-SSL، الكروت وQR/Barcode، المتجر المفتوح، التقارير، الصلاحيات، النسخ الاحتياطي وسجل التدقيق. الدفع الإلكتروني اختياري ويضاف لاحقًا.",fontSize=11.sp,color=Muted)};GlassCard{Text(stringResource(R.string.backup_label),fontWeight=FontWeight.Bold);Text(stringResource(R.string.backup_note),fontSize=11.sp,color=Muted)};OutlinedButton(logout,Modifier.fillMaxWidth()){Icon(Icons.Default.Logout,null);Spacer(Modifier.width(6.dp));Text(stringResource(R.string.action_logout))}}}
