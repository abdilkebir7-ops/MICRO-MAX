# MICRO-MAX V2.16.1 — Open Features + MikroTik Manager + Card Studio

نسخة مفتوحة من MICRO-MAX تركز على MikroTik والكروت والمتجر، بدون اشتراك إجباري أو بوابة دفع مطلوبة.

## الجديد في V2.6
- Card Studio: تحديد رابط HotSpot الحقيقي الذي يدخل داخل QR.
- QR وBarcode والطباعة يعملان بدون Binance أو أي اشتراك.
- طباعة مجموعة حتى 24 كرتًا في ورقة A4 (6 كروت/صفحة).
- طباعة بطاقة منفردة مع QR وCode 128.
- المتجر مفتوح، وتفعيل العناصر مجاني داخل الحساب.
- الدفع الإلكتروني مفصول ويمكن إضافته لاحقًا.
- تمت إضافة ملفات Gradle كاملة للمشروع حتى يصبح بناء Android واضحًا عبر CI أو Gradle 8.11.1.

## Backend
```bash
cd backend
cp .env.example .env
npm install
npm start
```

## Android
المشروع يستخدم JDK 17 وAndroid Gradle Plugin 8.7.3 وKotlin 2.0.21.

عنوان Backend الافتراضي للمحاكي:
`http://10.0.2.2:8080`

يمكن تغييره في `app/build.gradle.kts` عبر `MICROMAX_API_BASE_URL`.

## الدفع
Binance Pay/NITA غير مطلوبين لتشغيل المميزات الأساسية. مفاتيح الدفع لا توضع داخل Android.

## V2.7 — HotSpot Profiles
- إدارة HotSpot User Profiles لكل MikroTik.
- إنشاء/تحديث Profile من التطبيق مع السعر والمدة وRate Limit وSession/Idle Timeout وShared Users.
- التحقق من وجود الـ Profile على MikroTik قبل إنشاء الكروت.
- حفظ سعر ومدة الباقة محليًا لربطهما بالكروت والمبيعات.
- اختيار Profile مباشرة من شاشة توليد الكروت.

## V2.9 Smart Pricing
- MikroTik HotSpot Profile controls network behavior only.
- MICRO-MAX Plan controls product name, selling price, currency, and active state.
- Card stores a price snapshot and plan_id at generation time.
- Price history is stored in `plan_price_history`.
- Changing a plan price does not rewrite old cards or past sales.
- Online payments remain optional and separate.

## V2.14 — Smart Card Preflight
- Added `POST /api/routers/:id/cards/preflight` for a read-only bulk generation check.
- Validates router access, MikroTik HotSpot Profile, username format, and estimated available username space before generation.
- Preflight never creates, deletes, sells, or changes cards.
- Existing pricing, Plan/Profile separation, Username controls, QR/Barcode, Store, and optional payments remain unchanged.

## V2.15 — Real MikroTik HotSpot QR
- QR content is generated from the actual HotSpot portal URL supplied for the router/card batch.
- Each card stores its generated `qr_content` so printed cards keep the exact QR payload used at creation time.
- Added `/api/routers/:id/qr-preflight` to validate the portal URL, reachability, login form, and RouterOS HotSpot login methods without changing MikroTik settings.
- The app exposes a QR compatibility check before bulk generation.
- Automatic login is only reported when the actual login page already contains compatible form auto-submit handling; otherwise the QR opens the real HotSpot login page with the card credentials prefilled.
- No MikroTik authentication settings are modified automatically.

## V2.16 — MikroTik login.html Editor
- Edit `hotspot/login.html` from MICRO-MAX.
- Validate required MikroTik HotSpot login fields before publish.
- Preview source before publishing.
- Automatic backup before replacing the live file.
- List and restore MICRO-MAX backups.
- Publishing/restore are admin-only and do not change MikroTik HotSpot authentication settings automatically.

## V2.16.0 — Branding, release readiness (this pass)
Online payments (Binance Pay / NITA / Visa) are still intentionally left **disabled by
default** — nothing below touches that.

- **App icon & splash screen**: added an adaptive launcher icon (`mipmap-anydpi-v26`) and a
  Core SplashScreen theme, both built from the same brand gradient/monogram used by the
  in-app `BrandMark` composable. See `app/src/main/res/drawable/ic_launcher_*.xml` and
  `splash_icon.xml`.
- **Unified palette**: added `res/values/colors.xml` as the single source for the brand
  colors used by the icon/splash/status bar (must stay in sync with the `Blue`/`Orange`/etc.
  constants in `MainActivity.kt`).
- **Localization groundwork**: started extracting hardcoded Arabic strings into
  `res/values/strings.xml` (app name, nav labels, Login screen, Settings screen, shared
  action words). This is a **first pass**, not a full extraction — the Cards, Sales, Store,
  Reports, Security and HotspotLoginEditor screens still have inline literals. Add a French
  `values-fr/strings.xml` once ready to expand beyond Arabic.
- **Release signing**: `app/build.gradle.kts` now reads a release signing config from
  `keystore.properties` (gitignored, see `keystore.properties.example`) or from
  `MICROMAX_KEYSTORE_*` environment variables in CI. Without either, `assembleRelease` fails
  loudly instead of silently shipping a debug-signed / unminified APK.
- **Minify + shrink resources** enabled for release builds.
- **Version bump**: `versionCode`/`versionName` now match the feature level (`216` /
  `2.16.0`) instead of the stale `2.7.0`. Bump both on every future release.
- **Theme persistence**: the Black Glass / White Glass toggle in Settings now survives app
  restarts (stored in local `SharedPreferences`, loaded before the first frame).

### Still missing for a fully store-ready release
- Full string extraction + a second language (French, given the FCFA/XOF market)
- Unit/UI tests (none exist yet, backend or Android)
- A real signing keystore generated and stored securely (template only is provided)
- TLS/reverse-proxy in front of the backend's port 8080 in `docker-compose.yml`
- Privacy policy / terms of service (required for Play Store listing)
- Completing `/api/backup/restore`, which still returns `501 NOT_IMPLEMENTED`


## V2.16.1 — MICRO-MAX Manager UI expansion
- Multi-router management with connection test and API/API-SSL.
- Dashboard: CPU, RAM, storage, uptime, users, active users and interface traffic.
- HotSpot Profiles + MICRO-MAX Plans with XOF pricing.
- Card Studio wired to Smart Preflight and Real HotSpot QR generation.
- QR + Code 128 Barcode preview and Android printing.
- Batch Center summary, Store activation, Sales and Reports.
- Users/Roles and Audit Log screens.
- Network center: Interfaces, DHCP leases, ARP, DNS, IP addresses, Routes, Firewall, Queues and Logs.
- HotSpot `login.html` editor with validation, publish, automatic backup and restore.
- Dark/Light glass interface.
- Online payments remain optional; card generation and QR/Barcode do not require a subscription.


## MICRO-MAX authentication
- Google Sign-In via Google ID token verification on the backend.
- Email/password registration and login remain available.
- Configure `GOOGLE_CLIENT_ID` on the backend and the GitHub Actions secret `MICROMAX_GOOGLE_WEB_CLIENT_ID` for Android builds.
- Never place Google client secrets or RouterOS credentials in the Android source.

## Additional network tools
- RouterOS Terminal (admin only) with audit logging.
- HotSpot IP Bindings in Network tools.
- Feature discovery endpoint exposes authentication, card, network, security, backup, store and payment capabilities.
