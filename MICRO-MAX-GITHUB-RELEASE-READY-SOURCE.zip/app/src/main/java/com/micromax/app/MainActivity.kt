package com.micromax.app

import android.graphics.Bitmap
import android.os.Bundle
import android.content.Context
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF050A14)
private val Card = Color(0xFF101B2C)
private val Card2 = Color(0xFF0B1524)
private val Accent = Color(0xFF22D3EE)
private val Blue = Color(0xFF3B82F6)
private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFF43F5E)
private val Amber = Color(0xFFF59E0B)
private val TextMain = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 10, 20)
        window.navigationBarColor = android.graphics.Color.rgb(5, 10, 20)
        window.decorView.systemUiVisibility = 0
        setContent { MicroMaxApp(this) }
    }

    fun printBitmap(bitmap: Bitmap) {
        try {
            androidx.print.PrintHelper(this).apply { scaleMode = androidx.print.PrintHelper.SCALE_MODE_FIT }.printBitmap("MICRO-MAX Card", bitmap)
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "تعذر فتح الطباعة", Toast.LENGTH_LONG).show()
        }
    }
}

class Api(private val base: String) {
    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).writeTimeout(20, TimeUnit.SECONDS).callTimeout(30, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    var token: String? = null
    private fun req(path: String) = Request.Builder().url(base.trim().trimEnd('/') + path).apply { token?.let { addHeader("Authorization", "Bearer $it") } }
    suspend fun get(path: String): String = call(req(path).get().build())
    suspend fun post(path: String, body: String = "{}"): String = call(req(path).post(body.toRequestBody("application/json".toMediaType())).build())
    suspend fun delete(path: String): String = call(req(path).delete().build())
    private suspend fun call(r: Request): String = withContext(Dispatchers.IO) { http.newCall(r).execute().use { x -> val b=x.body?.string().orEmpty(); if(!x.isSuccessful) throw Exception(try{JSONObject(b).optString("detail").ifBlank{JSONObject(b).optString("error")}}catch(_:Exception){"HTTP ${x.code}"}); b } }
}

@Composable
fun MicroMaxApp(activity: MainActivity) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, secondary = Blue, background = Bg, surface = Card, onSurface = TextMain)) {
        val prefs = remember { activity.getSharedPreferences("micromax_session", Context.MODE_PRIVATE) }
        val savedToken = prefs.getString("token", null)
        val savedBase = prefs.getString("api_base", null)
        var api by remember { mutableStateOf(if (!savedToken.isNullOrBlank() && !savedBase.isNullOrBlank()) Api(savedBase).also { it.token = savedToken } else null) }
        var logged by remember { mutableStateOf(api != null) }
        val scope = rememberCoroutineScope()

        fun finishLogin(base: String, raw: String): String? {
            return try {
                val a = Api(base)
                val json = JSONObject(raw)
                a.token = json.getString("token")
                api = a
                prefs.edit().putString("token", a.token).putString("api_base", base).apply()
                logged = true
                null
            } catch (e: Exception) {
                e.message ?: "تعذر تسجيل الدخول"
            }
        }

        if (!logged) {
            LoginScreen(
                defaultUrl = BuildConfig.MICROMAX_API_BASE_URL,
                onLogin = { base, email, password, done ->
                    scope.launch {
                        val a = Api(base)
                        try {
                            val raw = a.post("/api/auth/login", JSONObject().put("email", email).put("password", password).toString())
                            a.token = JSONObject(raw).getString("token")
                            api = a
                            prefs.edit().putString("token", a.token).putString("api_base", base).apply()
                            logged = true
                            done(null)
                        } catch (e: Exception) { done(e.message ?: "تعذر الاتصال بالخادم") }
                    }
                },
                onRegister = { base, email, password, done ->
                    scope.launch {
                        val a = Api(base)
                        try {
                            val raw = a.post("/api/auth/register", JSONObject().put("email", email).put("password", password).toString())
                            a.token = JSONObject(raw).getString("token")
                            api = a
                            prefs.edit().putString("token", a.token).putString("api_base", base).apply()
                            logged = true
                            done(null)
                        } catch (e: Exception) { done(e.message ?: "تعذر إنشاء الحساب") }
                    }
                },
                onGoogleToken = { base, idToken, done ->
                    scope.launch {
                        val a = Api(base)
                        try {
                            val raw = a.post("/api/auth/google", JSONObject().put("idToken", idToken).toString())
                            a.token = JSONObject(raw).getString("token")
                            api = a
                            prefs.edit().putString("token", a.token).putString("api_base", base).apply()
                            logged = true
                            done(null)
                        } catch (e: Exception) { done(e.message ?: "تعذر تسجيل الدخول بحساب Google") }
                    }
                }
            )
        } else {
            MainShell(api!!, activity) { logged = false; api = null; prefs.edit().clear().apply() }
        }
    }
}

@Composable
fun LoginScreen(
    defaultUrl: String,
    onLogin: (String, String, String, (String?) -> Unit) -> Unit,
    onRegister: (String, String, String, (String?) -> Unit) -> Unit,
    onGoogleToken: (String, String, (String?) -> Unit) -> Unit
) {
    var url by remember { mutableStateOf(defaultUrl) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var register by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val googleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            try {
                val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).getResult(com.google.android.gms.common.api.ApiException::class.java)
                val idToken = account.idToken
                if (idToken.isNullOrBlank()) { error = "لم يتم استلام رمز Google"; busy = false }
                else { onGoogleToken(url.trim(), idToken) { error = it; busy = false } }
            } catch (e: Exception) { error = e.message ?: "فشل تسجيل الدخول عبر Google"; busy = false }
        } else busy = false
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A2030), Bg, Color(0xFF03060C)))).systemBarsPadding().imePadding()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Green))
                    Text("SECURE NETWORK CONTROL", fontSize = 9.sp, letterSpacing = 1.2.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                }
                Text("V2.16.1", fontSize = 10.sp, color = Color(0xFF6B8294), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(34.dp))
            Box(Modifier.size(96.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Accent, Blue))), Alignment.Center) {
                Box(Modifier.size(78.dp).clip(RoundedCornerShape(23.dp)).background(Color(0x25030A14)), Alignment.Center) { Text("M", fontSize = 43.sp, fontWeight = FontWeight.Black, color = Color.White) }
            }
            Spacer(Modifier.height(17.dp))
            Text("MICRO-MAX", fontSize = 31.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, color = TextMain)
            Text("HOTSPOT MANAGER", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = Accent)
            Text(if (register) "ابدأ ببناء شبكة أكثر وضوحًا" else "لوحة تحكم واحدة لشبكة MikroTik", fontSize = 13.sp, color = TextMuted)
            Spacer(Modifier.height(27.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE101D2E)),
                border = BorderStroke(1.dp, Color(0x3049D7EA)),
                elevation = CardDefaults.cardElevation(10.dp)
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(if (register) "إنشاء حساب جديد" else "مرحبًا بعودتك", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = TextMain)
                            Text(if (register) "سجّل حسابك وابدأ إدارة الشبكة" else "سجّل الدخول إلى مركز التحكم", fontSize = 12.sp, color = TextMuted)
                        }
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(11.dp)).background(Color(0x1822D3EE)), Alignment.Center) { Icon(if (register) Icons.Default.PersonAdd else Icons.Default.Lock, null, tint = Accent) }
                    }
                    Spacer(Modifier.height(3.dp))
                    Text("بيانات الاتصال", fontSize = 11.sp, color = Accent, fontWeight = FontWeight.Bold)
                    AppField(url, { url = it }, "رابط خادم MICRO-MAX", Icons.Default.Cloud)
                    AppField(email, { email = it }, "البريد الإلكتروني", Icons.Default.Person)
                    OutlinedTextField(
                        pass, { pass = it }, label = { Text("كلمة المرور") }, singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Security, null) },
                        trailingIcon = { IconButton({ show = !show }) { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) } },
                        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(17.dp), colors = fieldColors()
                    )
                    error?.let { Text("⚠  $it", color = Color(0xFFFFA4B0), fontSize = 12.sp) }
                    Button({
                        if (url.isBlank() || email.isBlank() || pass.length < 8) { error = "أدخل البيانات كاملة وكلمة مرور من 8 أحرف على الأقل"; return@Button }
                        busy = true
                        val done: (String?) -> Unit = { error = it; busy = false }
                        if (register) onRegister(url.trim(), email.trim(), pass, done) else onLogin(url.trim(), email.trim(), pass, done)
                    }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)) {
                        if (busy) { CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Bg) }
                        else { Icon(Icons.Default.ArrowForward, null); Text(if (register) "إنشاء الحساب" else "دخول آمن", fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(Modifier.weight(1f), color = Color(0x33475569)); Text("  أو  ", color = TextMuted, fontSize = 12.sp); HorizontalDivider(Modifier.weight(1f), color = Color(0x33475569))
                    }
                    OutlinedButton({
                        if (url.isBlank()) { error = "أدخل رابط خادم MICRO-MAX أولاً"; return@OutlinedButton }
                        busy = true
                        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID).requestEmail().build()
                        googleLauncher.launch(GoogleSignIn.getClient(context, options).signInIntent)
                    }, enabled = !busy && BuildConfig.GOOGLE_WEB_CLIENT_ID != "REPLACE_WITH_GOOGLE_WEB_CLIENT_ID", modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Color(0x35677D91)), colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMain)) {
                        Text("G", fontSize = 17.sp, fontWeight = FontWeight.Black, color = Color(0xFFE9544F)); Text("تسجيل الدخول باستخدام Google", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    if (BuildConfig.GOOGLE_WEB_CLIENT_ID == "REPLACE_WITH_GOOGLE_WEB_CLIENT_ID") Text("يمكن تفعيل Google OAuth من إعدادات الإصدار.", color = TextMuted, fontSize = 10.sp)
                    TextButton({ register = !register; error = null }, Modifier.align(Alignment.CenterHorizontally)) { Text(if (register) "لدي حساب بالفعل" else "إنشاء حساب جديد", color = Accent, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Shield, null, tint = Green, modifier = Modifier.size(14.dp)); Text("جلسة مشفرة وصلاحيات حسب الدور", fontSize = 10.sp, color = TextMuted)
            }
            Spacer(Modifier.height(16.dp)); Text("MICRO-MAX  •  MikroTik Hotspot Manager", fontSize = 10.sp, color = Color(0xFF607889))
        }
    }
}

@Composable fun fieldColors()=OutlinedTextFieldDefaults.colors(focusedBorderColor=Accent,unfocusedBorderColor=Color(0xFF64748B),focusedLabelColor=Accent,unfocusedLabelColor=TextMuted,cursorColor=Accent,focusedTextColor=TextMain,unfocusedTextColor=TextMain)
@Composable fun Logo(){Box(Modifier.size(82.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Accent,Blue))),Alignment.Center){Text("M",fontSize=40.sp,fontWeight=FontWeight.Black,color=Color.White)}}
@Composable fun AppField(v:String,on:(String)->Unit,label:String,icon:androidx.compose.ui.graphics.vector.ImageVector){OutlinedTextField(v,on,label={Text(label)},leadingIcon={Icon(icon,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=fieldColors())}
@Composable fun GlassCard(content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth(),elevation=CardDefaults.cardElevation(7.dp)){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)}}

private data class Nav(val title:String,val icon:androidx.compose.ui.graphics.vector.ImageVector,val page:Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainShell(api: Api, activity: MainActivity, onLogout: () -> Unit) {
    val nav = listOf(
        Nav("الرئيسية", Icons.Default.Dashboard, 0), Nav("الراوترات", Icons.Default.Router, 1),
        Nav("Profiles", Icons.Default.Speed, 2), Nav("الكروت", Icons.Default.QrCode2, 3),
        Nav("المتجر", Icons.Default.Storefront, 4), Nav("المبيعات", Icons.Default.PointOfSale, 5),
        Nav("التقارير", Icons.Default.Assessment, 6), Nav("الأمان", Icons.Default.Security, 7),
        Nav("الشبكة", Icons.Default.Lan, 8), Nav("الإعدادات", Icons.Default.Settings, 9),
        Nav("HotSpot", Icons.Default.Code, 10), Nav("Terminal", Icons.Default.Terminal, 11),
        Nav("Studio", Icons.Default.AutoAwesome, 12)
    )
    var page by remember { mutableIntStateOf(0) }
    var moreOpen by remember { mutableStateOf(false) }
    var routers by remember { mutableStateOf(JSONArray()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var dash by remember { mutableStateOf<JSONObject?>(null) }
    var users by remember { mutableStateOf(JSONArray()) }
    var error by remember { mutableStateOf<String?>(null) }
    var add by remember { mutableStateOf(false) }
    val sessionPrefs = remember { activity.getSharedPreferences("micromax_session", Context.MODE_PRIVATE) }
    var themeDark by remember { mutableStateOf(sessionPrefs.getBoolean("theme_dark", true)) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch {
            try {
                val root = JSONObject(api.get("/api/routers"))
                routers = root.optJSONArray("routers") ?: JSONArray()
                val old = selected?.optString("id")
                selected = (0 until routers.length()).map { routers.getJSONObject(it) }
                    .firstOrNull { it.optString("id") == old }
                    ?: if (routers.length() > 0) routers.getJSONObject(0) else null
                if (selected != null) {
                    val id = selected!!.optString("id")
                    dash = JSONObject(api.get("/api/routers/$id/dashboard"))
                    users = JSONArray(api.get("/api/routers/$id/hotspot/users"))
                } else {
                    dash = null
                    users = JSONArray()
                }
                error = null
            } catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" }
        }
    }
    LaunchedEffect(Unit) { refresh() }
    val scheme = if (themeDark) darkColorScheme(primary = Accent, secondary = Blue, background = Bg, surface = Card, onSurface = TextMain)
                 else lightColorScheme(primary = Color(0xFF075E9E), secondary = Blue, background = Color(0xFFF4F7FB), surface = Color.White, onSurface = Color(0xFF14283B))

    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("MICRO-MAX", fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(8.dp))
                            Text("VIP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Accent,
                                modifier = Modifier.background(Accent.copy(alpha = .12f), RoundedCornerShape(50)).padding(horizontal = 9.dp, vertical = 4.dp))
                        }
                    },
                    actions = {
                        IconButton({ refresh() }) { Icon(Icons.Default.Refresh, null) }
                        IconButton(onLogout) { Icon(Icons.Default.Logout, null) }
                    }
                )
            },
            bottomBar = {
                Box {
                    NavigationBar(containerColor = if (themeDark) Color(0xFF08111F) else Color.White) {
                        nav.take(5).forEach { n ->
                            NavigationBarItem(selected = page == n.page, onClick = { page = n.page }, icon = { Icon(n.icon, null) }, label = { Text(n.title, fontSize = 9.sp) })
                        }
                        NavigationBarItem(selected = page >= 5, onClick = { moreOpen = !moreOpen }, icon = { Icon(Icons.Default.MoreHoriz, null) }, label = { Text("المزيد", fontSize = 9.sp) })
                    }
                    DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                        nav.drop(5).forEach { n ->
                            DropdownMenuItem(text = { Text(n.title) }, leadingIcon = { Icon(n.icon, null) }, onClick = { page = n.page; moreOpen = false })
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when (page) {
                    0 -> DashboardPage(routers, selected, dash, users, error, { add = true }) { r -> selected = r; refresh() }
                    1 -> RoutersPage(routers, selected, { add = true }, { r -> selected = r; page = 0; refresh() }) { id -> scope.launch { try { api.delete("/api/routers/$id"); refresh() } catch (e: Exception) { error = e.message } } }
                    2 -> ProfilesPage(api, selected)
                    3 -> CardsStudioPage(api, selected, activity)
                    4 -> StorePage(api)
                    5 -> SalesPage(api)
                    6 -> ReportsPage(api)
                    7 -> SecurityPage(api)
                    8 -> NetworkPage(api, selected)
                    9 -> SettingsPage(themeDark, { themeDark = !themeDark; sessionPrefs.edit().putBoolean("theme_dark", themeDark).apply() }, onLogout)
                    10 -> HotspotEditorPage(api, selected)
                    11 -> TerminalPage(api, selected)
                    12 -> DesignStudioPage(api, selected, activity)
                }
            }
        }
    }
    if (add) AddRouterDialog(api, { add = false; refresh() }, { add = false })
}

@Composable
fun DashboardPage(
    routers: JSONArray,
    selected: JSONObject?,
    dash: JSONObject?,
    users: JSONArray,
    error: String?,
    add: () -> Unit,
    select: (JSONObject) -> Unit
) {
    val resource = dash?.optJSONObject("resource")
    val cpu = resource?.optString("cpu-load")?.toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
    val ram = memoryPercent(resource)
    val storage = storagePercent(resource)

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 28.dp)
    ) {
        item {
            DashboardHeader()
        }
        error?.let { item { ErrorCard(it) } }

        item {
            if (selected != null && dash != null) {
                RouterHeroCard(selected, resource, cpu, ram, storage, dash)
            } else {
                EmptyRouterCard(add)
            }
        }

        if (selected != null && dash != null) {
            item { Text("إجراءات سريعة", fontSize = 20.sp, fontWeight = FontWeight.Black) }
            item {
                QuickActions(
                    onRouter = add,
                    onCards = { },
                    onUsers = { },
                    onStore = { },
                    onReports = { },
                    onDesign = { }
                )
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("الراوترات", fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Text("الحالة والموارد في نظرة واحدة", fontSize = 12.sp, color = TextMuted)
                }
                TextButton(onClick = { }) { Text("عرض الكل") }
            }
        }
        items((0 until routers.length()).map { routers.getJSONObject(it) }) { r ->
            RouterCompactRow(r, selected?.optString("id") == r.optString("id"), { select(r) })
        }

        if (selected != null && dash != null) {
            item { Text("واجهات الشبكة", fontSize = 20.sp, fontWeight = FontWeight.Black) }
            val ints = dash.optJSONArray("interfaces") ?: JSONArray()
            items((0 until ints.length()).take(6)) { InterfaceRow(ints.getJSONObject(it)) }
            item { Text("آخر مستخدمي Hotspot", fontSize = 20.sp, fontWeight = FontWeight.Black) }
            items((0 until users.length()).take(6)) { UserRow(users.getJSONObject(it)) }
        }
    }
}

@Composable
private fun DashboardHeader() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            Modifier.size(46.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Blue))),
            contentAlignment = Alignment.Center
        ) { Text("K", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("MICRO-MAX", fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("Hotspot Manager", fontSize = 12.sp, color = TextMuted)
            Text("إدارة شبكتك بسهولة واحترافية", fontSize = 11.sp, color = Accent)
        }
        Surface(color = Accent.copy(alpha = .12f), shape = RoundedCornerShape(50)) {
            Text("VIP", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

@Composable
private fun RouterHeroCard(r: JSONObject, resource: JSONObject?, cpu: Float, ram: Float, storage: Float, d: JSONObject) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Card2),
        border = androidx.compose.foundation.BorderStroke(1.dp, Accent.copy(alpha = .22f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = .95f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Router, null, tint = Blue, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.optString("name", "MikroTik"), fontSize = 19.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(7.dp))
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Green))
                    }
                    Text(r.optString("host", "-"), fontSize = 12.sp, color = TextMuted)
                    Text("RouterOS ${resource?.optString("version", "-") ?: "-"}", fontSize = 12.sp, color = TextMuted)
                }
                Surface(color = Accent.copy(alpha = .10f), shape = RoundedCornerShape(14.dp)) {
                    Text("متصل", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricGauge("CPU", cpu, Accent, Modifier.weight(1f))
                MetricGauge("RAM", ram, Green, Modifier.weight(1f))
                MetricGauge("التخزين", storage, Amber, Modifier.weight(1f))
            }
            HorizontalDivider(color = Color.White.copy(alpha = .08f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                MiniMetric(Icons.Default.People, "المستخدمون", d.optInt("users", d.optInt("activeUsers", 0)).toString())
                MiniMetric(Icons.Default.Wifi, "المتصلون", d.optInt("active", d.optInt("activeUsers", 0)).toString())
                MiniMetric(Icons.Default.DataUsage, "الترافيك", trafficText(d))
            }
        }
    }
}

@Composable
private fun MetricGauge(label: String, value: Float, tint: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${value.toInt()}%", fontSize = 20.sp, fontWeight = FontWeight.Black, color = tint)
        LinearProgressIndicator(progress = { value / 100f }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(50)), color = tint, trackColor = tint.copy(alpha = .13f))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = TextMuted)
    }
}

@Composable
private fun MiniMetric(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(20.dp))
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(title, fontSize = 10.sp, color = TextMuted)
    }
}

@Composable
private fun QuickActions(onRouter: () -> Unit, onCards: () -> Unit, onUsers: () -> Unit, onStore: () -> Unit, onReports: () -> Unit, onDesign: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            QuickAction("إضافة راوتر", Icons.Default.Add, Blue, onRouter, Modifier.weight(1f))
            QuickAction("كرت جديد", Icons.Default.CreditCard, Green, onCards, Modifier.weight(1f))
            QuickAction("المستخدمون", Icons.Default.People, Color(0xFF8B5CF6), onUsers, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            QuickAction("متجر الكروت", Icons.Default.ShoppingCart, Amber, onStore, Modifier.weight(1f))
            QuickAction("تصميم الكرت", Icons.Default.Palette, Color(0xFFEC4899), onDesign, Modifier.weight(1f))
            QuickAction("التقارير", Icons.Default.Description, TextMuted, onReports, Modifier.weight(1f))
        }
    }
}

@Composable
private fun QuickAction(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, click: () -> Unit, modifier: Modifier) {
    Card(modifier.clickable(onClick = click), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = tint.copy(alpha = .11f)), border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = .25f))) {
        Column(Modifier.fillMaxWidth().padding(vertical = 13.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(5.dp))
            Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun RouterCompactRow(r: JSONObject, selected: Boolean, click: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = click), colors = CardDefaults.cardColors(containerColor = if (selected) Accent.copy(alpha = .10f) else Card), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Accent.copy(alpha = .25f) else Color.White.copy(alpha = .06f))) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = .08f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Router, null, tint = Accent) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text(r.optString("name", "MikroTik"), fontWeight = FontWeight.Bold); Spacer(Modifier.width(6.dp)); Box(Modifier.size(7.dp).clip(CircleShape).background(Green)) }
                Text(r.optString("host", "-"), fontSize = 11.sp, color = TextMuted)
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
        }
    }
}

private fun memoryPercent(r: JSONObject?): Float {
    val t = r?.optString("total-memory")?.toLongOrNull() ?: return 0f
    val f = r.optString("free-memory").toLongOrNull() ?: return 0f
    return if (t > 0) ((t - f) * 100f / t).coerceIn(0f, 100f) else 0f
}

private fun storagePercent(r: JSONObject?): Float {
    val t = r?.optString("total-hdd-space")?.toLongOrNull() ?: return 0f
    val f = r.optString("free-hdd-space").toLongOrNull() ?: return 0f
    return if (t > 0) ((t - f) * 100f / t).coerceIn(0f, 100f) else 0f
}

@Composable fun RouterSelector(rs:JSONArray,s:JSONObject?,add:()->Unit,select:(JSONObject)->Unit){GlassCard{Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Router,null,tint=Accent);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("الراوتر الحالي",fontSize=12.sp,color=TextMuted);Text(s?.optString("name")?:"لا يوجد راوتر",fontWeight=FontWeight.Bold)};Button(add){Icon(Icons.Default.Add,null);Text("إضافة")}};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){for(i in 0 until rs.length()){val r=rs.getJSONObject(i);FilterChip(s?.optString("id")==r.optString("id"),{select(r)},{Text(r.optString("name","Router"),maxLines=1)})}}}}
@Composable fun StatsGrid(r:JSONObject?,d:JSONObject){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("CPU",r?.optString("cpu-load","-")+"%",Icons.Default.Speed,Modifier.weight(1f));Stat("المستخدمون",d.optInt("users",d.optInt("activeUsers",0)).toString(),Icons.Default.People,Modifier.weight(1f))};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("متصل الآن",d.optInt("active",d.optInt("activeUsers",0)).toString(),Icons.Default.Wifi,Modifier.weight(1f));Stat("RAM",memoryText(r),Icons.Default.Memory,Modifier.weight(1f))};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("Storage",storageText(r),Icons.Default.Storage,Modifier.weight(1f));Stat("Traffic",trafficText(d),Icons.Default.DataUsage,Modifier.weight(1f))}}}
@Composable fun Stat(t:String,v:String,i:androidx.compose.ui.graphics.vector.ImageVector,m:Modifier){Card(m,colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(16.dp)){Icon(i,null,tint=Accent);Text(t,fontSize=12.sp,color=TextMuted);Text(v,fontSize=22.sp,fontWeight=FontWeight.Black)}}}
@Composable fun ResourceCard(r:JSONObject?,router:JSONObject){GlassCard{Text(router.optString("name","Router"),fontWeight=FontWeight.Bold);Text(router.optString("host","-"),fontSize=12.sp,color=TextMuted);HorizontalDivider();Text("RouterOS ${r?.optString("version","-")}",fontWeight=FontWeight.Bold);Text("${r?.optString("board-name","-")} • ${r?.optString("architecture-name","-")}",fontSize=12.sp,color=TextMuted);Text("Uptime: ${r?.optString("uptime","-")}",fontSize=12.sp,color=TextMuted)}}
fun memoryText(r:JSONObject?):String{val t=r?.optString("total-memory")?.toLongOrNull();val f=r?.optString("free-memory")?.toLongOrNull();return if(t!=null&&f!=null&&t>0)"${((t-f)*100/t)}%" else "-"}
fun storageText(r:JSONObject?):String{val t=r?.optString("total-hdd-space")?.toLongOrNull();val f=r?.optString("free-hdd-space")?.toLongOrNull();return if(t!=null&&f!=null&&t>0)"${((t-f)*100/t)}%" else "-"}
fun trafficText(d:JSONObject):String{val a=d.optJSONArray("interfaces")?:return "-";var total=0L;for(i in 0 until a.length()){val o=a.optJSONObject(i);total+=o?.optString("rx-byte")?.toLongOrNull()?:0L;total+=o?.optString("tx-byte")?.toLongOrNull()?:0L};return if(total<=0)"-" else if(total>1_000_000_000)String.format("%.1f GB",total/1_000_000_000.0) else if(total>1_000_000)String.format("%.1f MB",total/1_000_000.0) else "${total/1000} KB"}
@Composable fun InterfaceRow(o:JSONObject){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Lan,null,tint=Accent);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(o.optString("name","-"),fontWeight=FontWeight.Bold);Text(o.optString("type",""),fontSize=12.sp,color=TextMuted)};Text(if(o.optString("running")=="true")"UP" else "DOWN",color=if(o.optString("running")=="true")Green else Red,fontWeight=FontWeight.Bold)}}}
@Composable fun UserRow(o:JSONObject){val dis=o.optString("disabled")=="true";Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Person,null,tint=if(dis)Red else Green);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(o.optString("name","-"),fontWeight=FontWeight.Bold);Text(o.optString("profile","default"),fontSize=12.sp,color=TextMuted)};Text(if(dis)"معطل" else "فعال",color=if(dis)Red else Green,fontWeight=FontWeight.Bold)}}}
@Composable fun EmptyRouterCard(add:()->Unit){GlassCard{Icon(Icons.Default.Router,null,tint=Accent,modifier=Modifier.size(42.dp));Text("لا يوجد راوتر مرتبط",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("أضف MikroTik ثم اختبر الاتصال.",color=TextMuted);Button(add,Modifier.fillMaxWidth()){Text("إضافة راوتر MikroTik")}}}
@Composable fun ErrorCard(s:String){Card(colors=CardDefaults.cardColors(containerColor=Red.copy(alpha=.12f)),shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){Text("⚠ $s",Modifier.padding(14.dp),color=Color(0xFFFFA4B0))}}

@Composable fun RoutersPage(rs:JSONArray,selected:JSONObject?,add:()->Unit,choose:(JSONObject)->Unit,remove:(String)->Unit){LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("إدارة الراوترات",fontSize=28.sp,fontWeight=FontWeight.Black);Text("إضافة • اختبار • حفظ • إدارة عدة MikroTik",fontSize=13.sp,color=TextMuted)};Button(add){Icon(Icons.Default.Add,null);Text("إضافة")}}};items((0 until rs.length()).map{rs.getJSONObject(it)}){r->RouterRow(r,selected?.optString("id")==r.optString("id"),{choose(r)},{remove(r.optString("id"))})}}}
@Composable fun RouterRow(r:JSONObject,sel:Boolean,choose:()->Unit,remove:()->Unit){Card(Modifier.fillMaxWidth().clickable{choose()},colors=CardDefaults.cardColors(containerColor=if(sel)Accent.copy(alpha=.12f)else Card),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Router,null,tint=Blue);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(r.optString("name","Router"),fontWeight=FontWeight.Bold);Text("${r.optString("host","-")}:${r.optInt("port",8728)} • ${if(r.optBoolean("tls"))"API-SSL" else "API"}",fontSize=12.sp,color=TextMuted)};IconButton(remove){Icon(Icons.Default.Delete,null,tint=Red)}}}}

@Composable
fun ProfilesPage(api: Api, router: JSONObject?) {
    var profiles by remember { mutableStateOf(JSONArray()) }
    var plans by remember { mutableStateOf(JSONArray()) }
    var error by remember { mutableStateOf<String?>(null) }
    var show by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun load() { scope.launch { if (router != null) try { val id=router.optString("id"); profiles=JSONObject(api.get("/api/routers/$id/hotspot-profiles")).optJSONArray("profiles")?:JSONArray(); plans=JSONObject(api.get("/api/routers/$id/plans")).optJSONArray("plans")?:JSONArray() } catch(e:Exception){ error=e.message } } }
    LaunchedEffect(router?.optString("id")) { load() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Profiles & Plans", fontSize=28.sp, fontWeight=FontWeight.Black)
        Text("Profile = سلوك الشبكة • Plan = المنتج والسعر", color=TextMuted)
        error?.let { ErrorCard(it) }
        if (router == null) EmptyCard("اختر راوتر أولاً") else {
            Button({ show=true }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add,null); Text("إضافة Profile + Plan") }
            Text("HotSpot Profiles", fontSize=20.sp, fontWeight=FontWeight.Bold)
            for(i in 0 until profiles.length()) { val p=profiles.getJSONObject(i); GlassCard { Text(p.optString("name"),fontWeight=FontWeight.Bold); Text("Rate: ${p.optString("rateLimit","-")} • Session: ${p.optString("sessionTimeout","-")} • Shared: ${p.optInt("sharedUsers",1)}",fontSize=12.sp,color=TextMuted) } }
            Text("Plans", fontSize=20.sp, fontWeight=FontWeight.Bold)
            for(i in 0 until plans.length()) { val p=plans.getJSONObject(i); GlassCard { Text(p.optString("name"),fontWeight=FontWeight.Bold); Text("${p.optDouble("price",0.0)} ${p.optString("currency","XOF")} • ${p.optString("profileName",p.optString("profile_name","-"))}",color=Accent) } }
        }
    }
    if(show && router!=null) ProfileDialog(api,router,{show=false;load()},{show=false})
}

@Composable fun ProfileDialog(api:Api,r:JSONObject,done:()->Unit,cancel:()->Unit){var name by remember{mutableStateOf("")};var duration by remember{mutableStateOf("60")};var rate by remember{mutableStateOf("")};var session by remember{mutableStateOf("")};var shared by remember{mutableStateOf("1")};var plan by remember{mutableStateOf("")};var price by remember{mutableStateOf("0")};var busy by remember{mutableStateOf(false)};var err by remember{mutableStateOf<String?>(null)};val scope=rememberCoroutineScope();AlertDialog(onDismissRequest=cancel,title={Text("Profile + Plan")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){AppField(name,{name=it},"اسم Profile",Icons.Default.Speed);AppField(duration,{duration=it},"المدة بالدقائق",Icons.Default.Timer);AppField(rate,{rate=it},"Rate Limit (مثال 2M/2M)",Icons.Default.Speed);AppField(session,{session=it},"Session Timeout",Icons.Default.Timer);AppField(shared,{shared=it},"Shared Users",Icons.Default.People);AppField(plan,{plan=it},"اسم Plan",Icons.Default.Inventory2);AppField(price,{price=it},"السعر XOF",Icons.Default.Payments);err?.let{Text(it,color=Red)}}},confirmButton={Button({scope.launch{busy=true;try{val id=r.optString("id");api.post("/api/routers/$id/hotspot-profiles",JSONObject().put("name",name).put("durationMinutes",duration.toIntOrNull()?:0).put("rateLimit",rate).put("sessionTimeout",session).put("sharedUsers",shared.toIntOrNull()?:1).toString());api.post("/api/routers/$id/plans",JSONObject().put("profileName",name).put("name",if(plan.isBlank())name else plan).put("price",price.toDoubleOrNull()?:0).put("currency","XOF").toString());done()}catch(e:Exception){err=e.message}finally{busy=false}}},enabled=!busy&&name.isNotBlank()&&price.isNotBlank()){Text(if(busy)"جاري الحفظ…" else "حفظ")}},dismissButton={TextButton(cancel){Text("إلغاء")}})}

@Composable fun CardsStudioPage(api:Api,router:JSONObject?,activity:MainActivity){var plans by remember{mutableStateOf(JSONArray())};var selectedPlan by remember{mutableStateOf<JSONObject?>(null)};var portal by remember{mutableStateOf("")};var count by remember{mutableStateOf("10")};var prefix by remember{mutableStateOf("KMX")};var digits by remember{mutableStateOf("6")};var result by remember{mutableStateOf<JSONArray?>(null)};var batches by remember{mutableStateOf<JSONArray?>(null)};var err by remember{mutableStateOf<String?>(null)};var busy by remember{mutableStateOf(false)};var preview by remember{mutableStateOf<JSONObject?>(null)};val scope=rememberCoroutineScope();LaunchedEffect(router?.optString("id")){if(router!=null)scope.launch{try{plans=JSONObject(api.get("/api/routers/${router.optString("id")}/plans")).optJSONArray("plans")?:JSONArray()}catch(e:Exception){err=e.message}}};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Card Studio",fontSize=28.sp,fontWeight=FontWeight.Black);Text("QR + Barcode + Preflight + توليد + Batch Center — بدون اشتراك",color=TextMuted);if(router==null)EmptyCard("اختر راوتر أولاً") else {GlassCard{Text("بيانات الكروت",fontWeight=FontWeight.Bold);AppField(portal,{portal=it},"رابط HotSpot الحقيقي",Icons.Default.Link);AppField(count,{count=it},"عدد الكروت",Icons.Default.Numbers);AppField(prefix,{prefix=it},"Prefix",Icons.Default.Tag);AppField(digits,{digits=it},"عدد أرقام اسم المستخدم",Icons.Default.Numbers);Text("الخطة",fontSize=13.sp,color=TextMuted);if(plans.length()==0)Text("أنشئ Plan أولاً من Profiles",color=Amber);for(i in 0 until plans.length()){val p=plans.getJSONObject(i);FilterChip(selectedPlan?.optString("id")==p.optString("id"),{selectedPlan=p},{Text("${p.optString("name")} • ${p.optDouble("price")} ${p.optString("currency","XOF")}")})};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({scope.launch{busy=true;try{val id=router.optString("id");api.post("/api/routers/$id/qr-preflight",JSONObject().put("portalUrl",portal).toString());val raw=api.post("/api/routers/$id/cards/preflight",JSONObject().put("count",count.toIntOrNull()?:1).put("planId",selectedPlan?.optString("id")).put("prefix",prefix).put("usernameDigits",digits.toIntOrNull()?:6).put("usernameLetters",0).put("portalUrl",portal).toString());err="Preflight جاهز: ${JSONObject(raw).optBoolean("ready",true)}"}catch(e:Exception){err=e.message}}},enabled=!busy&&selectedPlan!=null&&portal.isNotBlank()){Text("فحص ذكي")};Button({scope.launch{busy=true;err=null;try{val id=router.optString("id");val raw=api.post("/api/routers/$id/cards/generate",JSONObject().put("count",count.toIntOrNull()?:1).put("planId",selectedPlan?.optString("id")).put("prefix",prefix).put("usernameDigits",digits.toIntOrNull()?:6).put("usernameLetters",0).put("portalUrl",portal).toString());result=JSONObject(raw).optJSONArray("cards")}catch(e:Exception){err=e.message}finally{busy=false}}},enabled=!busy&&selectedPlan!=null&&portal.isNotBlank()){Text(if(busy)"جاري…" else "توليد")}}};err?.let{Text(it,color=if(it.startsWith("Preflight"))Green else Red)};result?.let{arr->Text("تم إنشاء ${arr.length()} كرت",fontSize=20.sp,fontWeight=FontWeight.Bold);for(i in 0 until minOf(arr.length(),50)){val c=arr.getJSONObject(i);Card(Modifier.fillMaxWidth().clickable{preview=c},colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.QrCode2,null,tint=Accent);Column(Modifier.weight(1f)){Text(c.optString("username"),fontWeight=FontWeight.Bold);Text("${c.optString("password")} • ${c.optString("profile")}",fontSize=12.sp,color=TextMuted)};Text("${c.optDouble("price")} ${c.optString("currency","XOF")}",color=Accent)}}}};Button({scope.launch{try{batches=JSONObject(api.get("/api/card-batches")).optJSONArray("batches")}catch(e:Exception){err=e.message}}},Modifier.fillMaxWidth()){Text("فتح Batch Center")};batches?.let{Text("آخر الدُفعات",fontSize=20.sp,fontWeight=FontWeight.Bold);for(i in 0 until minOf(it.length(),20)){val b=it.getJSONObject(i);GlassCard{Text(b.optString("plan_name",b.optString("planName","Batch")),fontWeight=FontWeight.Bold);Text("${b.optInt("total")} كرت • متاح ${b.optInt("available")} • مباع ${b.optInt("sold")}",color=TextMuted)}}}};preview?.let{CardPreviewDialog(it,{preview=null},{bitmap->activity.printBitmap(bitmap)})}}}

@Composable fun CardPreviewDialog(c:JSONObject,close:()->Unit,print:(Bitmap)->Unit){val qr=c.optString("qrContent");val q=remember(qr){generateCode(qr,BarcodeFormat.QR_CODE,520,520)};val b=remember(c.optString("username")){generateCode(c.optString("username"),BarcodeFormat.CODE_128,700,150)};AlertDialog(onDismissRequest=close,title={Text("معاينة الكرت")},text={Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.verticalScroll(rememberScrollState())){Text("MICRO-MAX",fontSize=22.sp,fontWeight=FontWeight.Black);Text(c.optString("username"),fontWeight=FontWeight.Bold);Text(c.optString("password"),color=Accent);q?.let{Image(it.asImageBitmap(),null,Modifier.size(190.dp))};b?.let{Image(it.asImageBitmap(),null,Modifier.fillMaxWidth().height(55.dp))};Text("QR وBarcode يعملان بدون اشتراك",fontSize=11.sp,color=TextMuted)}},confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton({composeCardBitmap(c)?.let{print(it)}}){Text("طباعة")};TextButton(close){Text("إغلاق")}}})}

fun generateCode(value:String,format:BarcodeFormat,w:Int,h:Int):Bitmap?{return try{val hints=mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,EncodeHintType.MARGIN to 1);val m:BitMatrix=MultiFormatWriter().encode(value,format,w,h,hints);val bmp=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);for(x in 0 until w)for(y in 0 until h)bmp.setPixel(x,y,if(m[x,y])android.graphics.Color.BLACK else android.graphics.Color.WHITE);bmp}catch(_:Exception){null}}

fun MainActivity.printBitmap(bitmap:Bitmap){try{androidx.print.PrintHelper(this).apply{scaleMode=androidx.print.PrintHelper.SCALE_MODE_FIT}.printBitmap("MICRO-MAX Card",bitmap)}catch(e:Exception){Toast.makeText(this,e.message?:"تعذر فتح الطباعة",Toast.LENGTH_LONG).show()}}

fun composeCardBitmap(c:JSONObject):Bitmap?{val qr=generateCode(c.optString("qrContent"),BarcodeFormat.QR_CODE,520,520)?:return null;val bar=generateCode(c.optString("username"),BarcodeFormat.CODE_128,700,150)?:return null;val out=Bitmap.createBitmap(900,900,Bitmap.Config.ARGB_8888);val canvas=android.graphics.Canvas(out);canvas.drawColor(android.graphics.Color.WHITE);val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);p.color=android.graphics.Color.BLACK;p.textSize=42f;p.typeface=android.graphics.Typeface.DEFAULT_BOLD;canvas.drawText("MICRO-MAX",40f,60f,p);p.textSize=30f;canvas.drawText(c.optString("username"),40f,110f,p);canvas.drawText(c.optString("password"),40f,150f,p);canvas.drawBitmap(qr,null,android.graphics.Rect(190,180,710,700),p);canvas.drawBitmap(bar,null,android.graphics.Rect(100,730,800,880),p);return out}

@Composable fun StorePage(api:Api){var items by remember{mutableStateOf(JSONArray())};var msg by remember{mutableStateOf<String?>(null)};val scope=rememberCoroutineScope();LaunchedEffect(Unit){scope.launch{try{items=JSONObject(api.get("/api/store")).optJSONArray("items")?:JSONArray()}catch(e:Exception){msg=e.message}}};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("المتجر",fontSize=28.sp,fontWeight=FontWeight.Black);Text("القوالب والأدوات الأساسية متاحة بدون اشتراك إجباري",color=TextMuted)};msg?.let{item{ErrorCard(it)}};items((0 until items.length()).map{items.getJSONObject(it)}){o->GlassCard{Text(o.optString("name"),fontSize=18.sp,fontWeight=FontWeight.Bold);Text(o.optString("description"),color=TextMuted);Button({scope.launch{try{val x=api.post("/api/store/${o.optString("id")}/activate");msg=JSONObject(x).optString("message","تم التفعيل") }catch(e:Exception){msg=e.message}}},Modifier.fillMaxWidth()){Text("تفعيل مجاناً")}}}}}

@Composable fun SalesPage(api:Api){var sales by remember{mutableStateOf(JSONArray())};var cards by remember{mutableStateOf(JSONArray())};var err by remember{mutableStateOf<String?>(null)};var busy by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();fun load(){scope.launch{try{sales=JSONObject(api.get("/api/sales")).optJSONArray("sales")?:JSONArray();cards=JSONObject(api.get("/api/cards")).optJSONArray("cards")?:JSONArray()}catch(e:Exception){err=e.message}}};LaunchedEffect(Unit){load()};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("المبيعات",fontSize=28.sp,fontWeight=FontWeight.Black);Text("بيع الكرت نقداً الآن أو تتبع حالة الدفع الإلكتروني الاختياري",color=TextMuted);err?.let{ErrorCard(it)};Text("كروت جاهزة للبيع",fontSize=20.sp,fontWeight=FontWeight.Bold);for(i in 0 until minOf(cards.length(),40)){val c=cards.getJSONObject(i);if(c.optString("status")=="available"){GlassCard{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(c.optString("username"),fontWeight=FontWeight.Bold);Text("${c.optString("plan_name",c.optString("profile"))} • ${c.optDouble("price")} ${c.optString("price_currency","XOF")}",fontSize=12.sp,color=TextMuted)};Button({scope.launch{busy=true;try{api.post("/api/sales",JSONObject().put("cardId",c.optString("id")).put("paymentMethod","cash").toString());load()}catch(e:Exception){err=e.message}finally{busy=false}}},enabled=!busy){Text("بيع نقداً")}}}}};Text("آخر المبيعات",fontSize=20.sp,fontWeight=FontWeight.Bold);for(i in 0 until minOf(sales.length(),30)){val o=sales.getJSONObject(i);GlassCard{Text(o.optString("card_username","-"),fontWeight=FontWeight.Bold);Text("${o.optDouble("amount")} • ${o.optString("payment_method")} • ${o.optString("payment_status")}",color=TextMuted)}}}}

@Composable fun ReportsPage(api:Api){var data by remember{mutableStateOf(JSONArray())};var err by remember{mutableStateOf<String?>(null)};val scope=rememberCoroutineScope();LaunchedEffect(Unit){scope.launch{try{data=JSONObject(api.get("/api/reports/sales")).optJSONArray("rows")?:JSONArray()}catch(e:Exception){err=e.message}}};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("التقارير",fontSize=28.sp,fontWeight=FontWeight.Black);Text("تقارير المبيعات والإيرادات اليومية",color=TextMuted)};err?.let{item{ErrorCard(it)}};items((0 until data.length()).map{data.getJSONObject(it)}){o->GlassCard{Text(o.optString("day","-"),fontWeight=FontWeight.Bold);Text("المبيعات: ${o.optInt("sales")} • الإيراد: ${o.optDouble("revenue")} • مدفوع: ${o.optInt("paid")}",color=TextMuted)}}}}

@Composable
fun SecurityPage(api: Api) {
    var tab by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf(JSONArray()) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope=rememberCoroutineScope()
    fun load(){ scope.launch { try { val o=JSONObject(api.get(if(tab==0) "/api/users" else "/api/audit")); data=o.optJSONArray(if(tab==0) "users" else "logs")?:JSONArray(); err=null } catch(e:Exception){err=e.message} } }
    LaunchedEffect(tab){load()}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Text("الأمان والصلاحيات",fontSize=28.sp,fontWeight=FontWeight.Black)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ FilterChip(tab==0,{tab=0},{Text("المستخدمون")}); FilterChip(tab==1,{tab=1},{Text("سجل التدقيق")}) }
        err?.let{ErrorCard(it)}
        LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(top=12.dp)){items((0 until data.length()).map{data.getJSONObject(it)}){o->GlassCard{Text(if(tab==0)o.optString("email","-") else o.optString("action","-"),fontWeight=FontWeight.Bold);Text(if(tab==0)o.optString("role","staff") else "${o.optString("entity")} • ${o.optString("created_at")}",color=TextMuted)}}}
    }
}

@Composable
fun NetworkPage(api: Api, router: JSONObject?) {
    var tab by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf(JSONArray()) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope=rememberCoroutineScope()
    val names=listOf("Interfaces","DHCP","ARP","DNS","IP","Routes","Firewall","Queues","Logs","IP Bindings")
    val paths=listOf("interfaces","dhcp-leases","arp","dns-static","ip-addresses","routes","firewall","queues","logs","ip-bindings")
    LaunchedEffect(router?.optString("id"),tab){ if(router!=null) scope.launch{ try{val o=JSONObject(api.get("/api/routers/${router.optString("id")}/network/${paths[tab]}"));data=o.optJSONArray("items")?:JSONArray();err=null}catch(e:Exception){err=e.message}} }
    Column(Modifier.fillMaxSize().padding(12.dp)){
        Text("أدوات الشبكة",fontSize=27.sp,fontWeight=FontWeight.Black); Text(router?.optString("name")?:"اختر راوتر",color=TextMuted)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){names.forEachIndexed{i,n->FilterChip(tab==i,{tab=i},{Text(n,fontSize=11.sp)})}}
        err?.let{ErrorCard(it)}
        LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=10.dp)){items((0 until data.length()).map{data.getJSONObject(it)}){o->GlassCard{val title=o.optString("name",o.optString("address",o.optString("dst-address",o.optString("message","-"))));Text(title,fontWeight=FontWeight.Bold);Text(o.toString().removePrefix("{").removeSuffix("}").take(260),fontSize=11.sp,color=TextMuted)}}}
    }
}


@Composable
fun TerminalPage(api: Api, router: JSONObject?) {
    var command by remember { mutableStateOf("/system/resource/print") }
    var output by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Terminal RouterOS", fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text(router?.optString("name") ?: "اختر راوتر", color = TextMuted)
        if (router == null) EmptyCard("اختر راوتر أولاً") else {
            OutlinedTextField(command, { command = it }, label = { Text("أمر RouterOS") }, modifier = Modifier.fillMaxWidth(), minLines = 2, colors = fieldColors())
            Text("مثال: /system/resource/print أو /ip/hotspot/user/print", color = TextMuted, fontSize = 11.sp)
            Button({
                scope.launch {
                    busy = true; err = null
                    try {
                        val raw = api.post("/api/routers/${router.optString("id")}/terminal", JSONObject().put("command", command).toString())
                        output = JSONObject(raw).optJSONArray("result")?.toString(2) ?: raw
                    } catch(e: Exception) { err = e.message } finally { busy = false }
                }
            }, enabled = !busy && command.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (busy) "جاري التنفيذ…" else "تنفيذ الأمر") }
            err?.let { ErrorCard(it) }
            if (output.isNotBlank()) GlassCard { Text("النتيجة", fontWeight = FontWeight.Bold); Text(output, fontSize = 11.sp, color = TextMuted) }
        }
    }
}

@Composable
fun HotspotEditorPage(api: Api, router: JSONObject?) {
    var content by remember { mutableStateOf("") }
    var validation by remember { mutableStateOf<String?>(null) }
    var backups by remember { mutableStateOf(JSONArray()) }
    var busy by remember { mutableStateOf(false) }
    val scope=rememberCoroutineScope()
    LaunchedEffect(router?.optString("id")) {
        if(router!=null) scope.launch { try {
            val id=router.optString("id")
            val o=JSONObject(api.get("/api/routers/$id/hotspot-login"))
            content=o.optString("content","")
            backups=JSONObject(api.get("/api/routers/$id/hotspot-login/backups")).optJSONArray("backups")?:JSONArray()
        } catch(e:Exception){ validation=e.message } }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("HotSpot login.html",fontSize=27.sp,fontWeight=FontWeight.Black)
        Text(router?.optString("name")?:"اختر راوتر",color=TextMuted)
        if(router==null) EmptyCard("اختر راوتر أولاً") else {
            OutlinedTextField(content,{content=it},label={Text("مصدر login.html")},modifier=Modifier.fillMaxWidth().height(420.dp),textStyle=LocalTextStyle.current.copy(fontSize=11.sp),colors=fieldColors())
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button({ scope.launch { busy=true; try { val r=api.post("/api/routers/${router.optString("id")}/hotspot-login/validate",JSONObject().put("content",content).toString()); validation=JSONObject(r).toString(2) } catch(e:Exception){validation=e.message} finally{busy=false} } }) { Text("تحقق") }
                Button({ scope.launch { busy=true; try { api.post("/api/routers/${router.optString("id")}/hotspot-login/publish",JSONObject().put("content",content).toString()); validation="تم النشر مع إنشاء Backup تلقائي" } catch(e:Exception){validation=e.message} finally{busy=false} } },enabled=!busy) { Text("نشر") }
            }
            validation?.let { GlassCard { Text(it,fontSize=11.sp) } }
            Text("Backups",fontSize=20.sp,fontWeight=FontWeight.Bold)
            for(i in 0 until backups.length()) {
                val b=backups.getJSONObject(i)
                Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Card)) {
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Text(b.optString("name"),Modifier.weight(1f),fontSize=11.sp)
                        TextButton({ scope.launch { try { api.post("/api/routers/${router.optString("id")}/hotspot-login/restore",JSONObject().put("backupName",b.optString("name")).toString()); validation="تمت الاستعادة" } catch(e:Exception){validation=e.message} } }) { Text("استعادة") }
                    }
                }
            }
        }
    }
}

@Composable fun SettingsPage(dark:Boolean,toggle:()->Unit,logout:()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("الإعدادات",fontSize=28.sp,fontWeight=FontWeight.Black);GlassCard{Text("MICRO-MAX V2.16",fontWeight=FontWeight.Bold);Text("إدارة MikroTik عبر RouterOS API / API-SSL",color=TextMuted);Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.DarkMode,null,tint=Accent);Spacer(Modifier.width(10.dp));Text("الوضع الزجاجي الداكن",Modifier.weight(1f));Switch(dark,{toggle()})}};GlassCard{Text("المميزات المتفق عليها",fontWeight=FontWeight.Bold);Text("✓ عدة MikroTik\n✓ Dashboard وCPU/RAM/Uptime/Users/Traffic\n✓ Profiles وPlans والأسعار\n✓ Cards + QR + Barcode + Batch Center\n✓ Store + Sales + Reports\n✓ Users/Roles + Audit\n✓ Network: Interfaces/DHCP/ARP/DNS/IP/Routes/Firewall/Queues/Logs\n✓ HotSpot login.html Editor + Backup/Restore\n✓ الدفع الإلكتروني اختياري",color=TextMuted)};OutlinedButton(logout,Modifier.fillMaxWidth()){Icon(Icons.Default.Logout,null);Text("تسجيل الخروج")}}}

@Composable
fun AddRouterDialog(api:Api,onSaved:()->Unit,onCancel:()->Unit){
    var name by remember{mutableStateOf("")};var host by remember{mutableStateOf("")};var port by remember{mutableStateOf("8729")};var user by remember{mutableStateOf("admin")};var pass by remember{mutableStateOf("")};var tls by remember{mutableStateOf(true)};var busy by remember{mutableStateOf(false)};var err by remember{mutableStateOf<String?>(null)};val scope=rememberCoroutineScope()
    AlertDialog(onDismissRequest=onCancel,title={Text("إضافة MikroTik")},
        text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
            AppField(name,{name=it},"اسم الراوتر",Icons.Default.Router);AppField(host,{host=it},"IP / Host",Icons.Default.Cloud);AppField(port,{port=it},"Port",Icons.Default.Dns);AppField(user,{user=it},"اسم مستخدم MikroTik",Icons.Default.Person)
            OutlinedTextField(pass,{pass=it},label={Text("كلمة المرور")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),singleLine=true,colors=fieldColors())
            Row(verticalAlignment=Alignment.CenterVertically){Checkbox(tls,{tls=it});Text("API-SSL 8729")};err?.let{Text(it,color=Red)}
        }},
        confirmButton={Button({scope.launch{busy=true;try{val body=JSONObject().put("name",name.trim()).put("host",host.trim()).put("port",port.toIntOrNull()?:8729).put("username",user.trim()).put("password",pass).put("tls",tls);api.post("/api/routers/test",body.toString());api.post("/api/routers",body.toString());onSaved()}catch(e:Exception){err=e.message}finally{busy=false}}},enabled=!busy&&name.isNotBlank()&&host.isNotBlank()&&user.isNotBlank()&&pass.isNotBlank()){Text(if(busy)"جاري الاختبار…" else "اختبار وحفظ")}},
        dismissButton={TextButton(onCancel){Text("إلغاء")}})
}

@Composable fun EmptyCard(s:String){Card(colors=CardDefaults.cardColors(containerColor=Card2),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Text(s,Modifier.padding(18.dp),color=TextMuted)}}
